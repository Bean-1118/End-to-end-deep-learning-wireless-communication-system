"""
Residual Block 1 layer groups and Task 5.2 fine-grained strategies.

The block is decomposed into individual layers and layer combinations.
"""

from __future__ import annotations

from typing import Dict, Sequence


# ============================================================
# Residual Block 1 layers
# ============================================================

RESIDUAL_1_LAYERS = {
    "input": "decoder_res1_input",
    "conv1": "decoder_res1_conv1",
    "conv2": "decoder_res1_conv2",
}


# ============================================================
# Other reference groups
# ============================================================

DECODER_INPUT_LAYER = (
    "decoder_conv_1",
)

ENTIRE_RESIDUAL_1 = (
    "decoder_res1_input",
    "decoder_res1_conv1",
    "decoder_res1_conv2",
)

ENTIRE_DECODER = (
    "decoder_conv_1",
    "decoder_res1_input",
    "decoder_res1_conv1",
    "decoder_res1_conv2",
    "decoder_res2_input",
    "decoder_res2_conv1",
    "decoder_res2_conv2",
    "decoder_conv_final",
    "pred_logits_full",
)


# ============================================================
# Task 5.2 strategies
# ============================================================

TASK5_2_STRATEGIES: Dict[str, Sequence[str]] = {
    # Baseline: no parameter updates.
    "no_adaptation": (),

    # Individual Residual Block 1 layers.
    "res1_input_only": (
        RESIDUAL_1_LAYERS["input"],
    ),

    "res1_conv1_only": (
        RESIDUAL_1_LAYERS["conv1"],
    ),

    "res1_conv2_only": (
        RESIDUAL_1_LAYERS["conv2"],
    ),

    # Two-layer combinations.
    "res1_input_plus_conv1": (
        RESIDUAL_1_LAYERS["input"],
        RESIDUAL_1_LAYERS["conv1"],
    ),

    "res1_conv1_plus_conv2": (
        RESIDUAL_1_LAYERS["conv1"],
        RESIDUAL_1_LAYERS["conv2"],
    ),

    "res1_input_plus_conv2": (
        RESIDUAL_1_LAYERS["input"],
        RESIDUAL_1_LAYERS["conv2"],
    ),

    # Entire Residual Block 1.
    "entire_residual_1": (
        *ENTIRE_RESIDUAL_1,
    ),

    # Reference strategies from Task 5.1.
    "decoder_input_only": (
        *DECODER_INPUT_LAYER,
    ),

    "entire_decoder": (
        *ENTIRE_DECODER,
    ),

    "full_finetune": (
        "__ALL__",
    ),
}


# Default strategy set for the first Task 5.2A scan.
DEFAULT_TASK5_2A_STRATEGIES = (
    "no_adaptation",
    "res1_input_only",
    "res1_conv1_only",
    "res1_conv2_only",
    "res1_input_plus_conv1",
    "res1_conv1_plus_conv2",
    "res1_input_plus_conv2",
    "entire_residual_1",
    "decoder_input_only",
    "entire_decoder",
    "full_finetune",
)


# Default compact set for Task 5.2B.
# CLI options can override best_single_layer and best_compact_subset.
DEFAULT_TASK5_2B_REFERENCE_STRATEGIES = (
    "no_adaptation",
    "entire_residual_1",
    "entire_decoder",
    "full_finetune",
)


def get_task5_2_layer_names(
    strategy_name: str,
) -> Sequence[str]:
    """Return the requested trainable layers for a Task 5.2 strategy."""
    if strategy_name not in TASK5_2_STRATEGIES:
        raise KeyError(
            f"Unknown Task 5.2 strategy {strategy_name!r}. "
            f"Available strategies: "
            f"{sorted(TASK5_2_STRATEGIES)}"
        )

    return TASK5_2_STRATEGIES[strategy_name]