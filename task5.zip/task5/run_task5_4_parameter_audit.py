from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path
from typing import Dict, Iterable, List

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps

from src.task4.checkpoint_utils import (
    restore_task2_checkpoint,
)

from src.task4.fixed_adaptation import (
    make_fixed_adaptation_dataset,
    set_all_seeds,
)

from src.task5.task5_3_groups import (
    combine_unique,
    ENCODER,
    CHANNEL_ESTIMATOR,
)

from src.task5.trainable_masks import (
    apply_named_layer_mask,
)

from src.task5.run_task5_2_parameter_scan import (
    deterministic_ber,
    parse_pair,
)

from src.task5.task5_4_audit_utils import (
    calculate_layer_weight_changes,
    restore_layer_weights,
    snapshot_layer_weights,
    train_with_gradient_audit,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


CORE_PARTICULAR = (
    "decoder_conv_1",
    "decoder_res1_input",
    "decoder_res1_conv2",
)


TASK5_4_STRATEGIES = {
    "final_core": CORE_PARTICULAR,

    "final_core_plus_channel_estimator": combine_unique(
        CORE_PARTICULAR,
        CHANNEL_ESTIMATOR,
    ),

    "final_core_plus_encoder": combine_unique(
        CORE_PARTICULAR,
        ENCODER,
    ),

    "final_core_plus_encoder_plus_channel_estimator":
        combine_unique(
            CORE_PARTICULAR,
            ENCODER,
            CHANNEL_ESTIMATOR,
        ),

    "entire_decoder": (
        "decoder_conv_1",

        "decoder_res1_input",
        "decoder_res1_conv1",
        "decoder_res1_conv2",

        "decoder_res2_input",
        "decoder_res2_conv1",
        "decoder_res2_conv2",

        "decoder_conv_final",
        "pred_logits_full",
    ),

    "full_finetune": (
        "__ALL__",
    ),
}


DEFAULT_STRATEGIES = (
    "final_core",
    "final_core_plus_channel_estimator",
    "entire_decoder",
    "full_finetune",
)


def write_csv(
    path: Path,
    rows: List[Dict[str, object]],
) -> None:
    if not rows:
        return

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames: List[str] = []

    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )

        writer.writeheader()

        for row in rows:
            writer.writerow(row)


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Task 5.4 parameter importance and update audit."
        )
    )

    parser.add_argument(
        "--pairs",
        nargs="+",
        type=parse_pair,
        default=[
            (0, 1),
            (0, 4),
            (2, 6),
            (4, 0),
            (6, 2),
        ],
    )

    parser.add_argument(
        "--strategies",
        nargs="+",
        choices=sorted(TASK5_4_STRATEGIES),
        default=list(DEFAULT_STRATEGIES),
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[2026, 2027, 2028],
    )

    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=2048,
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=1e-4,
    )

    parser.add_argument(
        "--ebno-linear",
        type=float,
        default=20.0,
    )

    parser.add_argument(
        "--test-batches",
        type=int,
        default=100,
    )

    parser.add_argument(
        "--checkpoint-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "checkpoints"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task5"
            / "task5_4_parameter_audit"
        ),
    )

    return parser.parse_args()


def run_revert_ablation(
    model: tf.keras.Model,
    source_pdp,
    target_pdp,
    source_id: int,
    target_id: int,
    seed: int,
    strategy: str,
    audited_layers: Iterable[str],
    before_snapshot,
    after_snapshot,
    ebno_linear: float,
    test_batches: int,
    source_eval_seed: int,
    target_eval_seed: int,
    adapted_source_ber: float,
    adapted_target_ber: float,
) -> List[Dict[str, object]]:
    """
    Revert one layer at a time to its pre-adaptation value.
    """
    rows: List[Dict[str, object]] = []

    for layer_name in audited_layers:
        if layer_name not in before_snapshot:
            continue

        # Ensure every trial begins from the fully adapted model.
        restore_layer_weights(
            model=model,
            snapshots=after_snapshot,
        )

        # Revert exactly one layer.
        restore_layer_weights(
            model=model,
            snapshots=before_snapshot,
            layer_names=[layer_name],
        )

        reverted_target_ber = deterministic_ber(
            model=model,
            pdp=target_pdp,
            ebno_linear=ebno_linear,
            num_test_batches=test_batches,
            seed=target_eval_seed,
        )

        reverted_source_ber = deterministic_ber(
            model=model,
            pdp=source_pdp,
            ebno_linear=ebno_linear,
            num_test_batches=test_batches,
            seed=source_eval_seed,
        )

        rows.append({
            "source_pdp": source_id,
            "target_pdp": target_id,
            "seed": seed,
            "strategy": strategy,
            "layer_name": layer_name,

            "adapted_target_ber": adapted_target_ber,
            "reverted_target_ber": reverted_target_ber,

            # Positive means that reverting the layer damaged
            # target performance, so adaptation of this layer
            # made a useful contribution.
            "target_ber_loss_after_revert": (
                reverted_target_ber
                - adapted_target_ber
            ),

            "adapted_source_ber": adapted_source_ber,
            "reverted_source_ber": reverted_source_ber,

            "source_ber_change_after_revert": (
                reverted_source_ber
                - adapted_source_ber
            ),
        })

    # Leave model in the fully adapted state.
    restore_layer_weights(
        model=model,
        snapshots=after_snapshot,
    )

    return rows


def run_one_experiment(
    args: argparse.Namespace,
    source_id: int,
    target_id: int,
    strategy: str,
    seed: int,
    source_pdp,
    target_pdp,
    dataset,
    strategy_directory: Path,
):
    tf.keras.backend.clear_session()
    gc.collect()
    set_all_seeds(seed)

    model = end_to_end()

    restored_checkpoint = restore_task2_checkpoint(
        model=model,
        checkpoint_dir=(
            args.checkpoint_root
            / f"model_trained_on_PDP{source_id}"
        ),
    )

    requested_layers = TASK5_4_STRATEGIES[strategy]

    audit = apply_named_layer_mask(
        model=model,
        strategy_name=strategy,
        requested_layer_names=requested_layers,
    )

    pair_code = source_id * 100 + target_id

    source_eval_seed = (
        71000 + seed + pair_code * 10
    )

    target_eval_seed = (
        81000 + seed + pair_code * 10
    )

    source_ber_before = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_eval_seed,
    )

    target_ber_before = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_eval_seed,
    )

    before_snapshot = snapshot_layer_weights(
        model
    )

    history, gradient_accumulator = (
        train_with_gradient_audit(
            model=model,
            dataset=dataset,
            epochs=args.epochs,
            learning_rate=args.learning_rate,
            seed=seed,
        )
    )

    after_snapshot = snapshot_layer_weights(
        model
    )

    target_ber_after = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_eval_seed,
    )

    source_ber_after = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_eval_seed,
    )

    weight_rows = calculate_layer_weight_changes(
        model=model,
        before=before_snapshot,
        source_pdp=source_id,
        target_pdp=target_id,
        seed=seed,
        strategy=strategy,
    )

    gradient_rows = gradient_accumulator.to_rows(
        source_pdp=source_id,
        target_pdp=target_id,
        seed=seed,
        strategy=strategy,
    )

    revert_rows = run_revert_ablation(
        model=model,
        source_pdp=source_pdp,
        target_pdp=target_pdp,
        source_id=source_id,
        target_id=target_id,
        seed=seed,
        strategy=strategy,
        audited_layers=(
            audit.actual_trainable_layer_names
        ),
        before_snapshot=before_snapshot,
        after_snapshot=after_snapshot,
        ebno_linear=args.ebno_linear,
        test_batches=args.test_batches,
        source_eval_seed=source_eval_seed,
        target_eval_seed=target_eval_seed,
        adapted_source_ber=source_ber_after,
        adapted_target_ber=target_ber_after,
    )

    strategy_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    write_csv(
        strategy_directory
        / "layer_weight_changes.csv",
        weight_rows,
    )

    write_csv(
        strategy_directory
        / "gradient_statistics.csv",
        gradient_rows,
    )

    write_csv(
        strategy_directory
        / "layer_revert_ablation.csv",
        revert_rows,
    )

    (
        strategy_directory
        / "training_history.json"
    ).write_text(
        json.dumps(history, indent=2),
        encoding="utf-8",
    )

    result = {
        "source_pdp": source_id,
        "target_pdp": target_id,
        "seed": seed,
        "strategy": strategy,

        "trainable_parameters":
            audit.trainable_parameter_count,

        "trainable_percentage":
            audit.trainable_percentage,

        "actual_trainable_layers":
            "; ".join(
                audit.actual_trainable_layer_names
            ),

        "source_ber_before":
            source_ber_before,

        "source_ber_after":
            source_ber_after,

        "target_ber_before":
            target_ber_before,

        "target_ber_after":
            target_ber_after,

        "target_absolute_improvement": (
            target_ber_before
            - target_ber_after
        ),

        "source_ber_change": (
            source_ber_after
            - source_ber_before
        ),

        "restored_checkpoint":
            str(restored_checkpoint),
    }

    (
        strategy_directory
        / "result.json"
    ).write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    del model
    tf.keras.backend.clear_session()
    gc.collect()

    return (
        result,
        weight_rows,
        gradient_rows,
        revert_rows,
    )


def main() -> int:
    args = parse_arguments()
    pdps = get_known_pdps()

    all_results: List[Dict[str, object]] = []
    all_weight_rows: List[Dict[str, object]] = []
    all_gradient_rows: List[Dict[str, object]] = []
    all_revert_rows: List[Dict[str, object]] = []

    raw_root = args.output_root / "raw"

    for source_id, target_id in args.pairs:
        source_pdp = pdps[source_id]
        target_pdp = pdps[target_id]

        for seed in args.seeds:
            dataset_seed = (
                seed
                + source_id * 1000
                + target_id * 100
            )

            dataset = make_fixed_adaptation_dataset(
                pdp_target=target_pdp,
                pdp_id=target_id,
                num_blocks=args.adaptation_blocks,
                ebno_linear=args.ebno_linear,
                seed=dataset_seed,
            )

            for strategy in args.strategies:
                print("\n" + "=" * 80)
                print(
                    f"PDP{source_id}->PDP{target_id} | "
                    f"seed={seed} | "
                    f"strategy={strategy}"
                )
                print("=" * 80)

                strategy_directory = (
                    raw_root
                    / f"PDP{source_id}_to_PDP{target_id}"
                    / f"seed_{seed}"
                    / strategy
                )

                (
                    result,
                    weight_rows,
                    gradient_rows,
                    revert_rows,
                ) = run_one_experiment(
                    args=args,
                    source_id=source_id,
                    target_id=target_id,
                    strategy=strategy,
                    seed=seed,
                    source_pdp=source_pdp,
                    target_pdp=target_pdp,
                    dataset=dataset,
                    strategy_directory=strategy_directory,
                )

                all_results.append(result)
                all_weight_rows.extend(weight_rows)
                all_gradient_rows.extend(gradient_rows)
                all_revert_rows.extend(revert_rows)

                write_csv(
                    args.output_root
                    / "raw_results_partial.csv",
                    all_results,
                )

    write_csv(
        args.output_root
        / "raw_results.csv",
        all_results,
    )

    write_csv(
        args.output_root
        / "layer_weight_changes_all.csv",
        all_weight_rows,
    )

    write_csv(
        args.output_root
        / "gradient_statistics_all.csv",
        all_gradient_rows,
    )

    write_csv(
        args.output_root
        / "layer_revert_ablation_all.csv",
        all_revert_rows,
    )

    print("\nTask 5.4 completed.")
    print(f"Results: {args.output_root}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())