"""
Decoder parameter groups and Task 5.1 trainable-layer strategies.

Layer names match the Decoder defined in src/base_functions.py.
"""

from __future__ import annotations

from typing import Dict, Sequence


# ============================================================
# Decoder functional groups
# ============================================================

DECODER_GROUPS: Dict[str, Sequence[str]] = {
    # First convolution after bilinear multiplication.
    "decoder_input": (
        "decoder_conv_1",
    ),

    # First residual block.
    "decoder_residual_1": (
        "decoder_res1_input",
        "decoder_res1_conv1",
        "decoder_res1_conv2",
    ),

    # Second residual block.
    "decoder_residual_2": (
        "decoder_res2_input",
        "decoder_res2_conv1",
        "decoder_res2_conv2",
    ),

    # Final feature projection and bit-decision layer.
    "decoder_output_head": (
        "decoder_conv_final",
        "pred_logits_full",
    ),
}


ALL_DECODER_PARAMETER_LAYERS = tuple(
    layer_name
    for group_layers in DECODER_GROUPS.values()
    for layer_name in group_layers
)


# ============================================================
# Task 5.1 strategies
# ============================================================

TASK5_1_STRATEGIES: Dict[str, Sequence[str]] = {
    # No parameter update; BER evaluation only.
    "no_adaptation": (),

    # Individual Decoder groups.
    "decoder_input_only": (
        *DECODER_GROUPS["decoder_input"],
    ),

    "decoder_residual_1_only": (
        *DECODER_GROUPS["decoder_residual_1"],
    ),

    "decoder_residual_2_only": (
        *DECODER_GROUPS["decoder_residual_2"],
    ),

    "decoder_output_head_only": (
        *DECODER_GROUPS["decoder_output_head"],
    ),

    # Cumulative progressive unfreezing.
    "decoder_input_plus_residual_1": (
        *DECODER_GROUPS["decoder_input"],
        *DECODER_GROUPS["decoder_residual_1"],
    ),

    "decoder_input_plus_residual_1_plus_residual_2": (
        *DECODER_GROUPS["decoder_input"],
        *DECODER_GROUPS["decoder_residual_1"],
        *DECODER_GROUPS["decoder_residual_2"],
    ),

    # Entire Decoder.
    "entire_decoder": (
        *ALL_DECODER_PARAMETER_LAYERS,
    ),

    # Entire model.
    "full_finetune": (
        "__ALL__",
    ),
}


# Default Task 5.1 comparison set.
# The default scan excludes cumulative strategies to limit runtime.
DEFAULT_TASK5_1_STRATEGIES = (
    "no_adaptation",
    "decoder_input_only",
    "decoder_residual_1_only",
    "decoder_residual_2_only",
    "decoder_output_head_only",
    "entire_decoder",
    "full_finetune",
)


def get_strategy_layer_names(
    strategy_name: str,
) -> Sequence[str]:
    """Return the requested layer names for a Task 5.1 strategy."""
    if strategy_name not in TASK5_1_STRATEGIES:
        available = ", ".join(
            sorted(TASK5_1_STRATEGIES)
        )

        raise KeyError(
            f"Unknown Task 5.1 strategy {strategy_name!r}. "
            f"Available strategies: {available}"
        )

    return TASK5_1_STRATEGIES[strategy_name]