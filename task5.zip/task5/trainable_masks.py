"""
Trainable-layer mask utilities for Task 5.

Supports predefined Task 5.1 Decoder strategies and arbitrary Task 5.2 layer
subsets. In Keras, the root model must remain trainable=True while child layers
are frozen or unfrozen; otherwise selected variables may be excluded from
model.trainable_variables.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import tensorflow as tf

from src.task5.decoder_groups import (
    TASK5_1_STRATEGIES,
    get_strategy_layer_names,
)


@dataclass(frozen=True)
class TrainableAudit:
    strategy_name: str
    requested_layer_names: tuple[str, ...]
    actual_trainable_layer_names: tuple[str, ...]
    trainable_parameter_count: int
    frozen_parameter_count: int
    total_parameter_count: int
    trainable_percentage: float


def all_nested_layers(
    model: tf.keras.Model,
) -> List[tf.keras.layers.Layer]:
    """Return the root model and each nested layer exactly once."""
    result: List[tf.keras.layers.Layer] = []
    seen_ids = set()

    def visit(layer: tf.keras.layers.Layer) -> None:
        if id(layer) in seen_ids:
            return

        seen_ids.add(id(layer))
        result.append(layer)

        if isinstance(layer, tf.keras.Model):
            for child in layer.layers:
                visit(child)

    visit(model)

    return result


def child_layers(
    model: tf.keras.Model,
) -> List[tf.keras.layers.Layer]:
    """Return all nested layers except the root model."""
    return [
        layer
        for layer in all_nested_layers(model)
        if layer is not model
    ]


def find_layer_recursive(
    model: tf.keras.Model,
    layer_name: str,
) -> tf.keras.layers.Layer:
    """Find a uniquely named layer in the model."""
    matches = [
        layer
        for layer in child_layers(model)
        if layer.name == layer_name
    ]

    if not matches:
        available_names = sorted(
            {
                layer.name
                for layer in child_layers(model)
            }
        )

        raise ValueError(
            f"Layer {layer_name!r} was not found.\n"
            f"Available layer names:\n{available_names}"
        )

    if len(matches) > 1:
        raise ValueError(
            f"Layer name {layer_name!r} is not unique. "
            f"Found {len(matches)} matching layers."
        )

    return matches[0]


def count_trainable_parameters(
    model: tf.keras.Model,
) -> int:
    return int(
        sum(
            tf.keras.backend.count_params(weight)
            for weight in model.trainable_weights
        )
    )


def count_frozen_parameters(
    model: tf.keras.Model,
) -> int:
    return int(
        sum(
            tf.keras.backend.count_params(weight)
            for weight in model.non_trainable_weights
        )
    )


def trainable_layer_names(
    model: tf.keras.Model,
) -> List[str]:
    """Return trainable child layers that contain parameters."""
    return [
        layer.name
        for layer in child_layers(model)
        if layer.trainable and layer.weights
    ]


def build_trainable_audit(
    model: tf.keras.Model,
    strategy_name: str,
    requested_layers: tuple[str, ...],
) -> TrainableAudit:
    trainable_params = count_trainable_parameters(model)
    frozen_params = count_frozen_parameters(model)
    total_params = trainable_params + frozen_params

    actual_layers = tuple(
        trainable_layer_names(model)
    )

    return TrainableAudit(
        strategy_name=strategy_name,
        requested_layer_names=requested_layers,
        actual_trainable_layer_names=actual_layers,
        trainable_parameter_count=trainable_params,
        frozen_parameter_count=frozen_params,
        total_parameter_count=total_params,
        trainable_percentage=(
            100.0 * trainable_params / total_params
            if total_params > 0
            else 0.0
        ),
    )


def validate_trainable_audit(
    audit: TrainableAudit,
) -> None:
    """Verify that the trainable layers match the requested mask."""
    requested = audit.requested_layer_names
    actual = set(
        audit.actual_trainable_layer_names
    )

    if requested == ("__ALL__",):
        if (
            audit.trainable_parameter_count
            != audit.total_parameter_count
        ):
            raise RuntimeError(
                "Full fine-tuning mask failed: "
                "not all model parameters are trainable."
            )

        return

    expected = set(requested)

    if expected != actual:
        raise RuntimeError(
            f"Incorrect trainable mask for "
            f"{audit.strategy_name!r}.\n"
            f"Expected trainable layers: {sorted(expected)}\n"
            f"Actual trainable layers:   {sorted(actual)}"
        )

    if not requested:
        if audit.trainable_parameter_count != 0:
            raise RuntimeError(
                "An empty trainable-layer request must result "
                "in zero trainable parameters."
            )

    elif audit.trainable_parameter_count == 0:
        raise RuntimeError(
            f"Strategy {audit.strategy_name!r} unexpectedly "
            "has zero trainable parameters."
        )


def apply_named_layer_mask(
    model: tf.keras.Model,
    strategy_name: str,
    requested_layer_names: Sequence[str],
) -> TrainableAudit:
    """
    Apply an arbitrary trainable-layer mask.

    Special cases
    -------------
    requested_layer_names = ():
        Freeze every parameter-bearing child layer.

    requested_layer_names = ("__ALL__",):
        Make the entire model trainable.

    Otherwise:
        Freeze all child layers and unfreeze only the named layers.
    """
    requested_layers = tuple(
        requested_layer_names
    )

    # The root model must remain trainable.
    model.trainable = True

    if requested_layers == ("__ALL__",):
        for layer in child_layers(model):
            layer.trainable = True

    else:
        # Freeze all child layers first.
        for layer in child_layers(model):
            layer.trainable = False

        # Unfreeze only the requested layers.
        for layer_name in requested_layers:
            find_layer_recursive(
                model=model,
                layer_name=layer_name,
            ).trainable = True

    audit = build_trainable_audit(
        model=model,
        strategy_name=strategy_name,
        requested_layers=requested_layers,
    )

    validate_trainable_audit(audit)

    return audit


def apply_trainable_strategy(
    model: tf.keras.Model,
    strategy_name: str,
) -> TrainableAudit:
    """Apply a predefined Task 5.1 strategy."""
    if strategy_name not in TASK5_1_STRATEGIES:
        raise KeyError(
            f"Unknown Task 5.1 strategy {strategy_name!r}. "
            f"Available strategies: "
            f"{sorted(TASK5_1_STRATEGIES)}"
        )

    requested_layers = get_strategy_layer_names(
        strategy_name
    )

    return apply_named_layer_mask(
        model=model,
        strategy_name=strategy_name,
        requested_layer_names=requested_layers,
    )


def print_trainable_audit(
    audit: TrainableAudit,
) -> None:
    print("\n" + "=" * 80)
    print(f"Strategy: {audit.strategy_name}")
    print("=" * 80)

    if audit.actual_trainable_layer_names:
        print(
            "Trainable layers: "
            + ", ".join(
                audit.actual_trainable_layer_names
            )
        )
    else:
        print("Trainable layers: (none)")

    print(
        f"Trainable parameters: "
        f"{audit.trainable_parameter_count:,}"
    )

    print(
        f"Frozen parameters:    "
        f"{audit.frozen_parameter_count:,}"
    )

    print(
        f"Total parameters:     "
        f"{audit.total_parameter_count:,}"
    )

    print(
        f"Trainable percentage: "
        f"{audit.trainable_percentage:.6f}%"
    )