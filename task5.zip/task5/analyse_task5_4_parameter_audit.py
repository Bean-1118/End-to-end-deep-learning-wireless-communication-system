from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def main() -> int:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--input-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task5"
            / "task5_4_parameter_audit"
        ),
    )

    args = parser.parse_args()

    summary_directory = (
        args.input_root
        / "summaries"
    )

    summary_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    # ========================================================
    # Weight-change summary
    # ========================================================

    weight_df = pd.read_csv(
        args.input_root
        / "layer_weight_changes_all.csv"
    )

    weight_summary = (
        weight_df
        .groupby(
            [
                "strategy",
                "layer_name",
            ],
            as_index=False,
        )
        .agg(
            mean_relative_delta_l2=(
                "relative_delta_l2",
                "mean",
            ),
            std_relative_delta_l2=(
                "relative_delta_l2",
                "std",
            ),
            mean_delta_l2=(
                "delta_l2",
                "mean",
            ),
            mean_abs_delta=(
                "mean_abs_delta",
                "mean",
            ),
            max_abs_delta=(
                "max_abs_delta",
                "max",
            ),
            mean_changed_fraction_1e_6=(
                "changed_parameter_fraction_1e_6",
                "mean",
            ),
        )
    )

    weight_summary.to_csv(
        summary_directory
        / "cross_pair_layer_change_summary.csv",
        index=False,
    )

    # ========================================================
    # Gradient summary
    # ========================================================

    gradient_df = pd.read_csv(
        args.input_root
        / "gradient_statistics_all.csv"
    )

    gradient_summary = (
        gradient_df
        .groupby(
            [
                "strategy",
                "layer_name",
            ],
            as_index=False,
        )
        .agg(
            mean_gradient_norm=(
                "mean_gradient_norm",
                "mean",
            ),
            std_gradient_norm=(
                "mean_gradient_norm",
                "std",
            ),
            mean_normalised_gradient=(
                "mean_normalised_gradient",
                "mean",
            ),
            std_normalised_gradient=(
                "mean_normalised_gradient",
                "std",
            ),
            maximum_gradient_norm=(
                "max_gradient_norm",
                "max",
            ),
        )
    )

    gradient_summary.to_csv(
        summary_directory
        / "cross_pair_gradient_summary.csv",
        index=False,
    )

    # ========================================================
    # Revert contribution summary
    # ========================================================

    revert_df = pd.read_csv(
        args.input_root
        / "layer_revert_ablation_all.csv"
    )

    revert_df["positive_target_contribution"] = (
        revert_df["target_ber_loss_after_revert"] > 0
    ).astype(float)

    revert_summary = (
        revert_df
        .groupby(
            [
                "strategy",
                "layer_name",
            ],
            as_index=False,
        )
        .agg(
            mean_revert_target_ber_loss=(
                "target_ber_loss_after_revert",
                "mean",
            ),
            std_revert_target_ber_loss=(
                "target_ber_loss_after_revert",
                "std",
            ),
            median_revert_target_ber_loss=(
                "target_ber_loss_after_revert",
                "median",
            ),
            positive_contribution_fraction=(
                "positive_target_contribution",
                "mean",
            ),
            mean_source_effect_after_revert=(
                "source_ber_change_after_revert",
                "mean",
            ),
        )
    )

    revert_summary.to_csv(
        summary_directory
        / "cross_pair_revert_summary.csv",
        index=False,
    )

    # ========================================================
    # Combined importance table
    # ========================================================

    combined = (
        weight_summary
        .merge(
            gradient_summary,
            on=[
                "strategy",
                "layer_name",
            ],
            how="outer",
        )
        .merge(
            revert_summary,
            on=[
                "strategy",
                "layer_name",
            ],
            how="outer",
        )
    )

    combined.to_csv(
        summary_directory
        / "combined_layer_importance_summary.csv",
        index=False,
    )

    print(
        f"Task 5.4 summaries written to:\n"
        f"{summary_directory}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())