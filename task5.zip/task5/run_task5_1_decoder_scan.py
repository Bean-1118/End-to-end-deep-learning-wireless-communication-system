"""
Task 5.1B: Decoder parameter-localisation experiment.

Run from the project root, for example:

    python3 -m src.task5.run_task5_1_decoder_scan \
        --source-pdp 0 \
        --target-pdp 4 \
        --seeds 2026 \
        --adaptation-blocks 2048 \
        --epochs 20 \
        --learning-rate 1e-4
"""

from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path
from statistics import mean, stdev
from typing import Dict, List

import numpy as np
import tensorflow as tf

from src.base_functions import batch_size, end_to_end
from src.pdp_profiles import get_known_pdps
from src.train_eval import evaluate_ber_single_ebno

from src.task4.checkpoint_utils import (
    restore_task2_checkpoint,
)

from src.task4.fixed_adaptation import (
    compare_weight_snapshots,
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
    snapshot_weights,
)

from src.task5.decoder_groups import (
    DEFAULT_TASK5_1_STRATEGIES,
    TASK5_1_STRATEGIES,
)

from src.task5.trainable_masks import (
    TrainableAudit,
    apply_trainable_strategy,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def deterministic_ber(
    model,
    pdp,
    ebno_linear: float,
    num_test_batches: int,
    seed: int,
) -> float:
    """
    Evaluate BER on a deterministically regenerated test set.

    NumPy and TensorFlow seeds are reset so before/after evaluation uses the
    same bits, channel realisations, and TensorFlow AWGN sequence.
    """
    set_all_seeds(seed)

    return float(
        evaluate_ber_single_ebno(
            model=model,
            pdp_test=pdp,
            ebno_linear=ebno_linear,
            num_test_batches=num_test_batches,
        )
    )


def train_task5_strategy(
    model: tf.keras.Model,
    dataset,
    strategy_name: str,
    epochs: int,
    learning_rate: float,
    seed: int,
    audit: TrainableAudit,
) -> Dict[str, object]:
    """
    Train the selected parameters on the fixed adaptation dataset.

    Uses the Task 5 Decoder masks with the fixed-dataset training loop.
    """
    if audit.trainable_parameter_count == 0:
        raise ValueError(
            f"Strategy {strategy_name!r} has zero trainable parameters."
        )

    set_all_seeds(seed)

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=learning_rate
    )

    losses: List[float] = []
    bers: List[float] = []

    print(f"Strategy: {strategy_name}")

    print(
        "Trainable layers: "
        + ", ".join(
            audit.actual_trainable_layer_names
        )
    )

    print(
        f"Trainable parameters: "
        f"{audit.trainable_parameter_count:,}"
    )

    for epoch in range(epochs):
        epoch_losses: List[float] = []
        epoch_bers: List[float] = []

        for bits, channels, noise_std in iter_fixed_batches(
            dataset=dataset,
            epoch=epoch,
            shuffle_seed=seed + 1000,
        ):
            labels = tf.cast(
                bits,
                tf.float32,
            )

            with tf.GradientTape() as tape:
                logits, probabilities = model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        logits=logits,
                        labels=labels,
                    )
                )

            variables = model.trainable_variables

            gradients = tape.gradient(
                loss,
                variables,
            )

            gradient_variable_pairs = [
                (gradient, variable)
                for gradient, variable
                in zip(gradients, variables)
                if gradient is not None
            ]

            if not gradient_variable_pairs:
                raise RuntimeError(
                    f"No gradients were produced for "
                    f"{strategy_name!r}."
                )

            optimizer.apply_gradients(
                gradient_variable_pairs
            )

            predicted_bits = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predicted_bits != labels,
                    tf.float32,
                )
            )

            loss_value = float(loss.numpy())
            ber_value = float(ber.numpy())

            losses.append(loss_value)
            bers.append(ber_value)

            epoch_losses.append(loss_value)
            epoch_bers.append(ber_value)

        print(
            f"Epoch {epoch + 1}/{epochs} | "
            f"loss={np.mean(epoch_losses):.6f} | "
            f"BER={np.mean(epoch_bers):.6f}"
        )

    return {
        "loss": losses,
        "ber": bers,
        "steps": len(losses),
        "epochs": epochs,
        "batches_per_epoch":
            dataset.num_blocks // batch_size,
    }


def write_csv(
    path: Path,
    rows: List[Dict[str, object]],
) -> None:
    if not rows:
        raise ValueError(
            f"Cannot write an empty CSV to {path}"
        )

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    all_fieldnames: List[str] = []

    for row in rows:
        for key in row:
            if key not in all_fieldnames:
                all_fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=all_fieldnames,
        )

        writer.writeheader()
        writer.writerows(rows)


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Task 5.1 Decoder parameter-localisation scan."
        )
    )

    parser.add_argument(
        "--source-pdp",
        type=int,
        default=0,
    )

    parser.add_argument(
        "--target-pdp",
        type=int,
        default=4,
    )

    parser.add_argument(
        "--strategies",
        nargs="+",
        default=list(
            DEFAULT_TASK5_1_STRATEGIES
        ),
        choices=list(
            TASK5_1_STRATEGIES.keys()
        ),
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[
            2026,
            2027,
            2028,
        ],
    )

    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=2048,
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=1e-4,
    )

    parser.add_argument(
        "--ebno-linear",
        type=float,
        default=20.0,
    )

    parser.add_argument(
        "--test-batches",
        type=int,
        default=100,
    )

    parser.add_argument(
        "--checkpoint-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "checkpoints"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task5"
            / "task5_1_decoder_scan"
        ),
    )

    return parser.parse_args()


def validate_arguments(
    args: argparse.Namespace,
    number_of_pdps: int,
) -> None:
    if not 0 <= args.source_pdp < number_of_pdps:
        raise ValueError(
            f"source-pdp must be between 0 and "
            f"{number_of_pdps - 1}."
        )

    if not 0 <= args.target_pdp < number_of_pdps:
        raise ValueError(
            f"target-pdp must be between 0 and "
            f"{number_of_pdps - 1}."
        )

    if args.source_pdp == args.target_pdp:
        raise ValueError(
            "Task 5.1 requires different source and target PDPs."
        )

    if args.adaptation_blocks <= 0:
        raise ValueError(
            "adaptation-blocks must be positive."
        )

    if args.adaptation_blocks % batch_size != 0:
        raise ValueError(
            "adaptation-blocks must be a multiple of "
            f"batch_size={batch_size}."
        )

    if args.epochs <= 0:
        raise ValueError(
            "epochs must be positive."
        )

    if args.learning_rate <= 0:
        raise ValueError(
            "learning-rate must be positive."
        )

    if args.test_batches <= 0:
        raise ValueError(
            "test-batches must be positive."
        )


def run_one_strategy(
    args: argparse.Namespace,
    source_pdp,
    target_pdp,
    strategy_name: str,
    seed: int,
    dataset,
    seed_directory: Path,
) -> Dict[str, object]:
    """Restore, adapt, and evaluate one Task 5.1 strategy."""
    tf.keras.backend.clear_session()
    gc.collect()
    set_all_seeds(seed)

    model = end_to_end()

    checkpoint_directory = (
        args.checkpoint_root
        / f"model_trained_on_PDP{args.source_pdp}"
    )

    restored_checkpoint = restore_task2_checkpoint(
        model=model,
        checkpoint_dir=checkpoint_directory,
    )

    # Apply the Task 5 mask after checkpoint restoration.
    audit = apply_trainable_strategy(
        model=model,
        strategy_name=strategy_name,
    )

    source_evaluation_seed = 31000 + seed
    target_evaluation_seed = 41000 + seed

    source_ber_before = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_evaluation_seed,
    )

    target_ber_before = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_evaluation_seed,
    )

    weights_before = snapshot_weights(model)

    history = None

    if strategy_name != "no_adaptation":
        history = train_task5_strategy(
            model=model,
            dataset=dataset,
            strategy_name=strategy_name,
            epochs=args.epochs,
            learning_rate=args.learning_rate,
            seed=seed,
            audit=audit,
        )

    target_ber_after = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_evaluation_seed,
    )

    source_ber_after = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_evaluation_seed,
    )

    weight_changes = compare_weight_snapshots(
        model=model,
        before=weights_before,
    )

    changed_weights = [
        row
        for row in weight_changes
        if row["changed"]
    ]

    strategy_directory = (
        seed_directory / strategy_name
    )

    strategy_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    (
        strategy_directory
        / "weight_changes.json"
    ).write_text(
        json.dumps(
            weight_changes,
            indent=2,
        ),
        encoding="utf-8",
    )

    if history is not None:
        (
            strategy_directory
            / "training_history.json"
        ).write_text(
            json.dumps(
                history,
                indent=2,
            ),
            encoding="utf-8",
        )

    result: Dict[str, object] = {
        "source_pdp": args.source_pdp,
        "target_pdp": args.target_pdp,
        "seed": seed,
        "strategy": strategy_name,
        "adaptation_blocks":
            args.adaptation_blocks,
        "epochs": (
            0
            if strategy_name == "no_adaptation"
            else args.epochs
        ),
        "update_steps": (
            0
            if strategy_name == "no_adaptation"
            else (
                args.epochs
                * (
                    args.adaptation_blocks
                    // batch_size
                )
            )
        ),
        "learning_rate": (
            0.0
            if strategy_name == "no_adaptation"
            else args.learning_rate
        ),
        "ebno_linear": args.ebno_linear,
        "test_batches": args.test_batches,
        "requested_trainable_layers":
            "; ".join(
                audit.requested_layer_names
            ),
        "actual_trainable_layers":
            "; ".join(
                audit.actual_trainable_layer_names
            ),
        "trainable_parameters":
            audit.trainable_parameter_count,
        "frozen_parameters":
            audit.frozen_parameter_count,
        "total_parameters":
            audit.total_parameter_count,
        "trainable_percentage":
            audit.trainable_percentage,
        "source_ber_before":
            source_ber_before,
        "source_ber_after":
            source_ber_after,
        "target_ber_before":
            target_ber_before,
        "target_ber_after":
            target_ber_after,
        "target_absolute_improvement": (
            target_ber_before
            - target_ber_after
        ),
        "target_relative_improvement": (
            (
                target_ber_before
                - target_ber_after
            )
            / target_ber_before
            if target_ber_before > 0
            else 0.0
        ),
        "source_ber_change": (
            source_ber_after
            - source_ber_before
        ),
        "changed_weight_tensors":
            len(changed_weights),
        "restored_checkpoint":
            restored_checkpoint,
        "first_training_loss": (
            ""
            if history is None
            else history["loss"][0]
        ),
        "last_training_loss": (
            ""
            if history is None
            else history["loss"][-1]
        ),
        "first_training_ber": (
            ""
            if history is None
            else history["ber"][0]
        ),
        "last_training_ber": (
            ""
            if history is None
            else history["ber"][-1]
        ),
    }

    (
        strategy_directory
        / "result.json"
    ).write_text(
        json.dumps(
            result,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        f"\n{strategy_name}: "
        f"target {target_ber_before:.8f} "
        f"-> {target_ber_after:.8f}; "
        f"source {source_ber_before:.8f} "
        f"-> {source_ber_after:.8f}"
    )

    del model
    tf.keras.backend.clear_session()
    gc.collect()

    return result


def build_summary(
    rows: List[Dict[str, object]],
) -> List[Dict[str, object]]:
    summary_rows: List[Dict[str, object]] = []

    strategy_order = list(
        dict.fromkeys(
            row["strategy"]
            for row in rows
        )
    )

    for strategy_name in strategy_order:
        subset = [
            row
            for row in rows
            if row["strategy"] == strategy_name
        ]

        target_before_values = [
            float(row["target_ber_before"])
            for row in subset
        ]

        target_after_values = [
            float(row["target_ber_after"])
            for row in subset
        ]

        target_improvement_values = [
            float(
                row["target_absolute_improvement"]
            )
            for row in subset
        ]

        source_before_values = [
            float(row["source_ber_before"])
            for row in subset
        ]

        source_after_values = [
            float(row["source_ber_after"])
            for row in subset
        ]

        source_change_values = [
            float(row["source_ber_change"])
            for row in subset
        ]

        summary_rows.append(
            {
                "strategy": strategy_name,
                "num_seeds": len(subset),
                "trainable_parameters":
                    subset[0]["trainable_parameters"],
                "trainable_percentage":
                    subset[0]["trainable_percentage"],
                "mean_target_ber_before":
                    mean(target_before_values),
                "std_target_ber_before": (
                    stdev(target_before_values)
                    if len(target_before_values) > 1
                    else 0.0
                ),
                "mean_target_ber_after":
                    mean(target_after_values),
                "std_target_ber_after": (
                    stdev(target_after_values)
                    if len(target_after_values) > 1
                    else 0.0
                ),
                "mean_target_improvement":
                    mean(target_improvement_values),
                "std_target_improvement": (
                    stdev(target_improvement_values)
                    if len(target_improvement_values) > 1
                    else 0.0
                ),
                "mean_source_ber_before":
                    mean(source_before_values),
                "mean_source_ber_after":
                    mean(source_after_values),
                "mean_source_ber_change":
                    mean(source_change_values),
                "std_source_ber_change": (
                    stdev(source_change_values)
                    if len(source_change_values) > 1
                    else 0.0
                ),
            }
        )

    return summary_rows


def main() -> int:
    args = parse_arguments()

    pdps = get_known_pdps()

    validate_arguments(
        args=args,
        number_of_pdps=len(pdps),
    )

    source_pdp = pdps[args.source_pdp]
    target_pdp = pdps[args.target_pdp]

    experiment_directory = (
        args.output_root
        / (
            f"PDP{args.source_pdp}"
            f"_to_PDP{args.target_pdp}"
        )
        / (
            f"blocks{args.adaptation_blocks}"
            f"__epochs{args.epochs}"
            f"__lr{args.learning_rate:g}"
        )
    )

    experiment_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    config = vars(args).copy()

    config["checkpoint_root"] = str(
        config["checkpoint_root"]
    )

    config["output_root"] = str(
        config["output_root"]
    )

    (
        experiment_directory
        / "config.json"
    ).write_text(
        json.dumps(
            config,
            indent=2,
        ),
        encoding="utf-8",
    )

    result_rows: List[Dict[str, object]] = []

    print("=" * 80)
    print("Task 5.1B — Decoder parameter-localisation scan")
    print("=" * 80)

    print(
        f"Source: PDP{args.source_pdp}"
    )

    print(
        f"Target: PDP{args.target_pdp}"
    )

    print(
        f"Strategies: {args.strategies}"
    )

    for seed in args.seeds:
        print("\n" + "#" * 80)
        print(f"Seed: {seed}")
        print("#" * 80)

        fixed_dataset = make_fixed_adaptation_dataset(
            pdp_target=target_pdp,
            pdp_id=args.target_pdp,
            num_blocks=args.adaptation_blocks,
            ebno_linear=args.ebno_linear,
            seed=seed,
        )

        seed_directory = (
            experiment_directory
            / f"seed_{seed}"
        )

        seed_directory.mkdir(
            parents=True,
            exist_ok=True,
        )

        np.savez_compressed(
            seed_directory
            / "fixed_adaptation_dataset.npz",
            bits=fixed_dataset.bits,
            channels=fixed_dataset.channels,
            noise_std=fixed_dataset.noise_std,
        )

        for strategy_name in args.strategies:
            row = run_one_strategy(
                args=args,
                source_pdp=source_pdp,
                target_pdp=target_pdp,
                strategy_name=strategy_name,
                seed=seed,
                dataset=fixed_dataset,
                seed_directory=seed_directory,
            )

            result_rows.append(row)

            write_csv(
                experiment_directory
                / "raw_results_partial.csv",
                result_rows,
            )

    write_csv(
        experiment_directory
        / "raw_results.csv",
        result_rows,
    )

    summary_rows = build_summary(
        result_rows
    )

    write_csv(
        experiment_directory
        / "summary.csv",
        summary_rows,
    )

    (
        experiment_directory
        / "summary.json"
    ).write_text(
        json.dumps(
            summary_rows,
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTask 5.1B completed successfully.")
    print(f"Results: {experiment_directory}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())