"""
Task 5.3 parameter-group interaction strategies.

P_min:
    decoder_res1_input

P_compact:
    decoder_res1_input
    decoder_res1_conv2

Strategies combine these subsets with other model groups for comparison.
"""

from __future__ import annotations

from typing import Dict, Sequence


# ============================================================
# Core particular candidates from Task 5.2
# ============================================================

P_MIN = (
    "decoder_res1_input",
)

P_COMPACT = (
    "decoder_res1_input",
    "decoder_res1_conv2",
)


# ============================================================
# Decoder parameter groups
# ============================================================

DECODER_INPUT = (
    "decoder_conv_1",
)

RESIDUAL_1 = (
    "decoder_res1_input",
    "decoder_res1_conv1",
    "decoder_res1_conv2",
)

RESIDUAL_2 = (
    "decoder_res2_input",
    "decoder_res2_conv1",
    "decoder_res2_conv2",
)

OUTPUT_HEAD = (
    "decoder_conv_final",
    "pred_logits_full",
)

ENTIRE_DECODER = (
    "decoder_conv_1",

    "decoder_res1_input",
    "decoder_res1_conv1",
    "decoder_res1_conv2",

    "decoder_res2_input",
    "decoder_res2_conv1",
    "decoder_res2_conv2",

    "decoder_conv_final",
    "pred_logits_full",
)


# ============================================================
# Encoder group
# ============================================================

ENCODER = (
    "encoder_conv_1",
    "encoder_conv_2",
    "encoder_conv_3",
    "encoder_conv_4",
)


# ============================================================
# Channel-estimator group
# ============================================================

CHANNEL_ESTIMATOR = (
    "channel_est_conv_1",
    "channel_est_conv_2",
    "channel_est_conv_3",
    "channel_est_conv_4",
    "channel_est_conv_5",
    "channel_est_dense_1",
    "estimated_channel",
)


def combine_unique(
    *groups: Sequence[str],
) -> tuple[str, ...]:
    """Combine layer groups while preserving order and removing duplicates."""
    result: list[str] = []
    seen: set[str] = set()

    for group in groups:
        for layer_name in group:
            if layer_name not in seen:
                seen.add(layer_name)
                result.append(layer_name)

    return tuple(result)


# ============================================================
# Task 5.3 strategies
# ============================================================

TASK5_3_STRATEGIES: Dict[str, tuple[str, ...]] = {
    # --------------------------------------------------------
    # Reference baselines
    # --------------------------------------------------------
    "no_adaptation": (),

    "p_min": P_MIN,

    "p_compact": P_COMPACT,

    "entire_residual_1": RESIDUAL_1,

    "entire_decoder": ENTIRE_DECODER,

    "full_finetune": (
        "__ALL__",
    ),

    # --------------------------------------------------------
    # Decoder-group interaction experiments
    # --------------------------------------------------------
    "p_compact_plus_decoder_input": combine_unique(
        P_COMPACT,
        DECODER_INPUT,
    ),

    "p_compact_plus_residual_2": combine_unique(
        P_COMPACT,
        RESIDUAL_2,
    ),

    "p_compact_plus_output_head": combine_unique(
        P_COMPACT,
        OUTPUT_HEAD,
    ),

    # --------------------------------------------------------
    # Non-decoder interaction experiments
    # --------------------------------------------------------
    "p_compact_plus_encoder": combine_unique(
        P_COMPACT,
        ENCODER,
    ),

    "p_compact_plus_channel_estimator": combine_unique(
        P_COMPACT,
        CHANNEL_ESTIMATOR,
    ),

    "p_compact_plus_encoder_plus_channel_estimator": combine_unique(
        P_COMPACT,
        ENCODER,
        CHANNEL_ESTIMATOR,
    ),

    # --------------------------------------------------------
    # Optional P_min interaction controls
    # --------------------------------------------------------
    "p_min_plus_decoder_input": combine_unique(
        P_MIN,
        DECODER_INPUT,
    ),

    "p_min_plus_residual_2": combine_unique(
        P_MIN,
        RESIDUAL_2,
    ),

    "p_min_plus_channel_estimator": combine_unique(
        P_MIN,
        CHANNEL_ESTIMATOR,
    ),
}


DEFAULT_TASK5_3_STRATEGIES = (
    "no_adaptation",

    "p_min",
    "p_compact",

    "p_compact_plus_decoder_input",
    "p_compact_plus_residual_2",
    "p_compact_plus_output_head",

    "p_compact_plus_encoder",
    "p_compact_plus_channel_estimator",
    "p_compact_plus_encoder_plus_channel_estimator",

    "entire_residual_1",
    "entire_decoder",
    "full_finetune",
)


def get_task5_3_layer_names(
    strategy_name: str,
) -> tuple[str, ...]:
    """Return the requested trainable layers for a Task 5.3 strategy."""
    if strategy_name not in TASK5_3_STRATEGIES:
        raise KeyError(
            f"Unknown Task 5.3 strategy {strategy_name!r}. "
            f"Available strategies: "
            f"{sorted(TASK5_3_STRATEGIES)}"
        )

    return TASK5_3_STRATEGIES[strategy_name]