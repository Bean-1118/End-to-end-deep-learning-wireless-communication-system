"""
Task 5.1A: Decoder structure and trainable-mask audit.

Run from the project root:

    python3 -m src.task5.run_task5_1_structure_audit
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, List

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end
from src.task5.decoder_groups import (
    ALL_DECODER_PARAMETER_LAYERS,
    DECODER_GROUPS,
    TASK5_1_STRATEGIES,
)
from src.task5.trainable_masks import (
    apply_trainable_strategy,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]

OUTPUT_ROOT = (
    PROJECT_ROOT
    / "outputs"
    / "task5"
    / "task5_1_decoder_scan"
)

AUDIT_DIR = OUTPUT_ROOT / "audit"
RESULTS_DIR = OUTPUT_ROOT / "results"


def ensure_output_directories() -> None:
    AUDIT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )


def count_layer_parameters(
    layer: tf.keras.layers.Layer,
) -> int:
    return int(
        sum(
            np.prod(weight.shape)
            for weight in layer.weights
        )
    )


def validate_decoder_structure(
    model: tf.keras.Model,
) -> None:
    available_names = {
        layer.name
        for layer in model.layers
    }

    expected_names = set(
        ALL_DECODER_PARAMETER_LAYERS
    )

    missing = expected_names - available_names

    if missing:
        raise RuntimeError(
            "The model does not contain all expected Decoder layers.\n"
            f"Missing layers: {sorted(missing)}"
        )


def save_model_summary(
    model: tf.keras.Model,
) -> None:
    lines: List[str] = []

    model.summary(
        expand_nested=True,
        show_trainable=True,
        print_fn=lines.append,
    )

    (AUDIT_DIR / "model_summary.txt").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def save_layer_audit(
    model: tf.keras.Model,
) -> None:
    rows: List[Dict[str, object]] = []

    decoder_layer_names = set(
        ALL_DECODER_PARAMETER_LAYERS
    )

    for index, layer in enumerate(model.layers):
        parameter_count = count_layer_parameters(layer)

        try:
            input_shape = str(layer.input.shape)
        except (AttributeError, ValueError):
            input_shape = "unknown"

        try:
            output_shape = str(layer.output.shape)
        except (AttributeError, ValueError):
            output_shape = "unknown"

        rows.append(
            {
                "layer_index": index,
                "layer_name": layer.name,
                "layer_type": type(layer).__name__,
                "parameter_count": parameter_count,
                "has_parameters": parameter_count > 0,
                "is_decoder_parameter_layer":
                    layer.name in decoder_layer_names,
                "input_shape": input_shape,
                "output_shape": output_shape,
            }
        )

    output_path = (
        AUDIT_DIR / "model_layer_audit.csv"
    )

    with output_path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(rows[0].keys()),
        )

        writer.writeheader()
        writer.writerows(rows)


def save_decoder_definition() -> None:
    payload = {
        "decoder_groups": {
            group_name: list(layer_names)
            for group_name, layer_names
            in DECODER_GROUPS.items()
        },
        "all_decoder_parameter_layers": list(
            ALL_DECODER_PARAMETER_LAYERS
        ),
        "task5_1_strategies": {
            strategy_name: list(layer_names)
            for strategy_name, layer_names
            in TASK5_1_STRATEGIES.items()
        },
    }

    (
        AUDIT_DIR / "decoder_groups.json"
    ).write_text(
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )


def audit_all_strategies() -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []

    for strategy_name in TASK5_1_STRATEGIES:
        tf.keras.backend.clear_session()

        model = end_to_end()

        audit = apply_trainable_strategy(
            model=model,
            strategy_name=strategy_name,
        )

        print(
            f"{strategy_name:48s} "
            f"trainable="
            f"{audit.trainable_parameter_count:>10,d} "
            f"({audit.trainable_percentage:8.4f}%)"
        )

        print(
            "  layers: "
            + (
                ", ".join(
                    audit.actual_trainable_layer_names
                )
                if audit.actual_trainable_layer_names
                else "(none)"
            )
        )

        rows.append(
            {
                "strategy": strategy_name,
                "requested_layers": "; ".join(
                    audit.requested_layer_names
                ),
                "actual_trainable_layers": "; ".join(
                    audit.actual_trainable_layer_names
                ),
                "trainable_parameters":
                    audit.trainable_parameter_count,
                "frozen_parameters":
                    audit.frozen_parameter_count,
                "total_parameters":
                    audit.total_parameter_count,
                "trainable_percentage":
                    audit.trainable_percentage,
            }
        )

    return rows


def save_strategy_audit(
    rows: List[Dict[str, object]],
) -> None:
    csv_path = (
        RESULTS_DIR
        / "task5_1_strategy_parameter_counts.csv"
    )

    with csv_path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(rows[0].keys()),
        )

        writer.writeheader()
        writer.writerows(rows)

    json_path = (
        RESULTS_DIR
        / "task5_1_strategy_parameter_counts.json"
    )

    json_path.write_text(
        json.dumps(
            rows,
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )


def main() -> int:
    ensure_output_directories()

    tf.keras.backend.clear_session()

    model = end_to_end()

    validate_decoder_structure(model)
    save_model_summary(model)
    save_layer_audit(model)
    save_decoder_definition()

    print("=" * 80)
    print("Task 5.1A — Decoder structure and trainable-mask audit")
    print("=" * 80)

    rows = audit_all_strategies()
    save_strategy_audit(rows)

    print("\nTask 5.1A completed successfully.")
    print(f"Results written to: {OUTPUT_ROOT}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())