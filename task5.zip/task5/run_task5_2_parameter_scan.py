"""
Task 5.2: Fine-grained particular-parameter identification.

Includes:

Task 5.2A:
    Fine-grained Residual Block 1 decomposition on one PDP pair.

Task 5.2B:
    Cross-PDP validation of a selected compact particular subset.

Examples
--------

Task 5.2A smoke test:

    python3 -m src.task5.run_task5_2_parameter_scan \
        --pairs 0:4 \
        --seeds 2026 \
        --epochs 2 \
        --test-batches 10

Task 5.2A formal run:

    python3 -m src.task5.run_task5_2_parameter_scan \
        --pairs 0:4 \
        --seeds 2026 2027 2028 \
        --adaptation-blocks 2048 \
        --epochs 20 \
        --learning-rate 1e-4 \
        --test-batches 100

Task 5.2B cross-pair validation:

    python3 -m src.task5.run_task5_2_parameter_scan \
        --pairs 0:4 4:0 0:1 2:6 6:2 \
        --strategies \
            no_adaptation \
            res1_conv1_only \
            res1_conv1_plus_conv2 \
            entire_residual_1 \
            entire_decoder \
            full_finetune \
        --seeds 2026 2027 2028 \
        --adaptation-blocks 2048 \
        --epochs 20 \
        --learning-rate 1e-4 \
        --test-batches 100
"""

from __future__ import annotations

import argparse
import csv
import gc
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev
from typing import Dict, List, Sequence, Tuple

import numpy as np
import tensorflow as tf

from src.base_functions import (
    batch_size,
    end_to_end,
)

from src.pdp_profiles import get_known_pdps

from src.train_eval import (
    evaluate_ber_single_ebno,
)

from src.task4.checkpoint_utils import (
    restore_task2_checkpoint,
)

from src.task4.fixed_adaptation import (
    compare_weight_snapshots,
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
    snapshot_weights,
)

from src.task5.task5_2_groups import (
    DEFAULT_TASK5_2A_STRATEGIES,
    TASK5_2_STRATEGIES,
    get_task5_2_layer_names,
)

from src.task5.trainable_masks import (
    TrainableAudit,
    apply_named_layer_mask,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


# ============================================================
# General utilities
# ============================================================

def write_csv(
    path: Path,
    rows: List[Dict[str, object]],
) -> None:
    if not rows:
        raise ValueError(
            f"Cannot write empty CSV: {path}"
        )

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames: List[str] = []

    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(rows)


def safe_mean(
    values: Sequence[float],
) -> float:
    return float(mean(values))


def safe_std(
    values: Sequence[float],
) -> float:
    if len(values) <= 1:
        return 0.0

    return float(stdev(values))


def deterministic_ber(
    model: tf.keras.Model,
    pdp,
    ebno_linear: float,
    num_test_batches: int,
    seed: int,
) -> float:
    """
    Evaluate BER using deterministic random seeds.

    The same seed is used before and after adaptation so both evaluations use
    equivalent random bits, channels, and TensorFlow AWGN.
    """
    set_all_seeds(seed)

    return float(
        evaluate_ber_single_ebno(
            model=model,
            pdp_test=pdp,
            ebno_linear=ebno_linear,
            num_test_batches=num_test_batches,
        )
    )


def parse_pair(
    pair_text: str,
) -> Tuple[int, int]:
    """
    Convert a command-line pair such as '0:4' into (0, 4).
    """
    parts = pair_text.split(":")

    if len(parts) != 2:
        raise argparse.ArgumentTypeError(
            f"Invalid PDP pair {pair_text!r}. "
            f"Expected format SOURCE:TARGET, for example 0:4."
        )

    try:
        source_id = int(parts[0])
        target_id = int(parts[1])

    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"Invalid PDP pair {pair_text!r}. "
            "Both PDP IDs must be integers."
        ) from exc

    if source_id == target_id:
        raise argparse.ArgumentTypeError(
            f"Source and target PDP must differ: {pair_text!r}"
        )

    return source_id, target_id


# ============================================================
# Training
# ============================================================

def train_fixed_dataset_with_mask(
    model: tf.keras.Model,
    dataset,
    strategy_name: str,
    audit: TrainableAudit,
    epochs: int,
    learning_rate: float,
    seed: int,
) -> Dict[str, object]:
    """Train the parameters selected by the Task 5.2 mask on the fixed dataset."""
    if audit.trainable_parameter_count == 0:
        raise ValueError(
            f"Strategy {strategy_name!r} has zero trainable parameters."
        )

    set_all_seeds(seed)

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=learning_rate
    )

    all_losses: List[float] = []
    all_bers: List[float] = []

    epoch_mean_losses: List[float] = []
    epoch_mean_bers: List[float] = []

    print("\n" + "-" * 80)
    print(f"Training strategy: {strategy_name}")
    print(
        "Trainable layers: "
        + ", ".join(
            audit.actual_trainable_layer_names
        )
    )
    print(
        f"Trainable parameters: "
        f"{audit.trainable_parameter_count:,}"
    )
    print("-" * 80)

    for epoch in range(epochs):
        epoch_losses: List[float] = []
        epoch_bers: List[float] = []

        for bits, channels, noise_std in iter_fixed_batches(
            dataset=dataset,
            epoch=epoch,
            shuffle_seed=seed + 1000,
        ):
            labels = tf.cast(
                bits,
                tf.float32,
            )

            with tf.GradientTape() as tape:
                logits, probabilities = model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        logits=logits,
                        labels=labels,
                    )
                )

            trainable_variables = model.trainable_variables

            gradients = tape.gradient(
                loss,
                trainable_variables,
            )

            gradient_variable_pairs = [
                (gradient, variable)
                for gradient, variable
                in zip(
                    gradients,
                    trainable_variables,
                )
                if gradient is not None
            ]

            if not gradient_variable_pairs:
                raise RuntimeError(
                    f"No gradients were produced for "
                    f"strategy {strategy_name!r}."
                )

            optimizer.apply_gradients(
                gradient_variable_pairs
            )

            predicted_bits = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predicted_bits != labels,
                    tf.float32,
                )
            )

            loss_value = float(
                loss.numpy()
            )

            ber_value = float(
                ber.numpy()
            )

            all_losses.append(loss_value)
            all_bers.append(ber_value)

            epoch_losses.append(loss_value)
            epoch_bers.append(ber_value)

        mean_epoch_loss = float(
            np.mean(epoch_losses)
        )

        mean_epoch_ber = float(
            np.mean(epoch_bers)
        )

        epoch_mean_losses.append(
            mean_epoch_loss
        )

        epoch_mean_bers.append(
            mean_epoch_ber
        )

        print(
            f"Epoch {epoch + 1}/{epochs} | "
            f"loss={mean_epoch_loss:.6f} | "
            f"BER={mean_epoch_ber:.6f}"
        )

    return {
        "loss": all_losses,
        "ber": all_bers,
        "epoch_mean_loss": epoch_mean_losses,
        "epoch_mean_ber": epoch_mean_bers,
        "steps": len(all_losses),
        "epochs": epochs,
        "batches_per_epoch":
            dataset.num_blocks // batch_size,
    }


# ============================================================
# One strategy on one pair and seed
# ============================================================

def run_one_experiment(
    args: argparse.Namespace,
    source_id: int,
    target_id: int,
    source_pdp,
    target_pdp,
    strategy_name: str,
    seed: int,
    dataset,
    pair_seed_directory: Path,
) -> Dict[str, object]:
    tf.keras.backend.clear_session()
    gc.collect()

    set_all_seeds(seed)

    model = end_to_end()

    checkpoint_directory = (
        args.checkpoint_root
        / f"model_trained_on_PDP{source_id}"
    )

    restored_checkpoint = restore_task2_checkpoint(
        model=model,
        checkpoint_dir=checkpoint_directory,
    )

    requested_layers = get_task5_2_layer_names(
        strategy_name
    )

    audit = apply_named_layer_mask(
        model=model,
        strategy_name=strategy_name,
        requested_layer_names=requested_layers,
    )

    # Pair- and training-seed values generate distinct test realisations
    # for different PDP pairs.
    pair_code = source_id * 100 + target_id

    source_eval_seed = (
        31000
        + seed
        + pair_code * 10
    )

    target_eval_seed = (
        41000
        + seed
        + pair_code * 10
    )

    source_ber_before = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_eval_seed,
    )

    target_ber_before = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_eval_seed,
    )

    weights_before = snapshot_weights(
        model
    )

    training_history = None

    if strategy_name != "no_adaptation":
        training_history = train_fixed_dataset_with_mask(
            model=model,
            dataset=dataset,
            strategy_name=strategy_name,
            audit=audit,
            epochs=args.epochs,
            learning_rate=args.learning_rate,
            seed=seed,
        )

    target_ber_after = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_eval_seed,
    )

    source_ber_after = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_eval_seed,
    )

    weight_changes = compare_weight_snapshots(
        model=model,
        before=weights_before,
    )

    changed_weights = [
        row
        for row in weight_changes
        if row["changed"]
    ]

    strategy_directory = (
        pair_seed_directory
        / strategy_name
    )

    strategy_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    (
        strategy_directory
        / "weight_changes.json"
    ).write_text(
        json.dumps(
            weight_changes,
            indent=2,
        ),
        encoding="utf-8",
    )

    if training_history is not None:
        (
            strategy_directory
            / "training_history.json"
        ).write_text(
            json.dumps(
                training_history,
                indent=2,
            ),
            encoding="utf-8",
        )

    result: Dict[str, object] = {
        "source_pdp": source_id,
        "target_pdp": target_id,
        "seed": seed,
        "strategy": strategy_name,

        "adaptation_blocks":
            args.adaptation_blocks,

        "epochs": (
            0
            if strategy_name == "no_adaptation"
            else args.epochs
        ),

        "update_steps": (
            0
            if strategy_name == "no_adaptation"
            else (
                args.epochs
                * (
                    args.adaptation_blocks
                    // batch_size
                )
            )
        ),

        "learning_rate": (
            0.0
            if strategy_name == "no_adaptation"
            else args.learning_rate
        ),

        "ebno_linear":
            args.ebno_linear,

        "test_batches":
            args.test_batches,

        "requested_trainable_layers":
            "; ".join(
                audit.requested_layer_names
            ),

        "actual_trainable_layers":
            "; ".join(
                audit.actual_trainable_layer_names
            ),

        "trainable_parameters":
            audit.trainable_parameter_count,

        "frozen_parameters":
            audit.frozen_parameter_count,

        "total_parameters":
            audit.total_parameter_count,

        "trainable_percentage":
            audit.trainable_percentage,

        "source_ber_before":
            source_ber_before,

        "source_ber_after":
            source_ber_after,

        "target_ber_before":
            target_ber_before,

        "target_ber_after":
            target_ber_after,

        "target_absolute_improvement": (
            target_ber_before
            - target_ber_after
        ),

        "target_relative_improvement": (
            (
                target_ber_before
                - target_ber_after
            )
            / target_ber_before
            if target_ber_before > 0
            else 0.0
        ),

        "source_ber_change": (
            source_ber_after
            - source_ber_before
        ),

        "changed_weight_tensors":
            len(changed_weights),

        "restored_checkpoint":
            restored_checkpoint,

        "first_training_loss": (
            ""
            if training_history is None
            else training_history["loss"][0]
        ),

        "last_training_loss": (
            ""
            if training_history is None
            else training_history["loss"][-1]
        ),

        "first_training_ber": (
            ""
            if training_history is None
            else training_history["ber"][0]
        ),

        "last_training_ber": (
            ""
            if training_history is None
            else training_history["ber"][-1]
        ),
    }

    (
        strategy_directory
        / "result.json"
    ).write_text(
        json.dumps(
            result,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        f"\nPDP{source_id}->PDP{target_id} | "
        f"{strategy_name} | "
        f"target: {target_ber_before:.8f} "
        f"-> {target_ber_after:.8f} | "
        f"source: {source_ber_before:.8f} "
        f"-> {source_ber_after:.8f}"
    )

    del model
    tf.keras.backend.clear_session()
    gc.collect()

    return result


# ============================================================
# Recovery-ratio calculation
# ============================================================

def add_recovery_metrics(
    rows: List[Dict[str, object]],
) -> None:
    """
    Add full-finetune and entire-decoder recovery ratios for each
    source-PDP, target-PDP, and seed combination.

    Full-finetune recovery ratio:
        (BER_no_adapt - BER_candidate)
        /
        (BER_no_adapt - BER_full_finetune)

    Decoder recovery ratio:
        (BER_no_adapt - BER_candidate)
        /
        (BER_no_adapt - BER_entire_decoder)
    """
    grouped_rows = defaultdict(list)

    for row in rows:
        key = (
            int(row["source_pdp"]),
            int(row["target_pdp"]),
            int(row["seed"]),
        )

        grouped_rows[key].append(row)

    for key, subset in grouped_rows.items():
        by_strategy = {
            str(row["strategy"]): row
            for row in subset
        }

        required = {
            "no_adaptation",
            "entire_decoder",
            "full_finetune",
        }

        missing = required - set(
            by_strategy
        )

        if missing:
            raise RuntimeError(
                f"Cannot calculate recovery metrics for "
                f"group {key}. Missing strategies: {sorted(missing)}"
            )

        no_adapt_ber = float(
            by_strategy[
                "no_adaptation"
            ]["target_ber_after"]
        )

        full_ber = float(
            by_strategy[
                "full_finetune"
            ]["target_ber_after"]
        )

        decoder_ber = float(
            by_strategy[
                "entire_decoder"
            ]["target_ber_after"]
        )

        full_denominator = (
            no_adapt_ber - full_ber
        )

        decoder_denominator = (
            no_adapt_ber - decoder_ber
        )

        for row in subset:
            candidate_ber = float(
                row["target_ber_after"]
            )

            candidate_improvement = (
                no_adapt_ber
                - candidate_ber
            )

            row["recovery_ratio_full"] = (
                candidate_improvement
                / full_denominator
                if full_denominator > 0
                else 0.0
            )

            row["recovery_ratio_decoder"] = (
                candidate_improvement
                / decoder_denominator
                if decoder_denominator > 0
                else 0.0
            )

            trainable_params = int(
                row["trainable_parameters"]
            )

            row[
                "improvement_per_100k_parameters"
            ] = (
                candidate_improvement
                / (
                    trainable_params / 100000.0
                )
                if trainable_params > 0
                else 0.0
            )


# ============================================================
# Summaries
# ============================================================

def build_pair_strategy_summary(
    rows: List[Dict[str, object]],
) -> List[Dict[str, object]]:
    """
    Summarise results for each source-target pair and strategy.
    """
    grouped = defaultdict(list)

    for row in rows:
        key = (
            int(row["source_pdp"]),
            int(row["target_pdp"]),
            str(row["strategy"]),
        )

        grouped[key].append(row)

    summary_rows: List[Dict[str, object]] = []

    for (
        source_id,
        target_id,
        strategy_name,
    ), subset in sorted(grouped.items()):

        target_after = [
            float(row["target_ber_after"])
            for row in subset
        ]

        target_improvement = [
            float(
                row["target_absolute_improvement"]
            )
            for row in subset
        ]

        source_change = [
            float(row["source_ber_change"])
            for row in subset
        ]

        recovery_full = [
            float(row["recovery_ratio_full"])
            for row in subset
        ]

        recovery_decoder = [
            float(row["recovery_ratio_decoder"])
            for row in subset
        ]

        parameter_efficiency = [
            float(
                row[
                    "improvement_per_100k_parameters"
                ]
            )
            for row in subset
        ]

        summary_rows.append(
            {
                "source_pdp": source_id,
                "target_pdp": target_id,
                "strategy": strategy_name,
                "num_seeds": len(subset),

                "trainable_parameters":
                    subset[0][
                        "trainable_parameters"
                    ],

                "trainable_percentage":
                    subset[0][
                        "trainable_percentage"
                    ],

                "mean_target_ber_after":
                    safe_mean(target_after),

                "std_target_ber_after":
                    safe_std(target_after),

                "mean_target_improvement":
                    safe_mean(target_improvement),

                "std_target_improvement":
                    safe_std(target_improvement),

                "mean_source_ber_change":
                    safe_mean(source_change),

                "std_source_ber_change":
                    safe_std(source_change),

                "mean_recovery_ratio_full":
                    safe_mean(recovery_full),

                "std_recovery_ratio_full":
                    safe_std(recovery_full),

                "mean_recovery_ratio_decoder":
                    safe_mean(recovery_decoder),

                "std_recovery_ratio_decoder":
                    safe_std(recovery_decoder),

                "mean_improvement_per_100k_parameters":
                    safe_mean(parameter_efficiency),
            }
        )

    return summary_rows


def build_cross_pair_summary(
    pair_summary_rows: List[Dict[str, object]],
) -> List[Dict[str, object]]:
    """
    Summarise each strategy across all source-target PDP pairs.
    """
    grouped = defaultdict(list)

    for row in pair_summary_rows:
        grouped[
            str(row["strategy"])
        ].append(row)

    cross_pair_rows: List[Dict[str, object]] = []

    for strategy_name, subset in sorted(
        grouped.items()
    ):
        target_ber_values = [
            float(row["mean_target_ber_after"])
            for row in subset
        ]

        improvement_values = [
            float(row["mean_target_improvement"])
            for row in subset
        ]

        source_change_values = [
            float(row["mean_source_ber_change"])
            for row in subset
        ]

        full_recovery_values = [
            float(row["mean_recovery_ratio_full"])
            for row in subset
        ]

        decoder_recovery_values = [
            float(
                row["mean_recovery_ratio_decoder"]
            )
            for row in subset
        ]

        efficiency_values = [
            float(
                row[
                    "mean_improvement_per_100k_parameters"
                ]
            )
            for row in subset
        ]

        positive_pair_count = sum(
            1
            for value in improvement_values
            if value > 0
        )

        cross_pair_rows.append(
            {
                "strategy": strategy_name,
                "num_pairs": len(subset),

                "trainable_parameters":
                    subset[0][
                        "trainable_parameters"
                    ],

                "trainable_percentage":
                    subset[0][
                        "trainable_percentage"
                    ],

                "mean_target_ber_across_pairs":
                    safe_mean(target_ber_values),

                "mean_target_improvement_across_pairs":
                    safe_mean(improvement_values),

                "mean_source_ber_change_across_pairs":
                    safe_mean(source_change_values),

                "mean_full_recovery_ratio_across_pairs":
                    safe_mean(full_recovery_values),

                "std_full_recovery_ratio_across_pairs":
                    safe_std(full_recovery_values),

                "mean_decoder_recovery_ratio_across_pairs":
                    safe_mean(decoder_recovery_values),

                "mean_parameter_efficiency_across_pairs":
                    safe_mean(efficiency_values),

                "positive_improvement_pair_count":
                    positive_pair_count,

                "positive_improvement_pair_fraction": (
                    positive_pair_count
                    / len(subset)
                ),
            }
        )

    return cross_pair_rows


# ============================================================
# Command-line arguments
# ============================================================

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Task 5.2 fine-grained particular-parameter scan."
        )
    )

    parser.add_argument(
        "--pairs",
        nargs="+",
        type=parse_pair,
        default=[
            (0, 4),
        ],
        help=(
            "Source-target PDP pairs in SOURCE:TARGET format. "
            "Example: --pairs 0:4 4:0 2:6"
        ),
    )

    parser.add_argument(
        "--strategies",
        nargs="+",
        default=list(
            DEFAULT_TASK5_2A_STRATEGIES
        ),
        choices=list(
            TASK5_2_STRATEGIES.keys()
        ),
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[
            2026,
            2027,
            2028,
        ],
    )

    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=2048,
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=1e-4,
    )

    parser.add_argument(
        "--ebno-linear",
        type=float,
        default=20.0,
    )

    parser.add_argument(
        "--test-batches",
        type=int,
        default=100,
    )

    parser.add_argument(
        "--checkpoint-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "checkpoints"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task5"
            / "task5_2_parameter_scan"
        ),
    )

    return parser.parse_args()


def validate_arguments(
    args: argparse.Namespace,
    number_of_pdps: int,
) -> None:
    for source_id, target_id in args.pairs:
        if not 0 <= source_id < number_of_pdps:
            raise ValueError(
                f"Invalid source PDP: {source_id}. "
                f"Expected 0 to {number_of_pdps - 1}."
            )

        if not 0 <= target_id < number_of_pdps:
            raise ValueError(
                f"Invalid target PDP: {target_id}. "
                f"Expected 0 to {number_of_pdps - 1}."
            )

        if source_id == target_id:
            raise ValueError(
                f"Source and target PDP must differ: "
                f"PDP{source_id}->PDP{target_id}"
            )

    if args.adaptation_blocks <= 0:
        raise ValueError(
            "adaptation-blocks must be positive."
        )

    if (
        args.adaptation_blocks
        % batch_size
        != 0
    ):
        raise ValueError(
            "adaptation-blocks must be a multiple of "
            f"batch_size={batch_size}."
        )

    if args.epochs <= 0:
        raise ValueError(
            "epochs must be positive."
        )

    if args.learning_rate <= 0:
        raise ValueError(
            "learning-rate must be positive."
        )

    if args.ebno_linear <= 0:
        raise ValueError(
            "ebno-linear must be positive."
        )

    if args.test_batches <= 0:
        raise ValueError(
            "test-batches must be positive."
        )

    required_reference_strategies = {
        "no_adaptation",
        "entire_decoder",
        "full_finetune",
    }

    missing = (
        required_reference_strategies
        - set(args.strategies)
    )

    if missing:
        raise ValueError(
            "The following reference strategies are required "
            "for recovery-ratio calculation: "
            f"{sorted(missing)}"
        )


# ============================================================
# Main
# ============================================================

def main() -> int:
    args = parse_arguments()

    pdps = get_known_pdps()

    validate_arguments(
        args=args,
        number_of_pdps=len(pdps),
    )

    pair_label = "__".join(
        f"PDP{source_id}_to_PDP{target_id}"
        for source_id, target_id
        in args.pairs
    )

    experiment_directory = (
        args.output_root
        / pair_label
        / (
            f"blocks{args.adaptation_blocks}"
            f"__epochs{args.epochs}"
            f"__lr{args.learning_rate:g}"
        )
    )

    experiment_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    config = vars(args).copy()

    config["pairs"] = [
        {
            "source_pdp": source_id,
            "target_pdp": target_id,
        }
        for source_id, target_id
        in args.pairs
    ]

    config["checkpoint_root"] = str(
        args.checkpoint_root
    )

    config["output_root"] = str(
        args.output_root
    )

    (
        experiment_directory
        / "config.json"
    ).write_text(
        json.dumps(
            config,
            indent=2,
        ),
        encoding="utf-8",
    )

    all_rows: List[Dict[str, object]] = []

    print("=" * 80)
    print(
        "Task 5.2 — Fine-grained particular-parameter scan"
    )
    print("=" * 80)

    print(
        "Pairs: "
        + ", ".join(
            f"PDP{source}->PDP{target}"
            for source, target
            in args.pairs
        )
    )

    print(
        "Strategies: "
        + ", ".join(
            args.strategies
        )
    )

    for source_id, target_id in args.pairs:
        source_pdp = pdps[source_id]
        target_pdp = pdps[target_id]

        pair_directory = (
            experiment_directory
            / (
                f"PDP{source_id}"
                f"_to_PDP{target_id}"
            )
        )

        for seed in args.seeds:
            print("\n" + "#" * 80)
            print(
                f"Pair: PDP{source_id}->PDP{target_id} | "
                f"Seed: {seed}"
            )
            print("#" * 80)

            # Use a pair-dependent seed for independent fixed adaptation sets.
            dataset_seed = (
                seed
                + source_id * 1000
                + target_id * 100
            )

            fixed_dataset = make_fixed_adaptation_dataset(
                pdp_target=target_pdp,
                pdp_id=target_id,
                num_blocks=args.adaptation_blocks,
                ebno_linear=args.ebno_linear,
                seed=dataset_seed,
            )

            pair_seed_directory = (
                pair_directory
                / f"seed_{seed}"
            )

            pair_seed_directory.mkdir(
                parents=True,
                exist_ok=True,
            )

            np.savez_compressed(
                pair_seed_directory
                / "fixed_adaptation_dataset.npz",
                bits=fixed_dataset.bits,
                channels=fixed_dataset.channels,
                noise_std=fixed_dataset.noise_std,
            )

            for strategy_name in args.strategies:
                row = run_one_experiment(
                    args=args,
                    source_id=source_id,
                    target_id=target_id,
                    source_pdp=source_pdp,
                    target_pdp=target_pdp,
                    strategy_name=strategy_name,
                    seed=seed,
                    dataset=fixed_dataset,
                    pair_seed_directory=
                        pair_seed_directory,
                )

                all_rows.append(row)

                write_csv(
                    experiment_directory
                    / "raw_results_partial.csv",
                    all_rows,
                )

    add_recovery_metrics(
        all_rows
    )

    write_csv(
        experiment_directory
        / "raw_results.csv",
        all_rows,
    )

    pair_summary_rows = (
        build_pair_strategy_summary(
            all_rows
        )
    )

    write_csv(
        experiment_directory
        / "pair_strategy_summary.csv",
        pair_summary_rows,
    )

    (
        experiment_directory
        / "pair_strategy_summary.json"
    ).write_text(
        json.dumps(
            pair_summary_rows,
            indent=2,
        ),
        encoding="utf-8",
    )

    cross_pair_summary_rows = (
        build_cross_pair_summary(
            pair_summary_rows
        )
    )

    write_csv(
        experiment_directory
        / "cross_pair_summary.csv",
        cross_pair_summary_rows,
    )

    (
        experiment_directory
        / "cross_pair_summary.json"
    ).write_text(
        json.dumps(
            cross_pair_summary_rows,
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTask 5.2 completed successfully.")
    print(
        f"Results written to:\n"
        f"{experiment_directory}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())