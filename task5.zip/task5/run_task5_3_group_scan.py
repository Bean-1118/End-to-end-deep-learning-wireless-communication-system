"""
Task 5.3: Parameter-group interaction experiment.

This experiment tests whether adding another model group to the
Task 5.2 compact particular subset produces stable additional
cross-PDP adaptation benefit.

Example smoke test:

    python3 -m src.task5.run_task5_3_group_scan \
        --pairs 0:4 \
        --seeds 2026 \
        --adaptation-blocks 2048 \
        --epochs 2 \
        --test-batches 10

Formal experiment:

    python3 -m src.task5.run_task5_3_group_scan \
        --pairs 0:1 0:4 2:6 4:0 6:2 \
        --seeds 2026 2027 2028 \
        --adaptation-blocks 2048 \
        --epochs 20 \
        --learning-rate 1e-4 \
        --ebno-linear 20 \
        --test-batches 100
"""

from __future__ import annotations

import argparse
import gc
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import tensorflow as tf

from src.base_functions import (
    batch_size,
    end_to_end,
)

from src.pdp_profiles import get_known_pdps

from src.task4.checkpoint_utils import (
    restore_task2_checkpoint,
)

from src.task4.fixed_adaptation import (
    compare_weight_snapshots,
    make_fixed_adaptation_dataset,
    set_all_seeds,
    snapshot_weights,
)

from src.task5.task5_3_groups import (
    DEFAULT_TASK5_3_STRATEGIES,
    TASK5_3_STRATEGIES,
    get_task5_3_layer_names,
)

from src.task5.trainable_masks import (
    apply_named_layer_mask,
)

# Task 5.2 experiment utilities.
from src.task5.run_task5_2_parameter_scan import (
    add_recovery_metrics,
    build_cross_pair_summary,
    build_pair_strategy_summary,
    deterministic_ber,
    parse_pair,
    train_fixed_dataset_with_mask,
    write_csv,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


# ============================================================
# One experiment
# ============================================================

def run_one_task5_3_experiment(
    args: argparse.Namespace,
    source_id: int,
    target_id: int,
    source_pdp,
    target_pdp,
    strategy_name: str,
    seed: int,
    fixed_dataset,
    pair_seed_directory: Path,
) -> Dict[str, object]:
    """Run one strategy for one source-target pair and random seed."""
    tf.keras.backend.clear_session()
    gc.collect()

    set_all_seeds(seed)

    model = end_to_end()

    checkpoint_directory = (
        args.checkpoint_root
        / f"model_trained_on_PDP{source_id}"
    )

    restored_checkpoint = restore_task2_checkpoint(
        model=model,
        checkpoint_dir=checkpoint_directory,
    )

    requested_layers = get_task5_3_layer_names(
        strategy_name
    )

    audit = apply_named_layer_mask(
        model=model,
        strategy_name=strategy_name,
        requested_layer_names=requested_layers,
    )

    # Pair-dependent deterministic evaluation seeds.
    pair_code = source_id * 100 + target_id

    source_eval_seed = (
        51000
        + seed
        + pair_code * 10
    )

    target_eval_seed = (
        61000
        + seed
        + pair_code * 10
    )

    source_ber_before = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_eval_seed,
    )

    target_ber_before = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_eval_seed,
    )

    weights_before = snapshot_weights(
        model
    )

    training_history = None

    if strategy_name != "no_adaptation":
        training_history = train_fixed_dataset_with_mask(
            model=model,
            dataset=fixed_dataset,
            strategy_name=strategy_name,
            audit=audit,
            epochs=args.epochs,
            learning_rate=args.learning_rate,
            seed=seed,
        )

    target_ber_after = deterministic_ber(
        model=model,
        pdp=target_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=target_eval_seed,
    )

    source_ber_after = deterministic_ber(
        model=model,
        pdp=source_pdp,
        ebno_linear=args.ebno_linear,
        num_test_batches=args.test_batches,
        seed=source_eval_seed,
    )

    weight_changes = compare_weight_snapshots(
        model=model,
        before=weights_before,
    )

    changed_weights = [
        row
        for row in weight_changes
        if row["changed"]
    ]

    strategy_directory = (
        pair_seed_directory
        / strategy_name
    )

    strategy_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    (
        strategy_directory
        / "weight_changes.json"
    ).write_text(
        json.dumps(
            weight_changes,
            indent=2,
        ),
        encoding="utf-8",
    )

    if training_history is not None:
        (
            strategy_directory
            / "training_history.json"
        ).write_text(
            json.dumps(
                training_history,
                indent=2,
            ),
            encoding="utf-8",
        )

    result: Dict[str, object] = {
        "source_pdp": source_id,
        "target_pdp": target_id,
        "seed": seed,
        "strategy": strategy_name,

        "adaptation_blocks":
            args.adaptation_blocks,

        "epochs": (
            0
            if strategy_name == "no_adaptation"
            else args.epochs
        ),

        "update_steps": (
            0
            if strategy_name == "no_adaptation"
            else (
                args.epochs
                * (
                    args.adaptation_blocks
                    // batch_size
                )
            )
        ),

        "learning_rate": (
            0.0
            if strategy_name == "no_adaptation"
            else args.learning_rate
        ),

        "ebno_linear":
            args.ebno_linear,

        "test_batches":
            args.test_batches,

        "requested_trainable_layers":
            "; ".join(
                audit.requested_layer_names
            ),

        "actual_trainable_layers":
            "; ".join(
                audit.actual_trainable_layer_names
            ),

        "trainable_parameters":
            audit.trainable_parameter_count,

        "frozen_parameters":
            audit.frozen_parameter_count,

        "total_parameters":
            audit.total_parameter_count,

        "trainable_percentage":
            audit.trainable_percentage,

        "source_ber_before":
            source_ber_before,

        "source_ber_after":
            source_ber_after,

        "target_ber_before":
            target_ber_before,

        "target_ber_after":
            target_ber_after,

        "target_absolute_improvement": (
            target_ber_before
            - target_ber_after
        ),

        "target_relative_improvement": (
            (
                target_ber_before
                - target_ber_after
            )
            / target_ber_before
            if target_ber_before > 0
            else 0.0
        ),

        "source_ber_change": (
            source_ber_after
            - source_ber_before
        ),

        "changed_weight_tensors":
            len(changed_weights),

        "restored_checkpoint":
            str(restored_checkpoint),

        "first_training_loss": (
            ""
            if training_history is None
            else training_history["loss"][0]
        ),

        "last_training_loss": (
            ""
            if training_history is None
            else training_history["loss"][-1]
        ),

        "first_training_ber": (
            ""
            if training_history is None
            else training_history["ber"][0]
        ),

        "last_training_ber": (
            ""
            if training_history is None
            else training_history["ber"][-1]
        ),
    }

    (
        strategy_directory
        / "result.json"
    ).write_text(
        json.dumps(
            result,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        f"\nPDP{source_id}->PDP{target_id} | "
        f"{strategy_name} | "
        f"target: {target_ber_before:.8f} "
        f"-> {target_ber_after:.8f} | "
        f"source: {source_ber_before:.8f} "
        f"-> {source_ber_after:.8f}"
    )

    del model

    tf.keras.backend.clear_session()
    gc.collect()

    return result


# ============================================================
# Arguments
# ============================================================

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Task 5.3 parameter-group interaction experiment."
        )
    )

    parser.add_argument(
        "--pairs",
        nargs="+",
        type=parse_pair,
        default=[
            (0, 1),
            (0, 4),
            (2, 6),
            (4, 0),
            (6, 2),
        ],
        help=(
            "PDP pairs in SOURCE:TARGET format. "
            "Example: --pairs 0:1 0:4 2:6 4:0 6:2"
        ),
    )

    parser.add_argument(
        "--strategies",
        nargs="+",
        default=list(
            DEFAULT_TASK5_3_STRATEGIES
        ),
        choices=sorted(
            TASK5_3_STRATEGIES.keys()
        ),
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[
            2026,
            2027,
            2028,
        ],
    )

    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=2048,
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=1e-4,
    )

    parser.add_argument(
        "--ebno-linear",
        type=float,
        default=20.0,
    )

    parser.add_argument(
        "--test-batches",
        type=int,
        default=100,
    )

    parser.add_argument(
        "--checkpoint-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "checkpoints"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task5"
            / "task5_3_group_scan"
            / "experiments"
        ),
    )

    return parser.parse_args()


def validate_arguments(
    args: argparse.Namespace,
    number_of_pdps: int,
) -> None:
    for source_id, target_id in args.pairs:
        if not 0 <= source_id < number_of_pdps:
            raise ValueError(
                f"Invalid source PDP: {source_id}."
            )

        if not 0 <= target_id < number_of_pdps:
            raise ValueError(
                f"Invalid target PDP: {target_id}."
            )

        if source_id == target_id:
            raise ValueError(
                "Source PDP and target PDP must differ."
            )

    if args.adaptation_blocks <= 0:
        raise ValueError(
            "adaptation-blocks must be positive."
        )

    if args.adaptation_blocks % batch_size != 0:
        raise ValueError(
            "adaptation-blocks must be a multiple of "
            f"batch_size={batch_size}."
        )

    if args.epochs <= 0:
        raise ValueError(
            "epochs must be positive."
        )

    if args.learning_rate <= 0:
        raise ValueError(
            "learning-rate must be positive."
        )

    if args.test_batches <= 0:
        raise ValueError(
            "test-batches must be positive."
        )

    required_reference_strategies = {
        "no_adaptation",
        "entire_decoder",
        "full_finetune",
    }

    missing = (
        required_reference_strategies
        - set(args.strategies)
    )

    if missing:
        raise ValueError(
            "These strategies are required for recovery metrics: "
            f"{sorted(missing)}"
        )


# ============================================================
# Main
# ============================================================

def main() -> int:
    args = parse_arguments()

    pdps = get_known_pdps()

    validate_arguments(
        args=args,
        number_of_pdps=len(pdps),
    )

    pair_label = "__".join(
        f"PDP{source_id}_to_PDP{target_id}"
        for source_id, target_id
        in args.pairs
    )

    experiment_directory = (
        args.output_root
        / pair_label
        / (
            f"blocks{args.adaptation_blocks}"
            f"__epochs{args.epochs}"
            f"__lr{args.learning_rate:g}"
        )
    )

    experiment_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    config = vars(args).copy()

    config["pairs"] = [
        {
            "source_pdp": source_id,
            "target_pdp": target_id,
        }
        for source_id, target_id
        in args.pairs
    ]

    config["checkpoint_root"] = str(
        args.checkpoint_root
    )

    config["output_root"] = str(
        args.output_root
    )

    (
        experiment_directory
        / "config.json"
    ).write_text(
        json.dumps(
            config,
            indent=2,
        ),
        encoding="utf-8",
    )

    all_rows: List[Dict[str, object]] = []

    print("=" * 80)
    print("Task 5.3 — Parameter-group interaction experiment")
    print("=" * 80)

    print(
        "Pairs: "
        + ", ".join(
            f"PDP{source}->PDP{target}"
            for source, target
            in args.pairs
        )
    )

    print(
        "Strategies: "
        + ", ".join(
            args.strategies
        )
    )

    for source_id, target_id in args.pairs:
        source_pdp = pdps[source_id]
        target_pdp = pdps[target_id]

        pair_directory = (
            experiment_directory
            / f"PDP{source_id}_to_PDP{target_id}"
        )

        for seed in args.seeds:
            print("\n" + "#" * 80)
            print(
                f"Pair: PDP{source_id}->PDP{target_id} | "
                f"Seed: {seed}"
            )
            print("#" * 80)

            dataset_seed = (
                seed
                + source_id * 1000
                + target_id * 100
            )

            fixed_dataset = make_fixed_adaptation_dataset(
                pdp_target=target_pdp,
                pdp_id=target_id,
                num_blocks=args.adaptation_blocks,
                ebno_linear=args.ebno_linear,
                seed=dataset_seed,
            )

            pair_seed_directory = (
                pair_directory
                / f"seed_{seed}"
            )

            pair_seed_directory.mkdir(
                parents=True,
                exist_ok=True,
            )

            np.savez_compressed(
                pair_seed_directory
                / "fixed_adaptation_dataset.npz",
                bits=fixed_dataset.bits,
                channels=fixed_dataset.channels,
                noise_std=fixed_dataset.noise_std,
            )

            for strategy_name in args.strategies:
                row = run_one_task5_3_experiment(
                    args=args,
                    source_id=source_id,
                    target_id=target_id,
                    source_pdp=source_pdp,
                    target_pdp=target_pdp,
                    strategy_name=strategy_name,
                    seed=seed,
                    fixed_dataset=fixed_dataset,
                    pair_seed_directory=pair_seed_directory,
                )

                all_rows.append(row)

                write_csv(
                    experiment_directory
                    / "raw_results_partial.csv",
                    all_rows,
                )

    add_recovery_metrics(
        all_rows
    )

    write_csv(
        experiment_directory
        / "raw_results.csv",
        all_rows,
    )

    pair_summary_rows = build_pair_strategy_summary(
        all_rows
    )

    write_csv(
        experiment_directory
        / "pair_strategy_summary.csv",
        pair_summary_rows,
    )

    (
        experiment_directory
        / "pair_strategy_summary.json"
    ).write_text(
        json.dumps(
            pair_summary_rows,
            indent=2,
        ),
        encoding="utf-8",
    )

    cross_pair_summary_rows = build_cross_pair_summary(
        pair_summary_rows
    )

    write_csv(
        experiment_directory
        / "cross_pair_summary.csv",
        cross_pair_summary_rows,
    )

    (
        experiment_directory
        / "cross_pair_summary.json"
    ).write_text(
        json.dumps(
            cross_pair_summary_rows,
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTask 5.3 completed successfully.")
    print(
        f"Results written to:\n"
        f"{experiment_directory}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())