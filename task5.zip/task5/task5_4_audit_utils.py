from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Sequence

import numpy as np
import tensorflow as tf

from src.base_functions import batch_size
from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    set_all_seeds,
)


EPSILON = 1e-12


# ============================================================
# Weight snapshots
# ============================================================

def snapshot_layer_weights(
    model: tf.keras.Model,
) -> Dict[str, List[np.ndarray]]:
    """
    Copy the weights of each parameter-bearing layer.

    Returned format:
        {
            "layer_name": [
                kernel_array,
                bias_array,
                ...
            ]
        }
    """
    snapshots: Dict[str, List[np.ndarray]] = {}

    for layer in model.layers:
        if not layer.weights:
            continue

        snapshots[layer.name] = [
            np.asarray(weight.numpy()).copy()
            for weight in layer.weights
        ]

    return snapshots


def restore_layer_weights(
    model: tf.keras.Model,
    snapshots: Mapping[str, Sequence[np.ndarray]],
    layer_names: Iterable[str] | None = None,
) -> None:
    """
    Restore complete layer weights from a snapshot.
    """
    selected = (
        set(layer_names)
        if layer_names is not None
        else set(snapshots)
    )

    for layer_name in selected:
        if layer_name not in snapshots:
            raise KeyError(
                f"No saved weights for layer {layer_name!r}."
            )

        layer = model.get_layer(layer_name)
        saved = snapshots[layer_name]

        if len(layer.weights) != len(saved):
            raise ValueError(
                f"Weight-count mismatch for {layer_name}: "
                f"model={len(layer.weights)}, saved={len(saved)}"
            )

        for variable, value in zip(layer.weights, saved):
            variable.assign(value)


def calculate_layer_weight_changes(
    model: tf.keras.Model,
    before: Mapping[str, Sequence[np.ndarray]],
    source_pdp: int,
    target_pdp: int,
    seed: int,
    strategy: str,
) -> List[Dict[str, object]]:
    """
    Calculate tensor-level weight-change metrics.
    """
    rows: List[Dict[str, object]] = []

    for layer in model.layers:
        if layer.name not in before:
            continue

        old_values = before[layer.name]

        for tensor_index, (variable, old_value) in enumerate(
            zip(layer.weights, old_values)
        ):
            new_value = np.asarray(variable.numpy())
            delta = new_value - old_value

            old_l2 = float(np.linalg.norm(old_value.ravel(), ord=2))
            new_l2 = float(np.linalg.norm(new_value.ravel(), ord=2))
            delta_l2 = float(np.linalg.norm(delta.ravel(), ord=2))

            rows.append({
                "source_pdp": source_pdp,
                "target_pdp": target_pdp,
                "seed": seed,
                "strategy": strategy,

                "layer_name": layer.name,
                "tensor_index": tensor_index,
                "weight_name": getattr(
                    variable,
                    "path",
                    variable.name,
                ),
                "shape": str(tuple(variable.shape)),
                "parameter_count": int(np.prod(variable.shape)),

                "weight_l2_before": old_l2,
                "weight_l2_after": new_l2,
                "delta_l2": delta_l2,

                "relative_delta_l2": (
                    delta_l2 / (old_l2 + EPSILON)
                ),

                "mean_abs_delta": float(
                    np.mean(np.abs(delta))
                ),

                "max_abs_delta": float(
                    np.max(np.abs(delta))
                ),

                "changed_parameter_fraction_1e_8": float(
                    np.mean(np.abs(delta) > 1e-8)
                ),

                "changed_parameter_fraction_1e_6": float(
                    np.mean(np.abs(delta) > 1e-6)
                ),
            })

    return rows


# ============================================================
# Gradient accumulation
# ============================================================

@dataclass
class GradientAccumulator:
    step_count: int
    raw_norms: Dict[str, List[float]]
    normalised_norms: Dict[str, List[float]]

    @classmethod
    def create(cls) -> "GradientAccumulator":
        return cls(
            step_count=0,
            raw_norms=defaultdict(list),
            normalised_norms=defaultdict(list),
        )

    def update(
        self,
        variables: Sequence[tf.Variable],
        gradients: Sequence[tf.Tensor | None],
    ) -> None:
        """Accumulate one global gradient norm per layer for each step."""
        grouped_gradients: Dict[str, List[tf.Tensor]] = defaultdict(list)
        grouped_variables: Dict[str, List[tf.Tensor]] = defaultdict(list)

        for variable, gradient in zip(variables, gradients):
            if gradient is None:
                continue

            variable_path = getattr(
                variable,
                "path",
                variable.name,
            )

            layer_name = variable_path.split("/")[0]

            grouped_gradients[layer_name].append(
                tf.cast(gradient, tf.float32)
            )

            grouped_variables[layer_name].append(
                tf.cast(variable, tf.float32)
            )

        for layer_name, layer_gradients in grouped_gradients.items():
            gradient_norm = float(
                tf.linalg.global_norm(layer_gradients).numpy()
            )

            weight_norm = float(
                tf.linalg.global_norm(
                    grouped_variables[layer_name]
                ).numpy()
            )

            normalised = gradient_norm / (
                weight_norm + EPSILON
            )

            self.raw_norms[layer_name].append(
                gradient_norm
            )

            self.normalised_norms[layer_name].append(
                normalised
            )

        self.step_count += 1

    def to_rows(
        self,
        source_pdp: int,
        target_pdp: int,
        seed: int,
        strategy: str,
    ) -> List[Dict[str, object]]:
        rows: List[Dict[str, object]] = []

        for layer_name in sorted(self.raw_norms):
            raw = np.asarray(
                self.raw_norms[layer_name],
                dtype=np.float64,
            )

            normalised = np.asarray(
                self.normalised_norms[layer_name],
                dtype=np.float64,
            )

            rows.append({
                "source_pdp": source_pdp,
                "target_pdp": target_pdp,
                "seed": seed,
                "strategy": strategy,
                "layer_name": layer_name,

                "num_gradient_steps": int(raw.size),

                "mean_gradient_norm": float(np.mean(raw)),
                "median_gradient_norm": float(np.median(raw)),
                "std_gradient_norm": float(np.std(raw)),
                "max_gradient_norm": float(np.max(raw)),
                "min_gradient_norm": float(np.min(raw)),

                "mean_normalised_gradient": float(
                    np.mean(normalised)
                ),

                "median_normalised_gradient": float(
                    np.median(normalised)
                ),

                "max_normalised_gradient": float(
                    np.max(normalised)
                ),
            })

        return rows


# ============================================================
# Training with gradient audit
# ============================================================

def train_with_gradient_audit(
    model: tf.keras.Model,
    dataset,
    epochs: int,
    learning_rate: float,
    seed: int,
) -> tuple[Dict[str, object], GradientAccumulator]:
    """Train on the fixed dataset and collect gradient statistics."""
    if not model.trainable_variables:
        raise ValueError(
            "Model has no trainable variables."
        )

    set_all_seeds(seed)

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=learning_rate
    )

    accumulator = GradientAccumulator.create()

    losses: List[float] = []
    bers: List[float] = []
    epoch_losses: List[float] = []
    epoch_bers: List[float] = []

    for epoch in range(epochs):
        current_losses: List[float] = []
        current_bers: List[float] = []

        for bits, channels, noise_std in iter_fixed_batches(
            dataset=dataset,
            epoch=epoch,
            shuffle_seed=seed + 1000,
        ):
            labels = tf.cast(bits, tf.float32)

            with tf.GradientTape() as tape:
                logits, probabilities = model(
                    [bits, channels, noise_std],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        logits=logits,
                        labels=labels,
                    )
                )

            variables = model.trainable_variables
            gradients = tape.gradient(
                loss,
                variables,
            )

            accumulator.update(
                variables=variables,
                gradients=gradients,
            )

            gradient_variable_pairs = [
                (gradient, variable)
                for gradient, variable
                in zip(gradients, variables)
                if gradient is not None
            ]

            if not gradient_variable_pairs:
                raise RuntimeError(
                    "No gradients were produced."
                )

            optimizer.apply_gradients(
                gradient_variable_pairs
            )

            predicted = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predicted != labels,
                    tf.float32,
                )
            )

            loss_value = float(loss.numpy())
            ber_value = float(ber.numpy())

            losses.append(loss_value)
            bers.append(ber_value)

            current_losses.append(loss_value)
            current_bers.append(ber_value)

        epoch_loss = float(np.mean(current_losses))
        epoch_ber = float(np.mean(current_bers))

        epoch_losses.append(epoch_loss)
        epoch_bers.append(epoch_ber)

        print(
            f"Epoch {epoch + 1}/{epochs} | "
            f"loss={epoch_loss:.6f} | "
            f"BER={epoch_ber:.6f}"
        )

    history = {
        "loss": losses,
        "ber": bers,
        "epoch_loss": epoch_losses,
        "epoch_ber": epoch_bers,
        "epochs": epochs,
        "steps": len(losses),
        "batches_per_epoch": (
            dataset.num_blocks // batch_size
        ),
    }

    return history, accumulator