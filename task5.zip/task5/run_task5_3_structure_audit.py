"""
Audit trainable-layer masks and parameter counts for Task 5.3 strategies.

No model training is performed.
"""

from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List

import tensorflow as tf

from src.base_functions import end_to_end

from src.task5.task5_3_groups import (
    DEFAULT_TASK5_3_STRATEGIES,
    TASK5_3_STRATEGIES,
    get_task5_3_layer_names,
)

from src.task5.trainable_masks import (
    apply_named_layer_mask,
    print_trainable_audit,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def serialise_audit(
    audit,
) -> Dict[str, object]:
    row = asdict(audit)

    row["requested_layer_names"] = "; ".join(
        row["requested_layer_names"]
    )

    row["actual_trainable_layer_names"] = "; ".join(
        row["actual_trainable_layer_names"]
    )

    return row


def write_csv(
    path: Path,
    rows: List[Dict[str, object]],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    if not rows:
        raise ValueError("No audit rows were generated.")

    fieldnames = list(rows[0].keys())

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    output_directory = (
        PROJECT_ROOT
        / "outputs"
        / "task5"
        / "task5_3_group_scan"
        / "audit"
    )

    output_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    rows: List[Dict[str, object]] = []

    print("=" * 80)
    print("Task 5.3 — Parameter-group structure audit")
    print("=" * 80)

    for strategy_name in DEFAULT_TASK5_3_STRATEGIES:
        tf.keras.backend.clear_session()

        model = end_to_end()

        requested_layers = get_task5_3_layer_names(
            strategy_name
        )

        audit = apply_named_layer_mask(
            model=model,
            strategy_name=strategy_name,
            requested_layer_names=requested_layers,
        )

        print_trainable_audit(audit)

        rows.append(
            serialise_audit(audit)
        )

    write_csv(
        output_directory
        / "task5_3_strategy_parameter_counts.csv",
        rows,
    )

    (
        output_directory
        / "task5_3_strategy_parameter_counts.json"
    ).write_text(
        json.dumps(
            rows,
            indent=2,
        ),
        encoding="utf-8",
    )

    (
        output_directory
        / "task5_3_strategy_definitions.json"
    ).write_text(
        json.dumps(
            {
                strategy_name: list(layer_names)
                for strategy_name, layer_names
                in TASK5_3_STRATEGIES.items()
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTask 5.3 audit completed.")
    print(f"Results written to:\n{output_directory}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())