
from __future__ import annotations

import inspect
import tensorflow as tf

from src import base_functions as bf


def build_original_model() -> tf.keras.Model:
    """Build the model defined in src/base_functions.py."""
    if not hasattr(bf, "end_to_end"):
        raise AttributeError(
            "src.base_functions does not expose end_to_end(). "
            "Update build_original_model() to call the actual model builder."
        )

    builder = bf.end_to_end
    try:
        model = builder()
    except TypeError as exc:
        signature = inspect.signature(builder)
        raise TypeError(
            "end_to_end() requires arguments. Edit only "
            "src/task4/model_factory.py and copy the exact arguments used "
            "by the existing Task 1/Task 2 runner. "
            f"Detected signature: end_to_end{signature}"
        ) from exc

    if not isinstance(model, tf.keras.Model):
        raise TypeError(
            f"end_to_end() returned {type(model)!r}, not tf.keras.Model."
        )
    return model
