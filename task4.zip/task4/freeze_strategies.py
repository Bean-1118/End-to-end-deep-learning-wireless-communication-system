from __future__ import annotations

from typing import Dict, List, Sequence
import tensorflow as tf


STRATEGY_LAYER_NAMES: Dict[str, Sequence[str]] = {
    "no_adaptation": (),
    "dense_head": (
        "channel_est_dense_1",
        "estimated_channel",
    ),
    "channel_extractor": (
        "channel_est_conv_1",
        "channel_est_conv_2",
        "channel_est_conv_3",
        "channel_est_conv_4",
        "channel_est_conv_5",
        "channel_est_dense_1",
        "estimated_channel",
    ),
    "decoder_conv1": (
        "decoder_conv_1",
    ),
    "full_finetune": ("__ALL__",),
    "channel_conv_backbone": (
        "channel_est_conv_1",
        "channel_est_conv_2",
        "channel_est_conv_3",
        "channel_est_conv_4",
        "channel_est_conv_5",
    ),
    "encoder_output": (
        "encoder_conv_4",
    ),
    "final_decision_head": (
        "decoder_conv_final",
        "pred_logits_full",
    ),
}


def _all_nested_layers(model: tf.keras.Model) -> List[tf.keras.layers.Layer]:
    """Return all nested layers once, including the root model."""
    result: List[tf.keras.layers.Layer] = []
    seen = set()

    def visit(layer: tf.keras.layers.Layer) -> None:
        if id(layer) in seen:
            return
        seen.add(id(layer))
        result.append(layer)
        if isinstance(layer, tf.keras.Model):
            for child in layer.layers:
                visit(child)

    visit(model)
    return result


def _child_layers(model: tf.keras.Model) -> List[tf.keras.layers.Layer]:
    """Return all layers except the root model itself."""
    return [
        layer
        for layer in _all_nested_layers(model)
        if layer is not model
    ]


def find_layer_recursive(
    model: tf.keras.Model,
    layer_name: str,
) -> tf.keras.layers.Layer:
    matches = [
        layer
        for layer in _child_layers(model)
        if layer.name == layer_name
    ]

    if not matches:
        available = sorted({layer.name for layer in _child_layers(model)})
        raise ValueError(
            f"Layer {layer_name!r} was not found. "
            f"Available layer names include: {available}"
        )

    if len(matches) > 1:
        raise ValueError(
            f"Layer name {layer_name!r} is not unique: "
            f"{len(matches)} matches."
        )

    return matches[0]


def apply_freeze_strategy(
    model: tf.keras.Model,
    strategy_name: str,
) -> None:
    """
    Apply the selected partial-training strategy.

    The root model remains trainable so selected child-layer weights are
    included in model.trainable_weights.
    """
    if strategy_name not in STRATEGY_LAYER_NAMES:
        raise KeyError(
            f"Unknown strategy {strategy_name!r}. "
            f"Choose from {sorted(STRATEGY_LAYER_NAMES)}"
        )

    selected = STRATEGY_LAYER_NAMES[strategy_name]

    if selected == ("__ALL__",):
        model.trainable = True
        for layer in _child_layers(model):
            layer.trainable = True
        return

    # Keep the root model trainable so selected child variables are visible.
    model.trainable = True

    # Freeze every child layer first.
    for layer in _child_layers(model):
        layer.trainable = False

    # No-adaptation means all child layers stay frozen.
    if strategy_name == "no_adaptation":
        return

    # Unfreeze only the selected child layers.
    for layer_name in selected:
        find_layer_recursive(model, layer_name).trainable = True


def count_trainable_parameters(model: tf.keras.Model) -> int:
    return int(
        sum(
            tf.keras.backend.count_params(weight)
            for weight in model.trainable_weights
        )
    )


def count_non_trainable_parameters(model: tf.keras.Model) -> int:
    return int(
        sum(
            tf.keras.backend.count_params(weight)
            for weight in model.non_trainable_weights
        )
    )


def trainable_layer_names(model: tf.keras.Model) -> List[str]:
    return [
        layer.name
        for layer in _child_layers(model)
        if layer.trainable and layer.weights
    ]