from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]

STRATEGY_ORDER = [
    "no_adaptation",
    "dense_head",
    "channel_extractor",
    "decoder_conv1",
    "full_finetune",
    "scratch",
]

PARTIAL_STRATEGIES = [
    "dense_head",
    "channel_extractor",
    "decoder_conv1",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Task 4.5: produce the final cross-pair statistical summary "
            "from Task 4.4 combined results."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task4_adaptation"
            / "04_multi_pair_analysis"
            / "combined_pair_strategy_results.csv"
        ),
        help="Task 4.4 combined_pair_strategy_results.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=(
            PROJECT_ROOT
            / "outputs"
            / "task4_adaptation"
            / "05_cross_pair_statistical_summary"
        ),
        help="Directory for Task 4.5 outputs.",
    )
    return parser.parse_args()


def validate_input(df: pd.DataFrame) -> None:
    required = {
        "pair",
        "strategy",
        "strategy_display",
        "trainable_parameters",
        "trainable_parameter_fraction",
        "mean_target_ber_after",
        "std_target_ber_after",
        "absolute_target_improvement_recomputed",
        "relative_target_improvement",
        "oracle_recovery_ratio",
        "mean_source_ber_change",
        "improvement_per_100k_parameters",
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            "Input file is missing required columns: "
            f"{sorted(missing)}"
        )

    if df.duplicated(subset=["pair", "strategy"]).any():
        raise ValueError(
            "Input contains duplicate pair-strategy rows."
        )

    expected_pairs = df["pair"].nunique()
    strategy_pair_counts = df.groupby("strategy")["pair"].nunique()
    incomplete = strategy_pair_counts[
        strategy_pair_counts != expected_pairs
    ]
    if not incomplete.empty:
        raise ValueError(
            "Not every strategy is present for every pair: "
            f"{incomplete.to_dict()}"
        )


def sample_std(series: pd.Series) -> float:
    if len(series) <= 1:
        return 0.0
    return float(series.std(ddof=1))


def sem(series: pd.Series) -> float:
    if len(series) <= 1:
        return 0.0
    return float(series.std(ddof=1) / np.sqrt(len(series)))


def rank_within_pairs(df: pd.DataFrame) -> pd.DataFrame:
    ranked = df.copy()

    # Lower target BER is better.
    ranked["rank_target_ber"] = ranked.groupby("pair")[
        "mean_target_ber_after"
    ].rank(method="average", ascending=True)

    # Higher target recovery is better.
    ranked["rank_oracle_recovery"] = ranked.groupby("pair")[
        "oracle_recovery_ratio"
    ].rank(method="average", ascending=False)

    # Lower source forgetting is better.
    ranked["rank_source_retention"] = ranked.groupby("pair")[
        "mean_source_ber_change"
    ].rank(method="average", ascending=True)

    # Parameter efficiency is ranked only for trainable transfer strategies.
    ranked["rank_parameter_efficiency"] = np.nan
    efficiency_mask = (
        ranked["trainable_parameters"].gt(0)
        & ~ranked["strategy"].eq("scratch")
    )
    ranked.loc[efficiency_mask, "rank_parameter_efficiency"] = (
        ranked.loc[efficiency_mask]
        .groupby("pair")["improvement_per_100k_parameters"]
        .rank(method="average", ascending=False)
    )

    # Rank only the three restricted fine-tuning strategies in this comparison.
    ranked["rank_partial_target_ber"] = np.nan
    partial_mask = ranked["strategy"].isin(PARTIAL_STRATEGIES)
    ranked.loc[partial_mask, "rank_partial_target_ber"] = (
        ranked.loc[partial_mask]
        .groupby("pair")["mean_target_ber_after"]
        .rank(method="average", ascending=True)
    )

    return ranked


def build_cross_pair_summary(ranked: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for strategy, group in ranked.groupby("strategy", sort=False):
        rows.append(
            {
                "strategy": strategy,
                "strategy_display": group[
                    "strategy_display"
                ].iloc[0],
                "num_pairs": int(group["pair"].nunique()),
                "trainable_parameters": int(
                    group["trainable_parameters"].iloc[0]
                ),
                "trainable_parameter_fraction": float(
                    group["trainable_parameter_fraction"].iloc[0]
                ),
                "mean_target_ber": float(
                    group["mean_target_ber_after"].mean()
                ),
                "std_target_ber_across_pairs": sample_std(
                    group["mean_target_ber_after"]
                ),
                "sem_target_ber_across_pairs": sem(
                    group["mean_target_ber_after"]
                ),
                "mean_absolute_target_improvement": float(
                    group[
                        "absolute_target_improvement_recomputed"
                    ].mean()
                ),
                "std_absolute_target_improvement": sample_std(
                    group[
                        "absolute_target_improvement_recomputed"
                    ]
                ),
                "mean_relative_target_improvement": float(
                    group["relative_target_improvement"].mean()
                ),
                "mean_oracle_recovery_ratio": float(
                    group["oracle_recovery_ratio"].mean()
                ),
                "std_oracle_recovery_ratio": sample_std(
                    group["oracle_recovery_ratio"]
                ),
                "mean_source_forgetting": float(
                    group["mean_source_ber_change"].mean()
                ),
                "std_source_forgetting": sample_std(
                    group["mean_source_ber_change"]
                ),
                "mean_improvement_per_100k_parameters": float(
                    group["improvement_per_100k_parameters"]
                    .replace([np.inf, -np.inf], np.nan)
                    .mean()
                ),
                "mean_target_ber_rank": float(
                    group["rank_target_ber"].mean()
                ),
                "mean_oracle_recovery_rank": float(
                    group["rank_oracle_recovery"].mean()
                ),
                "mean_source_retention_rank": float(
                    group["rank_source_retention"].mean()
                ),
                "mean_parameter_efficiency_rank": float(
                    group["rank_parameter_efficiency"].mean()
                ),
                "mean_partial_target_rank": float(
                    group["rank_partial_target_ber"].mean()
                ),
            }
        )

    summary = pd.DataFrame(rows)
    order_map = {
        strategy: index
        for index, strategy in enumerate(STRATEGY_ORDER)
    }
    summary["_order"] = summary["strategy"].map(
        order_map
    ).fillna(999)
    return (
        summary.sort_values("_order")
        .drop(columns="_order")
        .reset_index(drop=True)
    )


def add_recommendation_labels(
    summary: pd.DataFrame,
) -> pd.DataFrame:
    output = summary.copy()
    output["role_in_conclusion"] = ""

    transfer_trainable = output[
        output["strategy"].isin(
            [
                "dense_head",
                "channel_extractor",
                "decoder_conv1",
                "full_finetune",
            ]
        )
    ]

    best_target = transfer_trainable.sort_values(
        "mean_target_ber"
    ).iloc[0]["strategy"]

    partial = output[
        output["strategy"].isin(PARTIAL_STRATEGIES)
    ]
    best_partial = partial.sort_values(
        "mean_partial_target_rank"
    ).iloc[0]["strategy"]

    efficient_partial = partial.sort_values(
        "mean_improvement_per_100k_parameters",
        ascending=False,
    ).iloc[0]["strategy"]

    output.loc[
        output["strategy"] == best_target,
        "role_in_conclusion",
    ] = "Best overall Target BER"

    output.loc[
        output["strategy"] == best_partial,
        "role_in_conclusion",
    ] = (
        output.loc[
            output["strategy"] == best_partial,
            "role_in_conclusion",
        ]
        .replace("", "Best partial adaptation")
        .astype(str)
    )

    output.loc[
        output["strategy"] == efficient_partial,
        "role_in_conclusion",
    ] = output.loc[
        output["strategy"] == efficient_partial,
        "role_in_conclusion",
    ].apply(
        lambda value: (
            f"{value}; Best partial parameter efficiency"
            if value
            else "Best partial parameter efficiency"
        )
    )

    output.loc[
        output["strategy"] == "no_adaptation",
        "role_in_conclusion",
    ] = "Deployment baseline"

    output.loc[
        output["strategy"] == "scratch",
        "role_in_conclusion",
    ] = "Limited-data training-from-scratch control"

    return output


def pareto_frontier(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    minimize_x: bool,
    maximize_y: bool,
) -> pd.Series:
    """Return True for rows on the recovery-forgetting Pareto frontier."""
    is_pareto = []

    for index, row in df.iterrows():
        dominated = False
        for other_index, other in df.iterrows():
            if index == other_index:
                continue

            x_better_or_equal = (
                other[x_col] <= row[x_col]
                if minimize_x
                else other[x_col] >= row[x_col]
            )
            y_better_or_equal = (
                other[y_col] >= row[y_col]
                if maximize_y
                else other[y_col] <= row[y_col]
            )

            x_strictly_better = (
                other[x_col] < row[x_col]
                if minimize_x
                else other[x_col] > row[x_col]
            )
            y_strictly_better = (
                other[y_col] > row[y_col]
                if maximize_y
                else other[y_col] < row[y_col]
            )

            if (
                x_better_or_equal
                and y_better_or_equal
                and (
                    x_strictly_better
                    or y_strictly_better
                )
            ):
                dominated = True
                break

        is_pareto.append(not dominated)

    return pd.Series(is_pareto, index=df.index)


def save_average_rank_plot(
    summary: pd.DataFrame,
    output_path: Path,
) -> None:
    plot_df = summary[
        ~summary["strategy"].eq("scratch")
    ].sort_values("mean_target_ber_rank")

    fig, ax = plt.subplots(figsize=(9, 6))
    ax.bar(
        plot_df["strategy_display"],
        plot_df["mean_target_ber_rank"],
    )
    ax.set_title("Average Target-BER rank across PDP pairs")
    ax.set_xlabel("Adaptation strategy")
    ax.set_ylabel("Average rank (lower is better)")
    ax.set_ylim(0, max(6, plot_df["mean_target_ber_rank"].max() + 0.5))
    ax.grid(axis="y", alpha=0.3)
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_mean_recovery_plot(
    summary: pd.DataFrame,
    output_path: Path,
) -> None:
    plot_df = summary[
        summary["strategy"].isin(
            [
                "dense_head",
                "channel_extractor",
                "decoder_conv1",
                "full_finetune",
            ]
        )
    ].sort_values("mean_oracle_recovery_ratio")

    fig, ax = plt.subplots(figsize=(9, 6))
    ax.barh(
        plot_df["strategy_display"],
        plot_df["mean_oracle_recovery_ratio"],
        xerr=plot_df["std_oracle_recovery_ratio"],
        capsize=4,
    )
    ax.set_title("Mean oracle recovery across PDP pairs")
    ax.set_xlabel("Oracle recovery ratio")
    ax.set_ylabel("Adaptation strategy")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_mean_forgetting_plot(
    summary: pd.DataFrame,
    output_path: Path,
) -> None:
    plot_df = summary[
        summary["strategy"].isin(
            [
                "dense_head",
                "channel_extractor",
                "decoder_conv1",
                "full_finetune",
            ]
        )
    ].sort_values("mean_source_forgetting")

    fig, ax = plt.subplots(figsize=(9, 6))
    ax.barh(
        plot_df["strategy_display"],
        plot_df["mean_source_forgetting"],
        xerr=plot_df["std_source_forgetting"],
        capsize=4,
    )
    ax.set_title("Mean source forgetting across PDP pairs")
    ax.set_xlabel("Mean Source BER change (lower is better)")
    ax.set_ylabel("Adaptation strategy")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_summary_tradeoff_plot(
    summary: pd.DataFrame,
    output_path: Path,
) -> None:
    plot_df = summary[
        summary["strategy"].isin(
            [
                "dense_head",
                "channel_extractor",
                "decoder_conv1",
                "full_finetune",
            ]
        )
    ].copy()

    plot_df["pareto_optimal"] = pareto_frontier(
        plot_df,
        x_col="mean_source_forgetting",
        y_col="mean_oracle_recovery_ratio",
        minimize_x=True,
        maximize_y=True,
    )

    fig, ax = plt.subplots(figsize=(9, 7))

    for _, row in plot_df.iterrows():
        marker_size = (
            180 if row["pareto_optimal"] else 90
        )
        ax.scatter(
            row["mean_source_forgetting"],
            row["mean_oracle_recovery_ratio"],
            s=marker_size,
        )
        ax.annotate(
            row["strategy_display"],
            (
                row["mean_source_forgetting"],
                row["mean_oracle_recovery_ratio"],
            ),
            xytext=(6, 6),
            textcoords="offset points",
        )

    ax.set_title(
        "Cross-pair recovery versus forgetting summary"
    )
    ax.set_xlabel(
        "Mean Source BER change (lower is better)"
    )
    ax.set_ylabel(
        "Mean oracle recovery ratio (higher is better)"
    )
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def build_markdown_report(
    summary: pd.DataFrame,
    num_pairs: int,
) -> str:
    transfer = summary[
        summary["strategy"].isin(
            [
                "dense_head",
                "channel_extractor",
                "decoder_conv1",
                "full_finetune",
            ]
        )
    ]

    best_overall = transfer.sort_values(
        "mean_target_ber"
    ).iloc[0]
    best_partial = summary[
        summary["strategy"].isin(PARTIAL_STRATEGIES)
    ].sort_values(
        "mean_partial_target_rank"
    ).iloc[0]
    best_efficiency = summary[
        summary["strategy"].isin(PARTIAL_STRATEGIES)
    ].sort_values(
        "mean_improvement_per_100k_parameters",
        ascending=False,
    ).iloc[0]

    lines = [
        "# Task 4.5 — Cross-Pair Statistical Summary",
        "",
        f"Number of Source-to-Target pairs: **{num_pairs}**",
        "",
        "## Main findings",
        "",
        (
            f"- **{best_overall['strategy_display']}** achieved the "
            "lowest mean Target BER across the selected PDP pairs "
            f"({best_overall['mean_target_ber']:.6f})."
        ),
        (
            f"- **{best_partial['strategy_display']}** was the "
            "highest-ranked partial adaptation strategy, with a "
            f"mean partial-strategy rank of "
            f"{best_partial['mean_partial_target_rank']:.2f}."
        ),
        (
            f"- **{best_efficiency['strategy_display']}** provided "
            "the strongest mean Target-BER improvement per 100,000 "
            "trainable parameters among the partial strategies "
            f"({best_efficiency['mean_improvement_per_100k_parameters']:.6f})."
        ),
        (
            "- Full fine-tuning should be reported as the best "
            "Target-performance strategy, while restricted decoder "
            "adaptation should be reported as the preferred "
            "parameter-efficient strategy."
        ),
        (
            "- Source forgetting must be discussed alongside Target "
            "recovery; a method with stronger Target recovery is not "
            "automatically the best deployment choice."
        ),
        "",
        "## Reporting caution",
        "",
        (
            "The three Source-to-Target pairs are representative "
            "experimental conditions, not independent samples from a "
            "large statistical population. Therefore, mean, standard "
            "deviation and average rank should be described as "
            "**cross-pair descriptive statistics**, not as proof of "
            "universal statistical significance."
        ),
        "",
        "## Compact result table",
        "",
        "| Strategy | Mean Target BER | Mean oracle recovery | "
        "Mean source forgetting | Mean Target rank | Role |",
        "|---|---:|---:|---:|---:|---|",
    ]

    for _, row in summary.iterrows():
        lines.append(
            f"| {row['strategy_display']} "
            f"| {row['mean_target_ber']:.6f} "
            f"| {row['mean_oracle_recovery_ratio']:.4f} "
            f"| {row['mean_source_forgetting']:.6f} "
            f"| {row['mean_target_ber_rank']:.2f} "
            f"| {row['role_in_conclusion']} |"
        )

    lines.extend(
        [
            "",
            "## Recommended thesis conclusion",
            "",
            (
                "Across the selected cross-PDP deployment scenarios, "
                "full-model fine-tuning consistently delivered the "
                "strongest Target-domain BER recovery. However, "
                "adapting only the first decoder convolution layer "
                "was the most effective restricted fine-tuning "
                "strategy, providing a substantially better balance "
                "between Target recovery, trainable parameter count "
                "and Source-domain retention than adapting only the "
                "channel-estimation head or the full channel "
                "extractor."
            ),
            "",
        ]
    )

    return "\n".join(lines)


def main() -> int:
    args = parse_args()

    if not args.input.exists():
        raise FileNotFoundError(
            f"Task 4.4 combined result not found: {args.input}"
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)

    raw = pd.read_csv(args.input)
    validate_input(raw)

    ranked = rank_within_pairs(raw)
    summary = build_cross_pair_summary(ranked)
    summary = add_recommendation_labels(summary)

    transfer_summary = summary[
        ~summary["strategy"].eq("scratch")
    ].copy()

    partial_summary = summary[
        summary["strategy"].isin(PARTIAL_STRATEGIES)
    ].sort_values(
        "mean_partial_target_rank"
    )

    ranked.to_csv(
        args.output_dir / "pair_level_ranked_results.csv",
        index=False,
    )
    summary.to_csv(
        args.output_dir / "cross_pair_statistical_summary.csv",
        index=False,
    )
    transfer_summary.to_csv(
        args.output_dir / "transfer_strategy_summary.csv",
        index=False,
    )
    partial_summary.to_csv(
        args.output_dir / "partial_strategy_ranking.csv",
        index=False,
    )

    save_average_rank_plot(
        summary,
        args.output_dir / "average_target_ber_rank.png",
    )
    save_mean_recovery_plot(
        summary,
        args.output_dir / "mean_oracle_recovery.png",
    )
    save_mean_forgetting_plot(
        summary,
        args.output_dir / "mean_source_forgetting.png",
    )
    save_summary_tradeoff_plot(
        summary,
        args.output_dir / "summary_recovery_forgetting_tradeoff.png",
    )

    report = build_markdown_report(
        summary,
        num_pairs=raw["pair"].nunique(),
    )
    (
        args.output_dir
        / "TASK4_5_STATISTICAL_SUMMARY.md"
    ).write_text(report, encoding="utf-8")

    manifest = {
        "input": str(args.input),
        "num_pairs": int(raw["pair"].nunique()),
        "num_strategies": int(raw["strategy"].nunique()),
        "outputs": [
            "pair_level_ranked_results.csv",
            "cross_pair_statistical_summary.csv",
            "transfer_strategy_summary.csv",
            "partial_strategy_ranking.csv",
            "average_target_ber_rank.png",
            "mean_oracle_recovery.png",
            "mean_source_forgetting.png",
            "summary_recovery_forgetting_tradeoff.png",
            "TASK4_5_STATISTICAL_SUMMARY.md",
        ],
    }
    (
        args.output_dir / "analysis_manifest.json"
    ).write_text(
        json.dumps(manifest, indent=2),
        encoding="utf-8",
    )

    print("=" * 72)
    print("Task 4.5 cross-pair statistical summary complete")
    print("=" * 72)
    print(f"Input: {args.input}")
    print(f"Pairs: {manifest['num_pairs']}")
    print(f"Strategies: {manifest['num_strategies']}")
    print(f"Outputs: {args.output_dir}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
