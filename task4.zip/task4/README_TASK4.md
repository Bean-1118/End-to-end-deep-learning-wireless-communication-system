
# Task 4 starter

This package leaves `src/base_functions.py` unchanged.

Run from the project root:

```bash
python3 -m src.task4.run_freeze_audit
```

Expected counts from Task 3:

- dense_head: 44,940
- channel_extractor: 177,295
- decoder_conv1: 102,656
- full_finetune: 813,202
- encoder_output: 386
- final_decision_head: 6,273

If `end_to_end()` requires arguments, edit only:

```text
src/task4/model_factory.py
```
