
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List

import tensorflow as tf

from src.task4.freeze_strategies import (
    STRATEGY_LAYER_NAMES,
    apply_freeze_strategy,
    count_non_trainable_parameters,
    count_trainable_parameters,
    trainable_layer_names,
)
from src.task4.model_factory import build_original_model


def audit_strategy(strategy_name: str) -> Dict[str, object]:
    model = build_original_model()
    apply_freeze_strategy(model, strategy_name)

    trainable_params = count_trainable_parameters(model)
    frozen_params = count_non_trainable_parameters(model)
    total_params = trainable_params + frozen_params

    return {
        "strategy": strategy_name,
        "requested_layers": list(STRATEGY_LAYER_NAMES[strategy_name]),
        "actual_trainable_layers": trainable_layer_names(model),
        "trainable_parameters": trainable_params,
        "frozen_parameters": frozen_params,
        "total_parameters": total_params,
        "trainable_percentage": (
            100.0 * trainable_params / total_params
            if total_params
            else 0.0
        ),
    }


def write_results(rows: List[Dict[str, object]], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    (output_dir / "task4_freeze_audit.json").write_text(
        json.dumps(rows, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    fieldnames = [
        "strategy",
        "requested_layers",
        "actual_trainable_layers",
        "trainable_parameters",
        "frozen_parameters",
        "total_parameters",
        "trainable_percentage",
    ]
    with (output_dir / "task4_freeze_audit.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            serialised = dict(row)
            serialised["requested_layers"] = "; ".join(
                serialised["requested_layers"]
            )
            serialised["actual_trainable_layers"] = "; ".join(
                serialised["actual_trainable_layers"]
            )
            writer.writerow(serialised)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=(
            Path(__file__).resolve().parents[2]
            / "outputs"
            / "task4_adaptation"
            / "freeze_audit"
        ),
    )
    args = parser.parse_args()

    tf.keras.backend.clear_session()

    rows: List[Dict[str, object]] = []
    print("=" * 72)
    print("Task 4.1 — Freeze Audit")
    print("=" * 72)

    for strategy_name in STRATEGY_LAYER_NAMES:
        row = audit_strategy(strategy_name)
        rows.append(row)
        print(
            f"{strategy_name:28s} "
            f"trainable={row['trainable_parameters']:>9,d} "
            f"({row['trainable_percentage']:6.2f}%)"
        )
        print(
            "  layers: "
            + (
                ", ".join(row["actual_trainable_layers"])
                if row["actual_trainable_layers"]
                else "(none)"
            )
        )

    write_results(rows, args.output_dir)
    print(f"\nResults written to: {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
