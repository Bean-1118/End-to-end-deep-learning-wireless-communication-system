from pathlib import Path
import tensorflow as tf


def restore_task2_checkpoint(model, checkpoint_dir: Path) -> str:
    latest = tf.train.latest_checkpoint(str(checkpoint_dir))
    if latest is None:
        raise FileNotFoundError(f"No checkpoint found in {checkpoint_dir}")
    status = tf.train.Checkpoint(model=model).restore(latest)
    status.assert_existing_objects_matched()
    status.expect_partial()
    return latest


def save_task4_checkpoint(model, checkpoint_dir: Path) -> str:
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    return tf.train.Checkpoint(model=model).save(
        str(checkpoint_dir / "ckpt")
    )
