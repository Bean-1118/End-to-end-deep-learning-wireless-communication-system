import argparse
import csv
import gc
import json
from pathlib import Path
from statistics import mean, stdev

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end, len_h, batch_size
from src.pdp_profiles import get_known_pdps
from src.train_eval import evaluate_ber_single_ebno
from src.task4.checkpoint_utils import restore_task2_checkpoint
from src.task4.fixed_adaptation import (
    compare_weight_snapshots,
    make_fixed_adaptation_dataset,
    set_all_seeds,
    snapshot_weights,
    train_on_fixed_dataset,
)
from src.task4.freeze_strategies import (
    count_trainable_parameters,
    trainable_layer_names,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_STRATEGIES = [
    "no_adaptation",
    "dense_head",
    "channel_extractor",
    "decoder_conv1",
    "full_finetune",
    "scratch",
]


def deterministic_ber(model, pdp, ebno, batches, seed):
    set_all_seeds(seed)
    return float(evaluate_ber_single_ebno(
        model=model,
        pdp_test=pdp,
        ebno_linear=ebno,
        num_test_batches=batches,
    ))


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-pdp", type=int, default=0)
    parser.add_argument("--target-pdp", type=int, default=4)
    parser.add_argument("--strategies", nargs="+", default=DEFAULT_STRATEGIES)
    parser.add_argument("--seeds", nargs="+", type=int, default=[2026, 2027, 2028])
    parser.add_argument("--adaptation-blocks", type=int, default=2048)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--ebno-linear", type=float, default=20.0)
    parser.add_argument("--test-batches", type=int, default=100)
    parser.add_argument(
        "--checkpoint-root",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "checkpoints",
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "task4_adaptation" / "03_main_experiment",
    )
    return parser.parse_args()


def run_strategy(args, source_pdp, target_pdp, strategy, seed, dataset, seed_dir):
    tf.keras.backend.clear_session()
    gc.collect()
    set_all_seeds(seed)

    model = end_to_end()
    restored = ""

    if strategy != "scratch":
        restored = restore_task2_checkpoint(
            model,
            args.checkpoint_root / f"model_trained_on_PDP{args.source_pdp}",
        )

    source_eval_seed = 31000 + seed
    target_eval_seed = 41000 + seed

    source_before = deterministic_ber(
        model, source_pdp, args.ebno_linear,
        args.test_batches, source_eval_seed
    )
    target_before = deterministic_ber(
        model, target_pdp, args.ebno_linear,
        args.test_batches, target_eval_seed
    )

    before_weights = snapshot_weights(model)
    history = None

    if strategy == "no_adaptation":
        trainable_params = 0
        trainable_layers = []
    else:
        history = train_on_fixed_dataset(
            model=model,
            dataset=dataset,
            strategy_name=(
                "full_finetune" if strategy == "scratch" else strategy
            ),
            epochs=args.epochs,
            learning_rate=args.learning_rate,
            seed=seed,
            scratch=(strategy == "scratch"),
        )
        trainable_params = count_trainable_parameters(model)
        trainable_layers = trainable_layer_names(model)

    target_after = deterministic_ber(
        model, target_pdp, args.ebno_linear,
        args.test_batches, target_eval_seed
    )
    source_after = deterministic_ber(
        model, source_pdp, args.ebno_linear,
        args.test_batches, source_eval_seed
    )

    changes = compare_weight_snapshots(model, before_weights)
    changed = [row for row in changes if row["changed"]]

    strategy_dir = seed_dir / strategy
    strategy_dir.mkdir(parents=True, exist_ok=True)

    (strategy_dir / "weight_changes.json").write_text(
        json.dumps(changes, indent=2), encoding="utf-8"
    )
    if history is not None:
        (strategy_dir / "training_history.json").write_text(
            json.dumps(history, indent=2), encoding="utf-8"
        )

    result = {
        "source_pdp": args.source_pdp,
        "target_pdp": args.target_pdp,
        "seed": seed,
        "strategy": strategy,
        "adaptation_blocks": args.adaptation_blocks,
        "epochs": 0 if strategy == "no_adaptation" else args.epochs,
        "update_steps": (
            0 if strategy == "no_adaptation"
            else args.epochs * (args.adaptation_blocks // batch_size)
        ),
        "learning_rate": 0.0 if strategy == "no_adaptation" else args.learning_rate,
        "ebno_linear": args.ebno_linear,
        "test_batches": args.test_batches,
        "trainable_parameters": trainable_params,
        "trainable_layers": "; ".join(trainable_layers),
        "source_ber_before": source_before,
        "source_ber_after": source_after,
        "target_ber_before": target_before,
        "target_ber_after": target_after,
        "target_absolute_improvement": target_before - target_after,
        "source_ber_change": source_after - source_before,
        "changed_weight_tensors": len(changed),
        "restored_checkpoint": restored,
        "first_training_loss": "" if history is None else history["loss"][0],
        "last_training_loss": "" if history is None else history["loss"][-1],
    }

    (strategy_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )

    print(
        f"{strategy}: target {target_before:.6f} -> {target_after:.6f}; "
        f"source {source_before:.6f} -> {source_after:.6f}"
    )

    del model
    tf.keras.backend.clear_session()
    gc.collect()
    return result


def build_summary(rows):
    output = []
    for strategy in sorted({row["strategy"] for row in rows}):
        subset = [row for row in rows if row["strategy"] == strategy]
        target_after = [float(row["target_ber_after"]) for row in subset]
        improvement = [float(row["target_absolute_improvement"]) for row in subset]
        source_change = [float(row["source_ber_change"]) for row in subset]

        output.append({
            "strategy": strategy,
            "num_seeds": len(subset),
            "trainable_parameters": subset[0]["trainable_parameters"],
            "mean_target_ber_after": mean(target_after),
            "std_target_ber_after": stdev(target_after) if len(target_after) > 1 else 0.0,
            "mean_target_improvement": mean(improvement),
            "std_target_improvement": stdev(improvement) if len(improvement) > 1 else 0.0,
            "mean_source_ber_change": mean(source_change),
            "std_source_ber_change": stdev(source_change) if len(source_change) > 1 else 0.0,
        })
    return output


def main():
    args = parse_args()
    pdps = get_known_pdps(len_h)
    source_pdp = pdps[args.source_pdp]
    target_pdp = pdps[args.target_pdp]

    exp_dir = (
        args.output_root
        / f"PDP{args.source_pdp}_to_PDP{args.target_pdp}"
        / f"blocks{args.adaptation_blocks}__epochs{args.epochs}__lr{args.learning_rate:g}"
    )
    exp_dir.mkdir(parents=True, exist_ok=True)

    config = vars(args).copy()
    config["checkpoint_root"] = str(config["checkpoint_root"])
    config["output_root"] = str(config["output_root"])
    (exp_dir / "config.json").write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )

    rows = []

    for seed in args.seeds:
        dataset = make_fixed_adaptation_dataset(
            pdp_target=target_pdp,
            pdp_id=args.target_pdp,
            num_blocks=args.adaptation_blocks,
            ebno_linear=args.ebno_linear,
            seed=seed,
        )

        seed_dir = exp_dir / f"seed_{seed}"
        seed_dir.mkdir(parents=True, exist_ok=True)

        np.savez_compressed(
            seed_dir / "fixed_adaptation_dataset.npz",
            bits=dataset.bits,
            channels=dataset.channels,
            noise_std=dataset.noise_std,
        )

        for strategy in args.strategies:
            row = run_strategy(
                args, source_pdp, target_pdp,
                strategy, seed, dataset, seed_dir
            )
            rows.append(row)
            write_csv(exp_dir / "raw_results_partial.csv", rows)

    write_csv(exp_dir / "raw_results.csv", rows)
    summary = build_summary(rows)
    write_csv(exp_dir / "summary.csv", summary)
    (exp_dir / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print("Task 4.3 complete")
    print("Results:", exp_dir)


if __name__ == "__main__":
    main()
