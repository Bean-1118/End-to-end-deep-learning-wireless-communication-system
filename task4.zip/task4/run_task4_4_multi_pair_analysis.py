from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
FULL_MODEL_PARAMETERS = 813_202

STRATEGY_DISPLAY_NAMES = {
    "no_adaptation": "No adaptation",
    "dense_head": "Dense head",
    "channel_extractor": "Channel extractor",
    "decoder_conv1": "Decoder Conv1",
    "full_finetune": "Full fine-tune",
    "scratch": "Scratch",
}

STRATEGY_ORDER = [
    "no_adaptation",
    "dense_head",
    "channel_extractor",
    "decoder_conv1",
    "full_finetune",
    "scratch",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Task 4.4: combine multiple Source-to-Target adaptation "
            "experiments and calculate oracle recovery, forgetting, "
            "parameter efficiency, and cross-pair rankings."
        )
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "src" / "task4" / "task4_4_pairs.json",
        help="JSON file describing the BER matrix and experiment summary files.",
    )
    return parser.parse_args()


def resolve_path(path_text: str) -> Path:
    path = Path(path_text)
    if path.is_absolute():
        return path
    return PROJECT_ROOT / path


def read_ber_matrix(path: Path) -> np.ndarray:
    """Load the BER matrix without treating the first row as a header."""
    if not path.exists():
        raise FileNotFoundError(f"BER matrix not found: {path}")

    matrix_df = pd.read_csv(path, header=None)
    matrix = matrix_df.to_numpy(dtype=float)

    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError(
            f"Expected a square BER matrix, received shape {matrix.shape}."
        )

    if not np.all(np.isfinite(matrix)):
        raise ValueError("BER matrix contains NaN or infinite values.")

    return matrix


def read_summary(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Summary file not found: {path}")

    df = pd.read_csv(path)

    required = {
        "strategy",
        "num_seeds",
        "trainable_parameters",
        "mean_target_ber_after",
        "std_target_ber_after",
        "mean_target_improvement",
        "std_target_improvement",
        "mean_source_ber_change",
        "std_source_ber_change",
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            f"{path} is missing required columns: {sorted(missing)}"
        )

    if df["strategy"].duplicated().any():
        duplicate_names = df.loc[
            df["strategy"].duplicated(), "strategy"
        ].tolist()
        raise ValueError(
            f"{path} contains duplicate strategies: {duplicate_names}"
        )

    return df.copy()


def get_no_adaptation_target_ber(summary: pd.DataFrame) -> float:
    rows = summary.loc[summary["strategy"] == "no_adaptation"]
    if len(rows) != 1:
        raise ValueError(
            "Every summary must contain exactly one no_adaptation row."
        )
    return float(rows.iloc[0]["mean_target_ber_after"])


def combine_pair(
    pair_name: str,
    source_pdp: int,
    target_pdp: int,
    summary_path: Path,
    summary: pd.DataFrame,
    matrix: np.ndarray,
) -> pd.DataFrame:
    if not 0 <= source_pdp < matrix.shape[0]:
        raise ValueError(f"{pair_name}: invalid source_pdp={source_pdp}")
    if not 0 <= target_pdp < matrix.shape[1]:
        raise ValueError(f"{pair_name}: invalid target_pdp={target_pdp}")
    if source_pdp == target_pdp:
        raise ValueError(f"{pair_name}: source and target PDP must differ.")

    matrix_source_matched = float(matrix[source_pdp, source_pdp])
    matrix_cross_ber = float(matrix[source_pdp, target_pdp])
    target_oracle_ber = float(matrix[target_pdp, target_pdp])

    evaluated_no_adaptation = get_no_adaptation_target_ber(summary)

    # The restored source checkpoint is evaluated with a larger batch count,
    # so this value may differ slightly from the original BER matrix.
    matrix_vs_task4_difference = (
        evaluated_no_adaptation - matrix_cross_ber
    )

    oracle_gap = evaluated_no_adaptation - target_oracle_ber
    if oracle_gap <= 0:
        raise ValueError(
            f"{pair_name}: no positive oracle gap. "
            f"No-adaptation={evaluated_no_adaptation:.6f}, "
            f"oracle={target_oracle_ber:.6f}."
        )

    combined = summary.copy()
    combined.insert(0, "pair", pair_name)
    combined.insert(1, "source_pdp", source_pdp)
    combined.insert(2, "target_pdp", target_pdp)
    combined["strategy_display"] = combined["strategy"].map(
        STRATEGY_DISPLAY_NAMES
    ).fillna(combined["strategy"])

    combined["source_matched_ber_task2"] = matrix_source_matched
    combined["cross_ber_task2"] = matrix_cross_ber
    combined["no_adaptation_ber_task4"] = evaluated_no_adaptation
    combined["task4_minus_task2_cross_ber"] = matrix_vs_task4_difference
    combined["target_oracle_ber"] = target_oracle_ber
    combined["oracle_gap"] = oracle_gap

    combined["absolute_target_improvement_recomputed"] = (
        evaluated_no_adaptation
        - combined["mean_target_ber_after"]
    )

    combined["relative_target_improvement"] = (
        combined["absolute_target_improvement_recomputed"]
        / evaluated_no_adaptation
    )

    combined["oracle_recovery_ratio"] = (
        combined["absolute_target_improvement_recomputed"]
        / oracle_gap
    )

    combined["trainable_parameter_fraction"] = (
        combined["trainable_parameters"]
        / FULL_MODEL_PARAMETERS
    )

    combined["improvement_per_100k_parameters"] = np.where(
        combined["trainable_parameters"] > 0,
        combined["absolute_target_improvement_recomputed"]
        / (combined["trainable_parameters"] / 100_000.0),
        np.nan,
    )

    # Scratch training starts from random initialisation, so its BER difference
    # from no adaptation is not treated as a transfer-recovery metric.
    combined["is_transfer_strategy"] = ~combined["strategy"].eq("scratch")
    combined["valid_transfer_recovery_metric"] = ~combined["strategy"].eq(
        "scratch"
    )

    combined["summary_file"] = str(summary_path)
    return combined


def add_pairwise_ranks(combined: pd.DataFrame) -> pd.DataFrame:
    ranked = combined.copy()

    ranked["target_ber_rank"] = ranked.groupby("pair")[
        "mean_target_ber_after"
    ].rank(method="min", ascending=True)

    ranked["target_improvement_rank"] = ranked.groupby("pair")[
        "absolute_target_improvement_recomputed"
    ].rank(method="min", ascending=False)

    ranked["source_retention_rank"] = ranked.groupby("pair")[
        "mean_source_ber_change"
    ].rank(method="min", ascending=True)

    partial_mask = ranked["strategy"].isin(
        ["dense_head", "channel_extractor", "decoder_conv1"]
    )
    ranked["partial_strategy_target_rank"] = np.nan
    ranked.loc[partial_mask, "partial_strategy_target_rank"] = (
        ranked.loc[partial_mask]
        .groupby("pair")["mean_target_ber_after"]
        .rank(method="min", ascending=True)
    )

    return ranked


def build_strategy_summary(combined: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []

    for strategy, subset in combined.groupby("strategy", sort=False):
        rows.append(
            {
                "strategy": strategy,
                "strategy_display": STRATEGY_DISPLAY_NAMES.get(
                    strategy, strategy
                ),
                "num_pairs": int(subset["pair"].nunique()),
                "trainable_parameters": int(
                    subset["trainable_parameters"].iloc[0]
                ),
                "trainable_parameter_fraction": float(
                    subset["trainable_parameter_fraction"].iloc[0]
                ),
                "mean_target_ber_across_pairs": float(
                    subset["mean_target_ber_after"].mean()
                ),
                "std_target_ber_across_pairs": float(
                    subset["mean_target_ber_after"].std(ddof=1)
                    if len(subset) > 1
                    else 0.0
                ),
                "mean_absolute_target_improvement": float(
                    subset[
                        "absolute_target_improvement_recomputed"
                    ].mean()
                ),
                "mean_relative_target_improvement": float(
                    subset["relative_target_improvement"].mean()
                ),
                "mean_oracle_recovery_ratio": float(
                    subset["oracle_recovery_ratio"].mean()
                ),
                "mean_source_ber_change": float(
                    subset["mean_source_ber_change"].mean()
                ),
                "mean_target_ber_rank": float(
                    subset["target_ber_rank"].mean()
                ),
                "mean_partial_strategy_rank": (
                    float(
                        subset[
                            "partial_strategy_target_rank"
                        ].dropna().mean()
                    )
                    if subset[
                        "partial_strategy_target_rank"
                    ].notna().any()
                    else np.nan
                ),
            }
        )

    output = pd.DataFrame(rows)
    strategy_order_map = {
        strategy: index
        for index, strategy in enumerate(STRATEGY_ORDER)
    }
    output["_order"] = output["strategy"].map(
        strategy_order_map
    ).fillna(999)
    output = output.sort_values("_order").drop(columns="_order")
    return output


def save_target_ber_plot(
    combined: pd.DataFrame,
    output_path: Path,
) -> None:
    pivot = combined.pivot(
        index="pair",
        columns="strategy",
        values="mean_target_ber_after",
    )

    available = [
        strategy for strategy in STRATEGY_ORDER
        if strategy in pivot.columns
    ]
    pivot = pivot[available]

    ax = pivot.plot(kind="bar", figsize=(12, 7))
    ax.set_title("Target BER after adaptation across PDP pairs")
    ax.set_xlabel("Source-to-target pair")
    ax.set_ylabel("Target BER")
    ax.grid(axis="y", alpha=0.3)
    ax.legend(
        [STRATEGY_DISPLAY_NAMES.get(x, x) for x in available],
        title="Strategy",
        bbox_to_anchor=(1.02, 1),
        loc="upper left",
    )
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_recovery_forgetting_plot(
    combined: pd.DataFrame,
    output_path: Path,
) -> None:
    plot_df = combined.loc[
        ~combined["strategy"].isin(["no_adaptation", "scratch"])
    ].copy()

    fig, ax = plt.subplots(figsize=(10, 7))

    for _, row in plot_df.iterrows():
        ax.scatter(
            row["mean_source_ber_change"],
            row["oracle_recovery_ratio"],
            s=80,
        )
        ax.annotate(
            f"{row['pair']} | "
            f"{STRATEGY_DISPLAY_NAMES.get(row['strategy'], row['strategy'])}",
            (
                row["mean_source_ber_change"],
                row["oracle_recovery_ratio"],
            ),
            xytext=(5, 5),
            textcoords="offset points",
            fontsize=8,
        )

    ax.set_title("Target oracle recovery versus source forgetting")
    ax.set_xlabel("Source BER change after adaptation")
    ax.set_ylabel("Oracle recovery ratio")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_parameter_efficiency_plot(
    combined: pd.DataFrame,
    output_path: Path,
) -> None:
    plot_df = combined.loc[
        combined["strategy"].isin(
            [
                "dense_head",
                "channel_extractor",
                "decoder_conv1",
                "full_finetune",
            ]
        )
    ].copy()

    fig, ax = plt.subplots(figsize=(10, 7))

    for _, row in plot_df.iterrows():
        ax.scatter(
            row["trainable_parameter_fraction"] * 100.0,
            row["absolute_target_improvement_recomputed"],
            s=80,
        )
        ax.annotate(
            f"{row['pair']} | "
            f"{STRATEGY_DISPLAY_NAMES.get(row['strategy'], row['strategy'])}",
            (
                row["trainable_parameter_fraction"] * 100.0,
                row["absolute_target_improvement_recomputed"],
            ),
            xytext=(5, 5),
            textcoords="offset points",
            fontsize=8,
        )

    ax.set_title("Adaptation gain versus trainable parameter fraction")
    ax.set_xlabel("Trainable parameters (% of full model)")
    ax.set_ylabel("Absolute target BER improvement")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_pair_overview(
    combined: pd.DataFrame,
    output_path: Path,
) -> None:
    overview = (
        combined[
            [
                "pair",
                "source_pdp",
                "target_pdp",
                "source_matched_ber_task2",
                "cross_ber_task2",
                "no_adaptation_ber_task4",
                "task4_minus_task2_cross_ber",
                "target_oracle_ber",
                "oracle_gap",
            ]
        ]
        .drop_duplicates(subset=["pair"])
        .sort_values(["source_pdp", "target_pdp"])
    )
    overview.to_csv(output_path, index=False)


def main() -> int:
    args = parse_args()

    if not args.config.exists():
        raise FileNotFoundError(
            f"Configuration file not found: {args.config}"
        )

    config = json.loads(args.config.read_text(encoding="utf-8"))

    matrix_path = resolve_path(config["ber_matrix"])
    output_dir = resolve_path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    matrix = read_ber_matrix(matrix_path)

    pair_frames = []

    for pair in config["pairs"]:
        pair_name = str(pair["name"])
        source_pdp = int(pair["source_pdp"])
        target_pdp = int(pair["target_pdp"])
        summary_path = resolve_path(pair["summary_csv"])

        summary = read_summary(summary_path)
        pair_frame = combine_pair(
            pair_name=pair_name,
            source_pdp=source_pdp,
            target_pdp=target_pdp,
            summary_path=summary_path,
            summary=summary,
            matrix=matrix,
        )
        pair_frames.append(pair_frame)

    combined = pd.concat(pair_frames, ignore_index=True)
    combined = add_pairwise_ranks(combined)

    strategy_summary = build_strategy_summary(combined)

    combined.to_csv(
        output_dir / "combined_pair_strategy_results.csv",
        index=False,
    )
    strategy_summary.to_csv(
        output_dir / "cross_pair_strategy_summary.csv",
        index=False,
    )
    save_pair_overview(
        combined,
        output_dir / "pair_overview.csv",
    )

    save_target_ber_plot(
        combined,
        output_dir / "target_ber_comparison.png",
    )
    save_recovery_forgetting_plot(
        combined,
        output_dir / "recovery_vs_forgetting.png",
    )
    save_parameter_efficiency_plot(
        combined,
        output_dir / "performance_vs_parameters.png",
    )

    report = {
        "ber_matrix": str(matrix_path),
        "num_pairs": int(combined["pair"].nunique()),
        "pairs": sorted(combined["pair"].unique().tolist()),
        "output_dir": str(output_dir),
        "best_mean_target_ber_strategy": str(
            strategy_summary.sort_values(
                "mean_target_ber_across_pairs"
            ).iloc[0]["strategy"]
        ),
        "best_partial_strategy": str(
            strategy_summary.loc[
                strategy_summary["mean_partial_strategy_rank"].notna()
            ].sort_values(
                "mean_partial_strategy_rank"
            ).iloc[0]["strategy"]
        ),
    }

    (output_dir / "analysis_manifest.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("=" * 72)
    print("Task 4.4 multi-pair analysis complete")
    print("=" * 72)
    print(f"Pairs analysed: {report['pairs']}")
    print(
        "Best mean target-BER strategy: "
        f"{report['best_mean_target_ber_strategy']}"
    )
    print(
        "Best partial strategy: "
        f"{report['best_partial_strategy']}"
    )
    print(f"Outputs: {output_dir}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
