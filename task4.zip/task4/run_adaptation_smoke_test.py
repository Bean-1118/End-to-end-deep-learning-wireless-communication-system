import argparse
import csv
import json
from pathlib import Path

import tensorflow as tf

from src.base_functions import end_to_end, len_h
from src.pdp_profiles import get_known_pdps
from src.train_eval import evaluate_ber_single_ebno
from src.task4.adaptation import (
    adapt_model_on_pdp,
    compare_weights,
    set_all_seeds,
    snapshot_weights,
)
from src.task4.checkpoint_utils import (
    restore_task2_checkpoint,
    save_task4_checkpoint,
)
from src.task4.freeze_strategies import (
    count_trainable_parameters,
    trainable_layer_names,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def deterministic_ber(model, pdp, ebno, batches, seed):
    set_all_seeds(seed)
    return float(evaluate_ber_single_ebno(
        model=model,
        pdp_test=pdp,
        ebno_linear=ebno,
        num_test_batches=batches,
    ))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-pdp", type=int, default=0)
    parser.add_argument("--target-pdp", type=int, default=4)
    parser.add_argument("--strategy", default="dense_head")
    parser.add_argument("--adaptation-steps", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--ebno-linear", type=float, default=20.0)
    parser.add_argument("--test-batches", type=int, default=10)
    parser.add_argument("--adaptation-seed", type=int, default=2026)
    args = parser.parse_args()

    pdps = get_known_pdps(len_h)
    source_pdp = pdps[args.source_pdp]
    target_pdp = pdps[args.target_pdp]

    output_dir = (
        PROJECT_ROOT / "outputs" / "task4_adaptation" /
        "02_smoke_test" /
        f"PDP{args.source_pdp}_to_PDP{args.target_pdp}"
        f"__{args.strategy}__seed{args.adaptation_seed}"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    model = end_to_end()
    checkpoint_dir = (
        PROJECT_ROOT / "outputs" / "checkpoints" /
        f"model_trained_on_PDP{args.source_pdp}"
    )
    restored = restore_task2_checkpoint(model, checkpoint_dir)
    print("Restored:", restored)

    source_before = deterministic_ber(
        model, source_pdp, args.ebno_linear,
        args.test_batches, 31001
    )
    target_before = deterministic_ber(
        model, target_pdp, args.ebno_linear,
        args.test_batches, 41001
    )

    before_weights = snapshot_weights(model)

    losses, train_bers = adapt_model_on_pdp(
        model=model,
        pdp_target=target_pdp,
        strategy_name=args.strategy,
        number_steps=args.adaptation_steps,
        learning_rate=args.learning_rate,
        ebno_train_linear=args.ebno_linear,
        seed=args.adaptation_seed,
    )

    target_after = deterministic_ber(
        model, target_pdp, args.ebno_linear,
        args.test_batches, 41001
    )
    source_after = deterministic_ber(
        model, source_pdp, args.ebno_linear,
        args.test_batches, 31001
    )

    changes = compare_weights(model, before_weights)
    changed = [r for r in changes if r["changed"]]
    adapted_ckpt = save_task4_checkpoint(
        model, output_dir / "checkpoint"
    )

    result = {
        "source_pdp": args.source_pdp,
        "target_pdp": args.target_pdp,
        "strategy": args.strategy,
        "adaptation_steps": args.adaptation_steps,
        "learning_rate": args.learning_rate,
        "ebno_linear": args.ebno_linear,
        "test_batches": args.test_batches,
        "trainable_parameters": count_trainable_parameters(model),
        "trainable_layers": "; ".join(trainable_layer_names(model)),
        "source_ber_before": source_before,
        "source_ber_after": source_after,
        "target_ber_before": target_before,
        "target_ber_after": target_after,
        "target_absolute_improvement": target_before - target_after,
        "source_ber_change": source_after - source_before,
        "changed_weight_tensors": len(changed),
        "restored_checkpoint": restored,
        "adapted_checkpoint": adapted_ckpt,
        "first_loss": losses[0],
        "last_loss": losses[-1],
        "first_train_ber": train_bers[0],
        "last_train_ber": train_bers[-1],
    }

    (output_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    (output_dir / "weight_changes.json").write_text(
        json.dumps(changes, indent=2), encoding="utf-8"
    )
    (output_dir / "history.json").write_text(
        json.dumps({"loss": losses, "ber": train_bers}, indent=2),
        encoding="utf-8"
    )

    with (output_dir / "result.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=result.keys())
        writer.writeheader()
        writer.writerow(result)

    print("\nBefore adaptation")
    print("Source BER:", source_before)
    print("Target BER:", target_before)
    print("\nAfter adaptation")
    print("Source BER:", source_after)
    print("Target BER:", target_after)
    print("Changed weight tensors:", len(changed))
    print("Results:", output_dir)


if __name__ == "__main__":
    main()
