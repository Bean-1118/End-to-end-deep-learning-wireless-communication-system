import random
from dataclasses import dataclass
import numpy as np
import tensorflow as tf

from src.base_functions import R, batch_size, block_length, len_h, sample_h_mp
from src.task4.freeze_strategies import (
    apply_freeze_strategy,
    count_trainable_parameters,
    trainable_layer_names,
)


@dataclass
class FixedAdaptationDataset:
    bits: np.ndarray
    channels: np.ndarray
    noise_std: np.ndarray
    seed: int
    pdp_id: int
    ebno_linear: float

    @property
    def num_blocks(self):
        return int(self.bits.shape[0])


def set_all_seeds(seed):
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


def make_fixed_adaptation_dataset(
    pdp_target,
    pdp_id,
    num_blocks=2048,
    ebno_linear=20.0,
    seed=2026,
):
    if num_blocks < batch_size or num_blocks % batch_size != 0:
        raise ValueError(
            f"num_blocks must be a positive multiple of batch_size={batch_size}"
        )

    rng = np.random.default_rng(seed)
    bits = rng.binomial(
        1, 0.5, size=(num_blocks, block_length, 1)
    ).astype(np.float32)

    old_state = np.random.get_state()
    np.random.seed(seed + 1)
    try:
        channels = sample_h_mp(
            (num_blocks, len_h, 2), pdp_target
        ).astype(np.float32)
    finally:
        np.random.set_state(old_state)

    noise_value = np.float32(
        np.sqrt(1.0 / (2.0 * R * ebno_linear))
    )
    noise_std = np.full(
        (num_blocks, 1), noise_value, dtype=np.float32
    )

    return FixedAdaptationDataset(
        bits=bits,
        channels=channels,
        noise_std=noise_std,
        seed=seed,
        pdp_id=pdp_id,
        ebno_linear=ebno_linear,
    )


def iter_fixed_batches(dataset, epoch, shuffle_seed):
    rng = np.random.default_rng(shuffle_seed + epoch)
    indices = rng.permutation(dataset.num_blocks)

    for start in range(0, dataset.num_blocks, batch_size):
        idx = indices[start:start + batch_size]
        yield (
            dataset.bits[idx],
            dataset.channels[idx],
            dataset.noise_std[idx],
        )


def train_on_fixed_dataset(
    model,
    dataset,
    strategy_name,
    epochs=20,
    learning_rate=1e-4,
    seed=2026,
    scratch=False,
):
    set_all_seeds(seed)
    apply_freeze_strategy(
        model,
        "full_finetune" if scratch else strategy_name,
    )

    trainable_params = count_trainable_parameters(model)
    if trainable_params == 0:
        raise ValueError("Selected strategy has zero trainable parameters.")

    print(f"Strategy: {'scratch' if scratch else strategy_name}")
    print(f"Trainable parameters: {trainable_params:,}")
    print("Trainable layers:", ", ".join(trainable_layer_names(model)))

    optimizer = tf.keras.optimizers.Adam(learning_rate)
    losses, bers = [], []

    for epoch in range(epochs):
        epoch_losses, epoch_bers = [], []

        for bits, channels, noise_std in iter_fixed_batches(
            dataset, epoch, seed + 1000
        ):
            labels = tf.cast(bits, tf.float32)

            with tf.GradientTape() as tape:
                logits, probabilities = model(
                    [bits, channels, noise_std], training=True
                )
                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        logits=logits, labels=labels
                    )
                )

            variables = model.trainable_variables
            gradients = tape.gradient(loss, variables)
            pairs = [
                (g, v) for g, v in zip(gradients, variables)
                if g is not None
            ]
            if not pairs:
                raise RuntimeError("No gradients were produced.")
            optimizer.apply_gradients(pairs)

            predicted = tf.cast(probabilities >= 0.5, tf.float32)
            ber = tf.reduce_mean(
                tf.cast(predicted != labels, tf.float32)
            )

            loss_value = float(loss.numpy())
            ber_value = float(ber.numpy())
            losses.append(loss_value)
            bers.append(ber_value)
            epoch_losses.append(loss_value)
            epoch_bers.append(ber_value)

        print(
            f"Epoch {epoch + 1}/{epochs} | "
            f"loss={np.mean(epoch_losses):.6f} | "
            f"BER={np.mean(epoch_bers):.6f}"
        )

    return {
        "loss": losses,
        "ber": bers,
        "steps": len(losses),
        "epochs": epochs,
        "batches_per_epoch": dataset.num_blocks // batch_size,
    }


def snapshot_weights(model):
    return [w.numpy().copy() for w in model.weights]


def compare_weight_snapshots(model, before):
    rows = []
    for i, (weight, old) in enumerate(zip(model.weights, before)):
        change = float(np.max(np.abs(weight.numpy() - old)))
        rows.append({
            "weight_index": i,
            "weight_name": getattr(weight, "path", weight.name),
            "shape": list(weight.shape),
            "max_abs_change": change,
            "changed": change > 0.0,
        })
    return rows
