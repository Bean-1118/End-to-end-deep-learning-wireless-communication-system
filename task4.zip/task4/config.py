
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Task4Config:
    project_root: Path
    source_checkpoint: Path
    output_root: Path
    learning_rate: float = 1e-4
    batch_size: int = 512
    adaptation_blocks: int = 2048
    adaptation_steps: int = 80
    seed: int = 2026

    @classmethod
    def default(cls) -> "Task4Config":
        project_root = Path(__file__).resolve().parents[2]
        return cls(
            project_root=project_root,
            source_checkpoint=(
                project_root
                / "outputs"
                / "task2_cross_pdp"
                / "checkpoints"
                / "REPLACE_WITH_SOURCE_CHECKPOINT.weights.h5"
            ),
            output_root=project_root / "outputs" / "task4_adaptation",
        )
