import random
import numpy as np
import tensorflow as tf

from src.base_functions import (
    R, batch_size, generate_batch_data, len_h, sample_h_mp
)
from src.task4.freeze_strategies import (
    apply_freeze_strategy,
    count_trainable_parameters,
    trainable_layer_names,
)


def set_all_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


def snapshot_weights(model):
    return [w.numpy().copy() for w in model.weights]


def compare_weights(model, before):
    rows = []
    for i, (weight, old) in enumerate(zip(model.weights, before)):
        change = float(np.max(np.abs(weight.numpy() - old)))
        rows.append({
            "index": i,
            "name": getattr(weight, "path", weight.name),
            "max_abs_change": change,
            "changed": change > 0.0,
        })
    return rows


def adapt_model_on_pdp(
    model,
    pdp_target,
    strategy_name="dense_head",
    number_steps=20,
    learning_rate=1e-4,
    ebno_train_linear=20.0,
    seed=2026,
):
    set_all_seeds(seed)
    apply_freeze_strategy(model, strategy_name)

    trainable_count = count_trainable_parameters(model)
    if trainable_count == 0:
        raise ValueError("Adaptation strategy has zero trainable parameters.")

    print(f"Strategy: {strategy_name}")
    print(f"Trainable parameters: {trainable_count:,}")
    print("Trainable layers:", ", ".join(trainable_layer_names(model)))

    optimizer = tf.keras.optimizers.Adam(learning_rate)
    noise_std_value = np.float32(
        np.sqrt(1.0 / (2.0 * R * ebno_train_linear))
    )

    loss_history = []
    ber_history = []

    for step in range(1, number_steps + 1):
        bits = generate_batch_data(batch_size)
        channel = sample_h_mp(
            (batch_size, len_h, 2), pdp_target
        ).astype(np.float32)
        noise_std = np.full(
            (batch_size, 1), noise_std_value, dtype=np.float32
        )
        labels = tf.cast(bits, tf.float32)

        with tf.GradientTape() as tape:
            logits, probabilities = model(
                [bits, channel, noise_std], training=True
            )
            loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(
                    logits=logits, labels=labels
                )
            )

        variables = model.trainable_variables
        gradients = tape.gradient(loss, variables)
        pairs = [
            (g, v) for g, v in zip(gradients, variables)
            if g is not None
        ]
        if not pairs:
            raise RuntimeError("No gradients were produced.")
        optimizer.apply_gradients(pairs)

        predicted = tf.cast(probabilities >= 0.5, tf.float32)
        ber = tf.reduce_mean(
            tf.cast(predicted != labels, tf.float32)
        )

        loss_history.append(float(loss.numpy()))
        ber_history.append(float(ber.numpy()))

        if step == 1 or step == number_steps or step % 10 == 0:
            print(
                f"Step {step}/{number_steps} | "
                f"loss={loss_history[-1]:.6f} | "
                f"BER={ber_history[-1]:.6f}"
            )

    return loss_history, ber_history
