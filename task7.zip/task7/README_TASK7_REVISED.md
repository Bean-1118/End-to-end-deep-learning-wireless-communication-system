# Revised Task 7

Files:
- task7_config.py
- task7_common.py
- run_task7_1_joint_training.py
- run_task7_2_joint_particular_adaptation.py
- run_task7_3_ea_baseline_comparison.py

Important changes:
1. Task 7.1 starts from the same PDP0 checkpoint as Task 6.3.
2. Task 7.1 uses independent PDP0-PDP5 validation and restores the best joint checkpoint.
3. Joint checkpoints contain trainable weights only, matching revised Task 6 snapshot semantics.
4. Task 7.2 audits that shared weights remain unchanged and particular weights change.
5. Task 7.3 uses the exact output file names written by Task 7.1 and Task 7.2.
6. Task 7.3 validates columns, methods, seeds, targets, SNR grid and row counts before merging.
7. Algorithm 1 uses historical-mean particular initialisation, matching revised Task 6.4.
