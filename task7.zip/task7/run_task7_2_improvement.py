from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps
from src.task6.iadmm_state import (
    load_snapshot_npz,
    restore_named_layers,
)
from src.task7.task7_common import (
    build_dataset,
    clean_model,
    evaluate_snr_sweep,
    set_deterministic,
    snapshot_layer_arrays,
)
from src.task7.task7_config import Task7Config


# ============================================================================
# Task 7.2 improvement: ablation of the adaptable decoder subset.
#
# This experiment leaves src/task6/task6_parameter_groups.py unchanged, so the
# Algorithm-1 partition used in Task 6 and Task 7.3 is preserved. It measures
# how Baseline 2 changes when a larger decoder-specific subset is adapted at an
# unseen PDP. A direct comparison with Algorithm 1 requires Task 6 to use the
# same shared/particular partition.
# ============================================================================


PROFILE_LAYERS: Dict[str, Tuple[str, ...]] = {
    # Task-5.4 / Task-6 partition.
    "original3": (
        "decoder_conv_1",
        "decoder_res1_input",
        "decoder_res1_conv2",
    ),

    # Add the final decoder projection and decision layers.
    "tail2": (
        "decoder_conv_1",
        "decoder_res1_input",
        "decoder_res1_conv2",
        "decoder_conv_final",
        "pred_logits_full",
    ),

    # Extend the original subset with the second residual decoder block and final output head.
    "res2tail": (
        "decoder_conv_1",
        "decoder_res1_input",
        "decoder_res1_conv2",
        "decoder_res2_input",
        "decoder_res2_conv1",
        "decoder_res2_conv2",
        "decoder_conv_final",
        "pred_logits_full",
    ),

    # Make all trainable decoder layers target-specific and adaptable.
    "full_decoder": (
        "decoder_conv_1",
        "decoder_res1_input",
        "decoder_res1_conv1",
        "decoder_res1_conv2",
        "decoder_res2_input",
        "decoder_res2_conv1",
        "decoder_res2_conv2",
        "decoder_conv_final",
        "pred_logits_full",
    ),
}


def write_csv(
    path: Path,
    rows: List[dict],
) -> None:
    if not rows:
        return

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames: List[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def validate_profile(
    model: tf.keras.Model,
    layer_names: Iterable[str],
) -> Tuple[str, ...]:
    names = tuple(layer_names)
    model_names = {
        layer.name
        for layer in model.layers
    }

    missing = set(names) - model_names
    if missing:
        raise ValueError(
            "Requested adaptable layers are missing from model: "
            f"{sorted(missing)}"
        )

    no_parameters = [
        name
        for name in names
        if not model.get_layer(name).weights
    ]
    if no_parameters:
        raise ValueError(
            "Requested adaptable layers contain no parameters: "
            f"{no_parameters}"
        )

    return names


def count_profile_parameters(
    model: tf.keras.Model,
    layer_names: Iterable[str],
) -> int:
    return int(
        sum(
            tf.size(variable).numpy()
            for layer_name in layer_names
            for variable in model.get_layer(
                layer_name
            ).weights
        )
    )


def set_custom_particular_only_trainable(
    model: tf.keras.Model,
    layer_names: Iterable[str],
) -> None:
    intended = set(
        validate_profile(
            model,
            layer_names,
        )
    )

    for layer in model.layers:
        layer.trainable = (
            layer.name in intended
        )

    actual = {
        layer.name
        for layer in model.layers
        if (
            layer.trainable
            and layer.trainable_weights
        )
    }

    if actual != intended:
        raise RuntimeError(
            "Trainable-mask mismatch. "
            f"Expected={sorted(intended)}, "
            f"actual={sorted(actual)}"
        )


def make_plain_sgd(
    learning_rate: float,
) -> tf.keras.optimizers.Optimizer:
    if learning_rate <= 0:
        raise ValueError(
            "learning_rate must be positive."
        )

    return tf.keras.optimizers.SGD(
        learning_rate=learning_rate,
        momentum=0.0,
        nesterov=False,
    )


def adapt_custom_particular(
    *,
    model: tf.keras.Model,
    dataset,
    adaptable_layers: Tuple[str, ...],
    epochs: int,
    learning_rate: float,
    seed: int,
) -> List[dict]:
    set_deterministic(seed)

    set_custom_particular_only_trainable(
        model,
        adaptable_layers,
    )

    optimizer = make_plain_sgd(
        learning_rate
    )

    history: List[dict] = []

    for epoch in range(epochs):
        losses: List[float] = []
        bers: List[float] = []

        from src.task4.fixed_adaptation import iter_fixed_batches

        for (
            bits,
            channels,
            noise_std,
        ) in iter_fixed_batches(
            dataset=dataset,
            epoch=epoch,
            shuffle_seed=(
                seed + 1000
            ),
        ):
            labels = tf.cast(
                bits,
                tf.float32,
            )

            with tf.GradientTape() as tape:
                (
                    logits,
                    probabilities,
                ) = model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        labels=labels,
                        logits=logits,
                    )
                )

            variables = list(
                model.trainable_variables
            )

            gradients = tape.gradient(
                loss,
                variables,
            )

            pairs = []
            for gradient, variable in zip(
                gradients,
                variables,
            ):
                if gradient is None:
                    raise RuntimeError(
                        "Missing gradient for "
                        f"{variable.name}"
                    )

                if not bool(
                    tf.reduce_all(
                        tf.math.is_finite(
                            gradient
                        )
                    ).numpy()
                ):
                    raise FloatingPointError(
                        "Non-finite gradient for "
                        f"{variable.name}"
                    )

                pairs.append(
                    (
                        gradient,
                        variable,
                    )
                )

            if not pairs:
                raise RuntimeError(
                    "No adaptable gradients were produced."
                )

            optimizer.apply_gradients(
                pairs
            )

            predictions = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predictions != labels,
                    tf.float32,
                )
            )

            losses.append(
                float(loss.numpy())
            )
            bers.append(
                float(ber.numpy())
            )

        if not losses:
            raise RuntimeError(
                "No adaptation batches were generated."
            )

        history.append({
            "epoch": epoch + 1,
            "loss": float(
                np.mean(losses)
            ),
            "ber": float(
                np.mean(bers)
            ),
            "optimizer": "SGD",
            "learning_rate":
                learning_rate,
        })

    return history


def audit_custom_changes(
    *,
    model: tf.keras.Model,
    before: Mapping[
        str,
        List[np.ndarray],
    ],
    adaptable_layers: Tuple[str, ...],
) -> List[dict]:
    adaptable = set(
        adaptable_layers
    )

    rows: List[dict] = []

    for layer in model.layers:
        if layer.name not in before:
            continue

        old_values = before[
            layer.name
        ]

        new_values = [
            np.asarray(
                variable.numpy()
            ).copy()
            for variable in layer.weights
        ]

        if len(old_values) != len(
            new_values
        ):
            raise ValueError(
                f"Weight-count mismatch for {layer.name}"
            )

        if not old_values:
            continue

        old_flat = np.concatenate([
            value.reshape(-1)
            for value in old_values
        ])

        delta_flat = np.concatenate([
            (
                new_value
                - old_value
            ).reshape(-1)
            for (
                old_value,
                new_value,
            ) in zip(
                old_values,
                new_values,
            )
        ])

        delta_l2 = float(
            np.linalg.norm(
                delta_flat
            )
        )

        old_l2 = float(
            np.linalg.norm(
                old_flat
            )
        )

        rows.append({
            "layer_name":
                layer.name,
            "parameter_group":
                (
                    "adaptable_particular"
                    if layer.name
                    in adaptable
                    else "frozen_shared"
                ),
            "parameter_count":
                int(
                    delta_flat.size
                ),
            "delta_l2":
                delta_l2,
            "relative_delta_l2":
                (
                    delta_l2
                    / (
                        old_l2
                        + 1e-12
                    )
                ),
            "maximum_absolute_delta":
                float(
                    np.max(
                        np.abs(
                            delta_flat
                        )
                    )
                ),
        })

    return rows


def verify_custom_audit(
    rows: List[dict],
    frozen_tolerance: float = 1e-12,
    adaptable_tolerance: float = 1e-12,
) -> None:
    frozen_max = max(
        (
            row[
                "maximum_absolute_delta"
            ]
            for row in rows
            if row[
                "parameter_group"
            ] == "frozen_shared"
        ),
        default=0.0,
    )

    adaptable_max = max(
        (
            row[
                "maximum_absolute_delta"
            ]
            for row in rows
            if row[
                "parameter_group"
            ] == "adaptable_particular"
        ),
        default=0.0,
    )

    if frozen_max > frozen_tolerance:
        raise RuntimeError(
            "A frozen/shared parameter changed. "
            f"max change={frozen_max:.6e}"
        )

    if adaptable_max <= adaptable_tolerance:
        raise RuntimeError(
            "No adaptable particular parameter changed."
        )


def load_baseline1_checkpoint(
    *,
    model: tf.keras.Model,
    joint_root: Path,
    seed: int,
) -> Path:
    path = (
        joint_root
        / f"seed_{seed}"
        / "joint_model.npz"
    )

    if not path.exists():
        raise FileNotFoundError(
            "Missing Task 7.1 checkpoint: "
            f"{path}"
        )

    snapshot = load_snapshot_npz(
        path
    )

    restore_named_layers(
        model,
        snapshot,
    )

    return path


def plot_profile_comparison(
    *,
    baseline1: pd.DataFrame,
    improvement: pd.DataFrame,
    output_root: Path,
) -> None:
    plots = (
        output_root
        / "plots"
    )
    plots.mkdir(
        parents=True,
        exist_ok=True,
    )

    combined = pd.concat(
        [
            baseline1.assign(
                profile=(
                    "baseline1_no_adaptation"
                )
            ),
            improvement,
        ],
        ignore_index=True,
        sort=False,
    )

    summary = (
        combined
        .groupby(
            [
                "target_pdp",
                "snr_db",
                "profile",
            ],
            as_index=False,
        )
        .agg(
            mean_ber=(
                "ber",
                "mean",
            ),
            std_ber=(
                "ber",
                lambda x: float(
                    np.std(
                        np.asarray(x),
                        ddof=0,
                    )
                ),
            ),
        )
    )

    for target_pdp in sorted(
        summary[
            "target_pdp"
        ].unique()
    ):
        subset = summary[
            summary[
                "target_pdp"
            ] == target_pdp
        ]

        fig = plt.figure(
            figsize=(9, 6)
        )
        ax = fig.add_subplot(111)

        for profile in (
            subset[
                "profile"
            ].unique()
        ):
            rows = (
                subset[
                    subset[
                        "profile"
                    ] == profile
                ]
                .sort_values(
                    "snr_db"
                )
            )

            ax.errorbar(
                rows["snr_db"],
                rows["mean_ber"],
                yerr=rows["std_ber"],
                marker="o",
                capsize=3,
                label=profile,
            )

        ax.set_yscale(
            "log"
        )
        ax.set_xlabel(
            "SNR / Eb/N0 (dB)"
        )
        ax.set_ylabel(
            "Bit error rate"
        )
        ax.set_title(
            f"PDP{target_pdp}: "
            "Task 7.2 particular-layer expansion"
        )
        ax.grid(
            True,
            which="both",
            alpha=0.3,
        )
        ax.legend()

        fig.tight_layout()

        fig.savefig(
            plots
            / (
                f"PDP{target_pdp}"
                "_task72_improvement.png"
            ),
            dpi=300,
            bbox_inches="tight",
        )

        plt.close(
            fig
        )


def parse_arguments():
    config = Task7Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 7.2-improvement: decoder particular-layer "
            "expansion ablation for the ordinary joint-training baseline."
        )
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(
            config.seeds
        ),
    )

    parser.add_argument(
        "--profiles",
        nargs="+",
        choices=sorted(
            PROFILE_LAYERS
        ),
        default=[
            "original3",
            "tail2",
            "res2tail",
            "full_decoder",
        ],
    )

    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=2048,
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=1e-2,
    )

    parser.add_argument(
        "--query-blocks",
        type=int,
        default=8192,
    )

    parser.add_argument(
        "--joint-root",
        type=Path,
        default=(
            config.output_root
            / "01_joint_training"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / (
                "02b_particular_"
                "layer_expansion"
            )
        ),
    )

    return parser.parse_args()


def main() -> int:
    args = parse_arguments()

    if not args.seeds:
        raise ValueError(
            "At least one seed is required."
        )

    if (
        args.adaptation_blocks
        <= 0
        or args.epochs <= 0
        or args.learning_rate <= 0
        or args.query_blocks <= 0
    ):
        raise ValueError(
            "All numerical experiment settings must be positive."
        )

    config = Task7Config()
    pdps = get_known_pdps()

    all_rows: List[dict] = []
    all_audit_rows: List[dict] = []
    profile_rows: List[dict] = []

    # Parameter-count audit once.
    clean_model()
    audit_model = end_to_end()

    total_parameters = int(
        audit_model.count_params()
    )

    for profile in args.profiles:
        layers = validate_profile(
            audit_model,
            PROFILE_LAYERS[
                profile
            ],
        )

        adaptable_parameters = (
            count_profile_parameters(
                audit_model,
                layers,
            )
        )

        profile_rows.append({
            "profile":
                profile,
            "adaptable_layers":
                "|".join(
                    layers
                ),
            "adaptable_layer_count":
                len(layers),
            "adaptable_parameters":
                adaptable_parameters,
            "total_model_parameters":
                total_parameters,
            "adaptable_percentage":
                (
                    100.0
                    * adaptable_parameters
                    / total_parameters
                ),
        })

    write_csv(
        args.output_root
        / "profile_parameter_audit.csv",
        profile_rows,
    )

    for seed in args.seeds:
        for target_pdp_id in (
            config.unseen_pdps
        ):
            # Use the same support-set construction as Task 7.2.
            support_seed = (
                seed
                + 100000
                + target_pdp_id
                * 1000
            )

            support_dataset = build_dataset(
                pdp=pdps[
                    target_pdp_id
                ],
                pdp_id=(
                    target_pdp_id
                ),
                num_blocks=(
                    args.adaptation_blocks
                ),
                ebno_linear=(
                    config.training_ebno_linear
                ),
                seed=(
                    support_seed
                ),
            )

            for profile in (
                args.profiles
            ):
                adaptable_layers = (
                    PROFILE_LAYERS[
                        profile
                    ]
                )

                clean_model()
                set_deterministic(
                    seed
                )

                model = end_to_end()

                checkpoint_path = (
                    load_baseline1_checkpoint(
                        model=model,
                        joint_root=(
                            args.joint_root
                        ),
                        seed=seed,
                    )
                )

                before = (
                    snapshot_layer_arrays(
                        model
                    )
                )

                history = (
                    adapt_custom_particular(
                        model=model,
                        dataset=(
                            support_dataset
                        ),
                        adaptable_layers=(
                            adaptable_layers
                        ),
                        epochs=args.epochs,
                        learning_rate=(
                            args.learning_rate
                        ),
                        seed=(
                            support_seed
                        ),
                    )
                )

                audit_rows = (
                    audit_custom_changes(
                        model=model,
                        before=before,
                        adaptable_layers=(
                            adaptable_layers
                        ),
                    )
                )

                verify_custom_audit(
                    audit_rows
                )

                for row in audit_rows:
                    row.update({
                        "seed":
                            seed,
                        "target_pdp":
                            target_pdp_id,
                        "profile":
                            profile,
                    })

                all_audit_rows.extend(
                    audit_rows
                )

                snr_rows = (
                    evaluate_snr_sweep(
                        model=model,
                        pdps=pdps,
                        target_pdp_id=(
                            target_pdp_id
                        ),
                        snr_db_values=(
                            config.snr_db_values
                        ),
                        query_blocks=(
                            args.query_blocks
                        ),
                        seed=seed,
                        method=(
                            "joint_"
                            "expanded_particular_"
                            "adaptation"
                        ),
                    )
                )

                for row in snr_rows:
                    row.update({
                        "profile":
                            profile,
                        "adaptation_blocks":
                            args.adaptation_blocks,
                        "adaptation_epochs":
                            args.epochs,
                        "learning_rate":
                            args.learning_rate,
                        "adaptation_optimizer":
                            "SGD",
                        "shared_source":
                            (
                                "ordinary_joint_"
                                "training_PDP0_to_PDP5"
                            ),
                        "joint_checkpoint":
                            str(
                                checkpoint_path
                            ),
                        "adaptable_layers":
                            "|".join(
                                adaptable_layers
                            ),
                    })

                all_rows.extend(
                    snr_rows
                )

                print(
                    f"seed={seed} | "
                    f"PDP{target_pdp_id} | "
                    f"profile={profile} | "
                    f"layers={len(adaptable_layers)} | "
                    f"support BER="
                    f"{history[-1]['ber']:.6f}"
                )

                write_csv(
                    args.output_root
                    / (
                        "task72_improvement_"
                        "raw_partial.csv"
                    ),
                    all_rows,
                )

    raw_path = (
        args.output_root
        / "task72_improvement_raw.csv"
    )

    audit_path = (
        args.output_root
        / (
            "task72_improvement_"
            "parameter_change_audit.csv"
        )
    )

    write_csv(
        raw_path,
        all_rows,
    )

    write_csv(
        audit_path,
        all_audit_rows,
    )

    dataframe = pd.DataFrame(
        all_rows
    )

    summary = (
        dataframe
        .groupby(
            [
                "profile",
                "target_pdp",
                "snr_db",
            ],
            as_index=False,
        )
        .agg(
            seed_count=(
                "seed",
                "nunique",
            ),
            mean_ber=(
                "ber",
                "mean",
            ),
            std_ber=(
                "ber",
                lambda x: float(
                    np.std(
                        np.asarray(x),
                        ddof=0,
                    )
                ),
            ),
        )
    )

    summary.to_csv(
        args.output_root
        / (
            "task72_improvement_"
            "snr_summary.csv"
        ),
        index=False,
    )

    aggregate = (
        dataframe
        .assign(
            high_snr=(
                dataframe[
                    "snr_db"
                ] >= 10
            )
        )
        .groupby(
            "profile",
            as_index=False,
        )
        .agg(
            mean_ber_all=(
                "ber",
                "mean",
            ),
            pdp6_mean_ber=(
                "ber",
                lambda x: float(
                    dataframe.loc[
                        x.index
                    ][
                        dataframe.loc[
                            x.index,
                            "target_pdp",
                        ] == 6
                    ]["ber"].mean()
                ),
            ),
            pdp7_mean_ber=(
                "ber",
                lambda x: float(
                    dataframe.loc[
                        x.index
                    ][
                        dataframe.loc[
                            x.index,
                            "target_pdp",
                        ] == 7
                    ]["ber"].mean()
                ),
            ),
            high_snr_mean_ber=(
                "ber",
                lambda x: float(
                    dataframe.loc[
                        x.index
                    ][
                        dataframe.loc[
                            x.index,
                            "snr_db",
                        ] >= 10
                    ]["ber"].mean()
                ),
            ),
        )
        .sort_values(
            [
                "mean_ber_all",
                "high_snr_mean_ber",
            ]
        )
    )

    profile_audit = pd.DataFrame(
        profile_rows
    )

    aggregate = aggregate.merge(
        profile_audit[
            [
                "profile",
                "adaptable_layer_count",
                "adaptable_parameters",
                "adaptable_percentage",
            ]
        ],
        on="profile",
        how="left",
    )

    baseline1_path = (
        args.joint_root
        / (
            "joint_no_adaptation_"
            "snr_raw.csv"
        )
    )

    if not baseline1_path.exists():
        raise FileNotFoundError(
            baseline1_path
        )

    baseline1 = pd.read_csv(
        baseline1_path
    )

    baseline1_mean = float(
        baseline1[
            "ber"
        ].mean()
    )

    baseline1_high = float(
        baseline1[
            baseline1[
                "snr_db"
            ] >= 10
        ][
            "ber"
        ].mean()
    )

    aggregate[
        "baseline1_mean_ber"
    ] = baseline1_mean

    aggregate[
        "mean_ber_improvement_vs_baseline1"
    ] = (
        baseline1_mean
        - aggregate[
            "mean_ber_all"
        ]
    )

    aggregate[
        "baseline1_high_snr_mean_ber"
    ] = baseline1_high

    aggregate[
        "high_snr_improvement_vs_baseline1"
    ] = (
        baseline1_high
        - aggregate[
            "high_snr_mean_ber"
        ]
    )

    aggregate_path = (
        args.output_root
        / (
            "task72_improvement_"
            "profile_ranking.csv"
        )
    )

    aggregate.to_csv(
        aggregate_path,
        index=False,
    )

    plot_profile_comparison(
        baseline1=baseline1,
        improvement=dataframe,
        output_root=args.output_root,
    )

    (
        args.output_root
        / "experiment_definition.json"
    ).write_text(
        json.dumps(
            {
                "purpose": (
                    "Task 7.2-improvement ablation: "
                    "test whether a larger decoder-specific "
                    "adaptable subset improves the ordinary "
                    "joint-training baseline on unseen PDP6/PDP7."
                ),
                "important_fairness_note": (
                    "These expanded profiles do NOT redefine "
                    "the official Algorithm-1 partition. "
                    "Do not compare an expanded profile against "
                    "the current Algorithm-1 green curve as if "
                    "both used the same partition. For a formal "
                    "partition comparison, Task 6 must be retrained "
                    "with the same expanded particular set."
                ),
                "profiles": {
                    key: list(value)
                    for key, value
                    in PROFILE_LAYERS.items()
                    if key in args.profiles
                },
                "seeds":
                    args.seeds,
                "adaptation_blocks":
                    args.adaptation_blocks,
                "adaptation_epochs":
                    args.epochs,
                "learning_rate":
                    args.learning_rate,
                "optimizer":
                    "plain SGD",
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTask 7.2-improvement completed.")
    print("\nProfile ranking:")
    print(
        aggregate.to_string(
            index=False
        )
    )
    print("\nSaved:")
    print(raw_path)
    print(aggregate_path)
    print(
        args.output_root
        / "plots"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )
