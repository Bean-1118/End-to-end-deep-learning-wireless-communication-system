from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps
from src.task6.iadmm_state import (
    average_snapshots,
    load_snapshot_npz,
    restore_named_layers,
)
from src.task6.task6_parameter_groups import (
    validate_partition,
)
from src.task7.task7_common import (
    adapt_particular,
    audit_parameter_changes,
    build_dataset,
    clean_model,
    evaluate_snr_sweep,
    set_deterministic,
    snapshot_layer_arrays,
    verify_particular_only_audit,
    write_csv,
)
from src.task7.task7_config import Task7Config


SUPPORT_BATCH_SIZE = 512


METHOD_LABELS = {
    "joint_no_adaptation": "Joint training, no adaptation",
    "joint_particular_adaptation": "Joint training + particular adaptation",
    "algorithm1_particular_adaptation": "Algorithm 1 shared + particular adaptation",
}


def population_std(series: pd.Series) -> float:
    values = pd.to_numeric(series, errors="coerce").dropna()
    if values.empty:
        return float("nan")
    return float(values.std(ddof=0))


def parse_arguments():
    config = Task7Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 7 support-size analysis. For each target-support size, "
            "compare ordinary joint shared + particular-only SGD adaptation "
            "against Algorithm-1 shared + the exact same particular-only SGD "
            "adaptation. Baseline 1 is reused as a support-size-independent "
            "reference."
        )
    )

    parser.add_argument("--seeds", nargs="+", type=int, default=list(config.seeds))
    parser.add_argument(
        "--support-sizes",
        nargs="+",
        type=int,
        default=[512, 1024, 2048, 4096, 8192],
    )
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=1e-2)
    parser.add_argument("--query-blocks", type=int, default=8192)
    parser.add_argument(
        "--task6-training-root",
        type=Path,
        default=Path("outputs/task6/iadmm_training_revised"),
    )
    parser.add_argument(
        "--task7-1-root",
        type=Path,
        default=Path("outputs/task7/01_joint_training"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("outputs/task7/04_support_size_analysis"),
    )
    parser.add_argument("--expected-rho", type=float, default=1200.0)
    parser.add_argument("--expected-sigma", type=float, default=20.0)
    parser.add_argument("--expected-iterations", type=int, default=5000)

    return parser.parse_args()


def validate_arguments(args) -> None:
    if not args.seeds:
        raise ValueError("At least one seed is required.")
    if not args.support_sizes:
        raise ValueError("At least one support size is required.")
    if any(size <= 0 for size in args.support_sizes):
        raise ValueError("All support sizes must be positive.")
    if len(set(args.support_sizes)) != len(args.support_sizes):
        raise ValueError("Support sizes must be unique.")

    # make_fixed_adaptation_dataset() requires num_blocks to be a multiple of batch_size=512.
    invalid_support_sizes = [
        size
        for size in args.support_sizes
        if size % SUPPORT_BATCH_SIZE != 0
    ]

    if invalid_support_sizes:
        raise ValueError(
            "Every --support-sizes value must be a positive multiple "
            f"of {SUPPORT_BATCH_SIZE}, because the existing fixed "
            "adaptation dataset uses batch_size=512. "
            f"Invalid values: {invalid_support_sizes}. "
            "Recommended values: 512 1024 2048 4096 8192."
        )
    if args.epochs <= 0:
        raise ValueError("--epochs must be positive.")
    if args.learning_rate <= 0:
        raise ValueError("--learning-rate must be positive.")
    if args.query_blocks <= 0:
        raise ValueError("--query-blocks must be positive.")


def validate_task6_checkpoint(
    training_directory: Path,
    expected_rho: float,
    expected_sigma: float,
    expected_iterations: int,
) -> dict:
    metadata_path = training_directory / "metadata.json"

    if not metadata_path.exists():
        raise FileNotFoundError(metadata_path)

    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))

    rho = float(metadata["rho"])
    sigma = float(metadata["sigma"])
    iterations = int(metadata["iterations_requested"])

    if not np.isclose(rho, expected_rho):
        raise ValueError(
            f"Wrong rho in {metadata_path}: expected={expected_rho}, actual={rho}"
        )

    if not np.isclose(sigma, expected_sigma):
        raise ValueError(
            f"Wrong sigma in {metadata_path}: expected={expected_sigma}, actual={sigma}"
        )

    if iterations != expected_iterations:
        raise ValueError(
            f"Wrong iterations in {metadata_path}: "
            f"expected={expected_iterations}, actual={iterations}"
        )

    return metadata


def load_joint_model(*, model, joint_root: Path, seed: int) -> Path:
    path = joint_root / f"seed_{seed}" / "joint_model.npz"

    if not path.exists():
        raise FileNotFoundError(f"Missing Task 7.1 checkpoint: {path}")

    snapshot = load_snapshot_npz(path)
    restore_named_layers(model, snapshot)
    return path


def load_algorithm1_state(
    *,
    task6_root: Path,
    seed: int,
    train_pdps,
    expected_rho: float,
    expected_sigma: float,
    expected_iterations: int,
):
    training_directory = task6_root / f"seed_{seed}"

    metadata = validate_task6_checkpoint(
        training_directory=training_directory,
        expected_rho=expected_rho,
        expected_sigma=expected_sigma,
        expected_iterations=expected_iterations,
    )

    shared_path = training_directory / "global_shared_w.npz"
    if not shared_path.exists():
        raise FileNotFoundError(shared_path)

    shared = load_snapshot_npz(shared_path)

    historical_v = []

    for pdp_id in train_pdps:
        path = training_directory / "particular" / f"PDP{pdp_id}_v_i.npz"

        if not path.exists():
            raise FileNotFoundError(path)

        historical_v.append(load_snapshot_npz(path))

    v_initial = average_snapshots(historical_v)

    return shared, v_initial, metadata


def run_one_adaptation(
    *,
    model,
    support_dataset,
    epochs: int,
    learning_rate: float,
    adaptation_seed: int,
):
    before = snapshot_layer_arrays(model)

    history = adapt_particular(
        model=model,
        dataset=support_dataset,
        epochs=epochs,
        learning_rate=learning_rate,
        seed=adaptation_seed,
    )

    audit_rows = audit_parameter_changes(model, before)
    verify_particular_only_audit(audit_rows)

    return history, audit_rows


def make_support_dataset(
    *,
    pdps,
    target_pdp_id: int,
    support_size: int,
    support_seed: int,
    ebno_linear: float,
):
    return build_dataset(
        pdp=pdps[target_pdp_id],
        pdp_id=target_pdp_id,
        num_blocks=support_size,
        ebno_linear=ebno_linear,
        seed=support_seed,
    )


def aggregate_results(raw: pd.DataFrame) -> pd.DataFrame:
    return (
        raw.groupby(
            ["method", "support_size", "target_pdp", "snr_db"],
            as_index=False,
        )
        .agg(
            seed_count=("seed", "nunique"),
            mean_ber=("ber", "mean"),
            std_ber=("ber", population_std),
            min_ber=("ber", "min"),
            max_ber=("ber", "max"),
        )
        .sort_values(["method", "support_size", "target_pdp", "snr_db"])
    )


def make_support_ranking(raw: pd.DataFrame) -> pd.DataFrame:
    adapted = raw[raw["support_size"] > 0].copy()

    rows = []

    for (method, support_size), group in adapted.groupby(
        ["method", "support_size"]
    ):
        row = {
            "method": method,
            "support_size": int(support_size),
            "mean_ber_all": float(group["ber"].mean()),
            "high_snr_mean_ber": float(
                group.loc[group["snr_db"] >= 10, "ber"].mean()
            ),
            "pdp6_mean_ber": float(
                group.loc[group["target_pdp"] == 6, "ber"].mean()
            ),
            "pdp7_mean_ber": float(
                group.loc[group["target_pdp"] == 7, "ber"].mean()
            ),
        }

        for snr in [10.0, 14.0, 20.0]:
            snr_rows = group[np.isclose(group["snr_db"], snr)]
            if not snr_rows.empty:
                row[f"mean_ber_at_{int(snr)}dB"] = float(
                    snr_rows["ber"].mean()
                )

        rows.append(row)

    return pd.DataFrame(rows).sort_values(["method", "support_size"])


def save_method_support_plots(
    summary: pd.DataFrame,
    raw: pd.DataFrame,
    output_root: Path,
) -> None:
    plots_root = output_root / "plots"
    plots_root.mkdir(parents=True, exist_ok=True)

    adapted_methods = [
        "joint_particular_adaptation",
        "algorithm1_particular_adaptation",
    ]

    # A. BER-vs-SNR, one curve per support size, separately for each method.
    for method in adapted_methods:
        for target_pdp in sorted(summary["target_pdp"].unique()):
            subset = summary[
                (summary["method"] == method)
                & (summary["target_pdp"] == target_pdp)
            ]

            fig = plt.figure(figsize=(9, 6))
            ax = fig.add_subplot(111)

            for support_size in sorted(subset["support_size"].unique()):
                rows = subset[
                    subset["support_size"] == support_size
                ].sort_values("snr_db")

                ax.errorbar(
                    rows["snr_db"],
                    rows["mean_ber"],
                    yerr=rows["std_ber"],
                    marker="o",
                    capsize=3,
                    label=f"{int(support_size)} support blocks",
                )

            ax.set_yscale("log")
            ax.set_xlabel("SNR / Eb/N0 (dB)")
            ax.set_ylabel("Bit error rate")
            ax.set_title(
                f"PDP{target_pdp}: {METHOD_LABELS[method]} versus support size"
            )
            ax.grid(True, which="both", alpha=0.3)
            ax.legend()
            fig.tight_layout()

            fig.savefig(
                plots_root
                / f"A_PDP{target_pdp}_{method}_support_size_ber_vs_snr.png",
                dpi=300,
                bbox_inches="tight",
            )
            plt.close(fig)

    # B. Three-method BER-vs-SNR figure for every support size.
    baseline = summary[summary["method"] == "joint_no_adaptation"]

    support_sizes = sorted(
        summary.loc[summary["support_size"] > 0, "support_size"].unique()
    )

    for support_size in support_sizes:
        for target_pdp in sorted(summary["target_pdp"].unique()):
            fig = plt.figure(figsize=(9, 6))
            ax = fig.add_subplot(111)

            baseline_rows = baseline[
                baseline["target_pdp"] == target_pdp
            ].sort_values("snr_db")

            ax.errorbar(
                baseline_rows["snr_db"],
                baseline_rows["mean_ber"],
                yerr=baseline_rows["std_ber"],
                marker="o",
                capsize=3,
                label=METHOD_LABELS["joint_no_adaptation"],
            )

            for method in adapted_methods:
                rows = summary[
                    (summary["method"] == method)
                    & (summary["target_pdp"] == target_pdp)
                    & (summary["support_size"] == support_size)
                ].sort_values("snr_db")

                ax.errorbar(
                    rows["snr_db"],
                    rows["mean_ber"],
                    yerr=rows["std_ber"],
                    marker="o",
                    capsize=3,
                    label=METHOD_LABELS[method],
                )

            ax.set_yscale("log")
            ax.set_xlabel("SNR / Eb/N0 (dB)")
            ax.set_ylabel("Bit error rate")
            ax.set_title(
                f"PDP{target_pdp}: {int(support_size)} target support blocks"
            )
            ax.grid(True, which="both", alpha=0.3)
            ax.legend()
            fig.tight_layout()

            fig.savefig(
                plots_root
                / (
                    f"B_PDP{target_pdp}_support_{int(support_size)}_"
                    "three_method_ber_vs_snr.png"
                ),
                dpi=300,
                bbox_inches="tight",
            )
            plt.close(fig)

    # C. Support size vs BER at selected SNR values.
    for target_pdp in sorted(summary["target_pdp"].unique()):
        fig = plt.figure(figsize=(9, 6))
        ax = fig.add_subplot(111)

        for method in adapted_methods:
            for snr in [10.0, 14.0, 20.0]:
                rows = summary[
                    (summary["method"] == method)
                    & (summary["target_pdp"] == target_pdp)
                    & np.isclose(summary["snr_db"], snr)
                ].sort_values("support_size")

                ax.plot(
                    rows["support_size"],
                    rows["mean_ber"],
                    marker="o",
                    label=f"{METHOD_LABELS[method]} @ {int(snr)} dB",
                )

        ax.set_xscale("log", base=2)
        ax.set_xlabel("Number of target support blocks")
        ax.set_ylabel("Bit error rate")
        ax.set_title(
            f"PDP{target_pdp}: effect of target sample quantity"
        )
        ax.grid(True, which="both", alpha=0.3)
        ax.legend(fontsize=8)
        fig.tight_layout()

        fig.savefig(
            plots_root
            / f"C_PDP{target_pdp}_support_size_effect_selected_snr.png",
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig)

    # D. Overall BER across PDP6/PDP7 and complete SNR sweep vs support size.
    ranking = make_support_ranking(raw)

    fig = plt.figure(figsize=(9, 6))
    ax = fig.add_subplot(111)

    for method in adapted_methods:
        rows = ranking[
            ranking["method"] == method
        ].sort_values("support_size")

        ax.plot(
            rows["support_size"],
            rows["mean_ber_all"],
            marker="o",
            label=METHOD_LABELS[method],
        )

    ax.set_xscale("log", base=2)
    ax.set_xlabel("Number of target support blocks")
    ax.set_ylabel("Mean BER across PDP6/PDP7 and SNR sweep")
    ax.set_title("Target-sample quantity versus overall BER")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()

    fig.savefig(
        plots_root / "D_support_size_vs_overall_ber.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task7Config()
    pdps = get_known_pdps()

    raw_rows = []
    audit_rows_all = []
    run_metadata = []

    baseline1_path = (
        args.task7_1_root
        / "joint_no_adaptation_snr_raw.csv"
    )

    if not baseline1_path.exists():
        raise FileNotFoundError(baseline1_path)

    baseline1 = pd.read_csv(baseline1_path).copy()
    baseline1["support_size"] = 0

    raw_rows.extend(baseline1.to_dict("records"))

    for seed in args.seeds:
        (
            algorithm_shared,
            algorithm_v_initial,
            task6_metadata,
        ) = load_algorithm1_state(
            task6_root=args.task6_training_root,
            seed=seed,
            train_pdps=config.train_pdps,
            expected_rho=args.expected_rho,
            expected_sigma=args.expected_sigma,
            expected_iterations=args.expected_iterations,
        )

        for target_pdp_id in config.unseen_pdps:
            # Keep the random support environment fixed while changing N.
            support_seed = (
                seed
                + 100000
                + target_pdp_id * 1000
            )

            for support_size in sorted(args.support_sizes):
                support_dataset = make_support_dataset(
                    pdps=pdps,
                    target_pdp_id=target_pdp_id,
                    support_size=support_size,
                    support_seed=support_seed,
                    ebno_linear=config.training_ebno_linear,
                )

                # Baseline 2.
                clean_model()
                set_deterministic(seed)

                joint_model = end_to_end()
                validate_partition(joint_model)

                joint_checkpoint = load_joint_model(
                    model=joint_model,
                    joint_root=args.task7_1_root,
                    seed=seed,
                )

                joint_history, joint_audit = run_one_adaptation(
                    model=joint_model,
                    support_dataset=support_dataset,
                    epochs=args.epochs,
                    learning_rate=args.learning_rate,
                    adaptation_seed=support_seed,
                )

                for row in joint_audit:
                    row.update(
                        {
                            "seed": seed,
                            "target_pdp": target_pdp_id,
                            "support_size": support_size,
                            "method": "joint_particular_adaptation",
                        }
                    )

                audit_rows_all.extend(joint_audit)

                joint_rows = evaluate_snr_sweep(
                    model=joint_model,
                    pdps=pdps,
                    target_pdp_id=target_pdp_id,
                    snr_db_values=config.snr_db_values,
                    query_blocks=args.query_blocks,
                    seed=seed,
                    method="joint_particular_adaptation",
                )

                for row in joint_rows:
                    row.update(
                        {
                            "support_size": support_size,
                            "adaptation_blocks": support_size,
                            "adaptation_epochs": args.epochs,
                            "learning_rate": args.learning_rate,
                            "adaptation_optimizer": "SGD",
                            "shared_source":
                                "ordinary_joint_training_PDP0_to_PDP5",
                        }
                    )

                raw_rows.extend(joint_rows)

                # Algorithm 1.
                clean_model()
                set_deterministic(seed)

                alg_model = end_to_end()
                validate_partition(alg_model)

                restore_named_layers(
                    alg_model,
                    algorithm_shared,
                )
                restore_named_layers(
                    alg_model,
                    algorithm_v_initial,
                )

                alg_history, alg_audit = run_one_adaptation(
                    model=alg_model,
                    support_dataset=support_dataset,
                    epochs=args.epochs,
                    learning_rate=args.learning_rate,
                    adaptation_seed=support_seed,
                )

                for row in alg_audit:
                    row.update(
                        {
                            "seed": seed,
                            "target_pdp": target_pdp_id,
                            "support_size": support_size,
                            "method":
                                "algorithm1_particular_adaptation",
                        }
                    )

                audit_rows_all.extend(alg_audit)

                alg_rows = evaluate_snr_sweep(
                    model=alg_model,
                    pdps=pdps,
                    target_pdp_id=target_pdp_id,
                    snr_db_values=config.snr_db_values,
                    query_blocks=args.query_blocks,
                    seed=seed,
                    method="algorithm1_particular_adaptation",
                )

                for row in alg_rows:
                    row.update(
                        {
                            "support_size": support_size,
                            "adaptation_blocks": support_size,
                            "adaptation_epochs": args.epochs,
                            "learning_rate": args.learning_rate,
                            "adaptation_optimizer": "SGD",
                            "shared_source":
                                "Algorithm1_iADMM_PDP0_to_PDP5",
                            "rho": args.expected_rho,
                            "sigma": args.expected_sigma,
                            "iadmm_iterations":
                                args.expected_iterations,
                        }
                    )

                raw_rows.extend(alg_rows)

                run_metadata.append(
                    {
                        "seed": seed,
                        "target_pdp": target_pdp_id,
                        "support_size": support_size,
                        "support_seed": support_seed,
                        "epochs": args.epochs,
                        "learning_rate": args.learning_rate,
                        "query_blocks": args.query_blocks,
                        "joint_checkpoint": str(joint_checkpoint),
                        "algorithm1_rho": float(task6_metadata["rho"]),
                        "algorithm1_sigma": float(task6_metadata["sigma"]),
                        "algorithm1_iterations": int(
                            task6_metadata["iterations_requested"]
                        ),
                        "algorithm1_best_iteration": int(
                            task6_metadata["best_iteration"]
                        ),
                        "joint_final_support_ber": float(
                            joint_history[-1]["ber"]
                        ),
                        "algorithm1_final_support_ber": float(
                            alg_history[-1]["ber"]
                        ),
                    }
                )

                print(
                    f"seed={seed} | PDP{target_pdp_id} | "
                    f"support={support_size} | "
                    f"joint support BER={joint_history[-1]['ber']:.6f} | "
                    f"Algorithm1 support BER={alg_history[-1]['ber']:.6f}"
                )

                write_csv(
                    args.output_root / "support_size_raw_partial.csv",
                    raw_rows,
                )
                write_csv(
                    args.output_root / "parameter_change_audit_partial.csv",
                    audit_rows_all,
                )

    args.output_root.mkdir(parents=True, exist_ok=True)

    raw_path = args.output_root / "support_size_raw.csv"
    write_csv(raw_path, raw_rows)

    write_csv(
        args.output_root / "parameter_change_audit.csv",
        audit_rows_all,
    )

    (
        args.output_root / "run_metadata.json"
    ).write_text(
        json.dumps(run_metadata, indent=2),
        encoding="utf-8",
    )

    raw = pd.DataFrame(raw_rows)

    summary = aggregate_results(raw)
    summary_path = (
        args.output_root
        / "support_size_snr_summary.csv"
    )
    summary.to_csv(summary_path, index=False)

    ranking = make_support_ranking(raw)
    ranking_path = (
        args.output_root
        / "support_size_ranking.csv"
    )
    ranking.to_csv(ranking_path, index=False)

    save_method_support_plots(
        summary=summary,
        raw=raw,
        output_root=args.output_root,
    )

    (
        args.output_root / "experiment_definition.json"
    ).write_text(
        json.dumps(
            {
                "purpose": (
                    "Study how unseen-environment target-support sample "
                    "quantity affects Baseline 2 and Algorithm-1 transfer."
                ),
                "support_sizes": sorted(args.support_sizes),
                "support_batch_size_constraint": SUPPORT_BATCH_SIZE,
                "seeds": args.seeds,
                "targets": list(config.unseen_pdps),
                "epochs": args.epochs,
                "optimizer": "plain SGD",
                "learning_rate": args.learning_rate,
                "query_blocks": args.query_blocks,
                "fairness_controls": [
                    "same support seed for both methods",
                    "same support size",
                    "same adaptation epochs",
                    "same SGD learning rate",
                    "same particular-only trainable subset",
                    "same query generator and SNR sweep",
                    "Baseline 1 is reused and has support_size=0",
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTask 7 support-size analysis completed.")
    print(f"Raw: {raw_path}")
    print(f"Summary: {summary_path}")
    print(f"Ranking: {ranking_path}")
    print(f"Plots: {args.output_root / 'plots'}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())