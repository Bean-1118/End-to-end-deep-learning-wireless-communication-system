from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Tuple


PROJECT_ROOT = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Task7Config:
    train_pdps: Tuple[int, ...] = (0, 1, 2, 3, 4, 5)
    unseen_pdps: Tuple[int, ...] = (6, 7)
    seeds: Tuple[int, ...] = (2026, 2027, 2028)

    # Same fixed support-training condition used in Task 6.
    training_ebno_linear: float = 20.0

    snr_db_values: Tuple[float, ...] = (
        0.0, 2.0, 4.0, 6.0, 8.0, 10.0,
        12.0, 14.0, 16.0, 18.0, 20.0,
    )

    joint_blocks_per_pdp: int = 4096
    validation_blocks_per_pdp: int = 4096
    query_blocks_per_snr: int = 8192

    adaptation_blocks: int = 2048
    joint_epochs: int = 100
    adaptation_epochs: int = 20

    joint_learning_rate: float = 1e-4
    adaptation_learning_rate: float = 1e-4

    output_root: Path = PROJECT_ROOT / "outputs" / "task7"

    # Task 6 output directory.
    task6_training_root: Path = (
        PROJECT_ROOT
        / "outputs"
        / "task6"
        / "iadmm_training_revised"
    )
