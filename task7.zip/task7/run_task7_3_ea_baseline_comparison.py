from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps
from src.task4.fixed_adaptation import (
    make_fixed_adaptation_dataset,
)
from src.task6.iadmm_state import (
    average_snapshots,
    load_snapshot_npz,
    restore_named_layers,
)
from src.task6.task6_parameter_groups import (
    validate_partition,
)
from src.task7.task7_common import (
    adapt_particular,
    audit_parameter_changes,
    clean_model,
    evaluate_snr_sweep,
    set_deterministic,
    snapshot_layer_arrays,
    verify_particular_only_audit,
    write_csv,
)
from src.task7.task7_config import Task7Config


REQUIRED_COLUMNS = {
    "seed",
    "target_pdp",
    "snr_db",
    "method",
    "ber",
}


def population_std(
    series: pd.Series,
) -> float:
    values = pd.to_numeric(
        series,
        errors="coerce",
    ).dropna()

    if values.empty:
        return float("nan")

    return float(
        values.std(ddof=0)
    )


def validate_merge_input(
    dataframe: pd.DataFrame,
    name: str,
    expected_method: str,
    seeds: list[int],
    targets: tuple[int, ...],
    snr_values: tuple[float, ...],
) -> None:
    missing = (
        REQUIRED_COLUMNS
        - set(dataframe.columns)
    )

    if missing:
        raise ValueError(
            f"{name} missing columns: "
            f"{sorted(missing)}"
        )

    methods = set(
        dataframe[
            "method"
        ].astype(str).unique()
    )

    if methods != {
        expected_method
    }:
        raise ValueError(
            f"{name} method mismatch: "
            f"expected={expected_method}, "
            f"actual={sorted(methods)}"
        )

    actual_seeds = set(
        dataframe[
            "seed"
        ].astype(int).unique()
    )

    if actual_seeds != set(seeds):
        raise ValueError(
            f"{name} seed mismatch: "
            f"expected={sorted(seeds)}, "
            f"actual={sorted(actual_seeds)}"
        )

    actual_targets = set(
        dataframe[
            "target_pdp"
        ].astype(int).unique()
    )

    if actual_targets != set(
        targets
    ):
        raise ValueError(
            f"{name} target mismatch: "
            f"expected={sorted(targets)}, "
            f"actual={sorted(actual_targets)}"
        )

    actual_snr = set(
        pd.to_numeric(
            dataframe["snr_db"]
        ).astype(float).unique()
    )

    expected_snr = set(
        float(value)
        for value in snr_values
    )

    if actual_snr != expected_snr:
        raise ValueError(
            f"{name} SNR mismatch: "
            f"expected={sorted(expected_snr)}, "
            f"actual={sorted(actual_snr)}"
        )

    expected_rows = (
        len(seeds)
        * len(targets)
        * len(snr_values)
    )

    if len(dataframe) != expected_rows:
        raise ValueError(
            f"{name} row-count mismatch: "
            f"expected={expected_rows}, "
            f"actual={len(dataframe)}"
        )


def validate_baseline_settings(
    baseline1: pd.DataFrame,
    baseline2: pd.DataFrame,
    adaptation_blocks: int,
    adaptation_epochs: int,
    adaptation_learning_rate: float,
) -> None:
    """
    Validate optimizer and adaptation settings before combining baseline and Algorithm-1 results.
    """

    # Validate the Task 7.1 optimizer when the column is present.
    if "training_optimizer" in baseline1.columns:
        values = set(
            baseline1[
                "training_optimizer"
            ].astype(str).unique()
        )

        if values != {"SGD"}:
            raise ValueError(
                "Task 7.1 is not the SGD baseline. "
                f"Found training_optimizer={sorted(values)}"
            )

    # Validate the Task 7.2 adaptation optimizer.
    if "adaptation_optimizer" in baseline2.columns:
        values = set(
            baseline2[
                "adaptation_optimizer"
            ].astype(str).unique()
        )

        if values != {"SGD"}:
            raise ValueError(
                "Task 7.2 is not using SGD adaptation. "
                f"Found adaptation_optimizer={sorted(values)}"
            )

    if "adaptation_blocks" in baseline2.columns:
        values = set(
            pd.to_numeric(
                baseline2[
                    "adaptation_blocks"
                ]
            ).astype(int).unique()
        )

        if values != {
            int(adaptation_blocks)
        }:
            raise ValueError(
                "Task 7.2 adaptation-block mismatch: "
                f"expected={adaptation_blocks}, "
                f"actual={sorted(values)}"
            )

    if "adaptation_epochs" in baseline2.columns:
        values = set(
            pd.to_numeric(
                baseline2[
                    "adaptation_epochs"
                ]
            ).astype(int).unique()
        )

        if values != {
            int(adaptation_epochs)
        }:
            raise ValueError(
                "Task 7.2 adaptation-epoch mismatch: "
                f"expected={adaptation_epochs}, "
                f"actual={sorted(values)}"
            )

    if "learning_rate" in baseline2.columns:
        values = set(
            np.round(
                pd.to_numeric(
                    baseline2[
                        "learning_rate"
                    ]
                ).astype(float),
                decimals=12,
            ).unique()
        )

        expected = round(
            float(
                adaptation_learning_rate
            ),
            12,
        )

        if values != {
            expected
        }:
            raise ValueError(
                "Task 7.2 adaptation-LR mismatch: "
                f"expected={expected}, "
                f"actual={sorted(values)}"
            )


def validate_task6_checkpoint(
    *,
    training_directory: Path,
    expected_rho: float,
    expected_sigma: float,
    expected_iterations: int,
) -> dict:
    metadata_path = (
        training_directory
        / "metadata.json"
    )

    if not metadata_path.exists():
        raise FileNotFoundError(
            "Missing Task-6 metadata: "
            f"{metadata_path}"
        )

    metadata = json.loads(
        metadata_path.read_text(
            encoding="utf-8"
        )
    )

    rho = float(
        metadata["rho"]
    )
    sigma = float(
        metadata["sigma"]
    )
    iterations = int(
        metadata[
            "iterations_requested"
        ]
    )

    if not np.isclose(
        rho,
        expected_rho,
    ):
        raise ValueError(
            "Wrong Algorithm-1 rho checkpoint: "
            f"expected={expected_rho}, "
            f"actual={rho}"
        )

    if not np.isclose(
        sigma,
        expected_sigma,
    ):
        raise ValueError(
            "Wrong Algorithm-1 sigma checkpoint: "
            f"expected={expected_sigma}, "
            f"actual={sigma}"
        )

    if iterations != (
        expected_iterations
    ):
        raise ValueError(
            "Wrong Algorithm-1 iteration count: "
            f"expected={expected_iterations}, "
            f"actual={iterations}"
        )

    return metadata


def save_figures(
    summary: pd.DataFrame,
    output_root: Path,
) -> None:
    labels = {
        "joint_no_adaptation":
            "Joint training, no adaptation",
        "joint_particular_adaptation":
            "Joint training + particular adaptation",
        "algorithm1_particular_adaptation":
            "Algorithm 1 shared + particular adaptation",
    }

    method_order = [
        "joint_no_adaptation",
        "joint_particular_adaptation",
        "algorithm1_particular_adaptation",
    ]

    plots_root = (
        output_root
        / "plots"
    )

    plots_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    for target_pdp in sorted(
        summary[
            "target_pdp"
        ].unique()
    ):
        subset = summary[
            summary[
                "target_pdp"
            ] == target_pdp
        ]

        figure, axis = (
            plt.subplots(
                figsize=(
                    8.5,
                    5.5,
                )
            )
        )

        for method in (
            method_order
        ):
            method_rows = (
                subset[
                    subset[
                        "method"
                    ] == method
                ]
                .sort_values(
                    "snr_db"
                )
            )

            if method_rows.empty:
                raise RuntimeError(
                    "Missing plot data for "
                    f"{method}, PDP{target_pdp}."
                )

            axis.errorbar(
                method_rows[
                    "snr_db"
                ],
                method_rows[
                    "mean_ber"
                ],
                yerr=method_rows[
                    "std_ber"
                ],
                marker="o",
                capsize=3,
                label=labels[
                    method
                ],
            )

        axis.set_yscale(
            "log"
        )
        axis.set_xlabel(
            "SNR / Eb/N0 (dB)"
        )
        axis.set_ylabel(
            "Bit error rate"
        )
        axis.set_title(
            f"PDP{target_pdp}: "
            "BER versus SNR"
        )
        axis.grid(
            True,
            which="both",
            alpha=0.3,
        )
        axis.legend()

        figure.tight_layout()

        figure.savefig(
            plots_root
            / (
                f"PDP{target_pdp}"
                "_ber_vs_snr.png"
            ),
            dpi=300,
            bbox_inches="tight",
        )

        plt.close(
            figure
        )


def parse_arguments():
    config = Task7Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 7.3: evaluate the paper-corrected Algorithm-1 "
            "shared representation on PDP6/PDP7. The exact same "
            "particular-only SGD adaptation protocol as Task 7.2 "
            "is used, then all three Task-7 methods are merged."
        )
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(
            config.seeds
        ),
    )

    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=(
            config.adaptation_blocks
        ),
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=(
            config.adaptation_epochs
        ),
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=(
            config
            .adaptation_learning_rate
        ),
    )

    parser.add_argument(
        "--query-blocks",
        type=int,
        default=(
            config
            .query_blocks_per_snr
        ),
    )

    parser.add_argument(
        "--task6-training-root",
        type=Path,
        default=(
            config
            .task6_training_root
        ),
    )

    parser.add_argument(
        "--task7-1-root",
        type=Path,
        default=(
            config.output_root
            / "01_joint_training"
        ),
    )

    parser.add_argument(
        "--task7-2-root",
        type=Path,
        default=(
            config.output_root
            / (
                "02_joint_"
                "particular_adaptation"
            )
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / (
                "03_algorithm1_"
                "baseline_comparison"
            )
        ),
    )

    parser.add_argument(
        "--expected-rho",
        type=float,
        default=1200.0,
    )

    parser.add_argument(
        "--expected-sigma",
        type=float,
        default=20.0,
    )

    parser.add_argument(
        "--expected-iterations",
        type=int,
        default=5000,
    )

    return parser.parse_args()


def validate_arguments(
    args,
) -> None:
    if not args.seeds:
        raise ValueError(
            "At least one seed is required."
        )

    if (
        args.adaptation_blocks
        <= 0
    ):
        raise ValueError(
            "--adaptation-blocks must "
            "be positive."
        )

    if args.epochs <= 0:
        raise ValueError(
            "--epochs must be positive."
        )

    if (
        args.learning_rate
        <= 0
    ):
        raise ValueError(
            "--learning-rate must "
            "be positive."
        )

    if args.query_blocks <= 0:
        raise ValueError(
            "--query-blocks must "
            "be positive."
        )

    if (
        args.expected_rho
        <= 0
        or args.expected_sigma
        <= 0
    ):
        raise ValueError(
            "Expected rho and sigma "
            "must be positive."
        )

    if (
        args.expected_iterations
        <= 0
    ):
        raise ValueError(
            "Expected iterations "
            "must be positive."
        )


def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task7Config()
    pdps = get_known_pdps()

    algorithm_rows: list[
        dict
    ] = []

    all_audit_rows: list[
        dict
    ] = []

    run_metadata: list[
        dict
    ] = []

    for seed in args.seeds:
        training_directory = (
            args.task6_training_root
            / f"seed_{seed}"
        )

        task6_metadata = (
            validate_task6_checkpoint(
                training_directory=(
                    training_directory
                ),
                expected_rho=(
                    args.expected_rho
                ),
                expected_sigma=(
                    args.expected_sigma
                ),
                expected_iterations=(
                    args.expected_iterations
                ),
            )
        )

        shared_path = (
            training_directory
            / "global_shared_w.npz"
        )

        if not shared_path.exists():
            raise FileNotFoundError(
                "Missing Algorithm-1 shared checkpoint: "
                f"{shared_path}"
            )

        w_star = (
            load_snapshot_npz(
                shared_path
            )
        )

        historical_particular = []

        for pdp_id in (
            config.train_pdps
        ):
            path = (
                training_directory
                / "particular"
                / (
                    f"PDP{pdp_id}"
                    "_v_i.npz"
                )
            )

            if not path.exists():
                raise FileNotFoundError(
                    "Missing Algorithm-1 "
                    "particular checkpoint: "
                    f"{path}"
                )

            historical_particular.append(
                load_snapshot_npz(
                    path
                )
            )

        # Initialize the new-environment particular subset from the mean historical v_i.
        v_initial = (
            average_snapshots(
                historical_particular
            )
        )

        run_metadata.append({
            "seed":
                seed,
            "rho":
                float(
                    task6_metadata[
                        "rho"
                    ]
                ),
            "sigma":
                float(
                    task6_metadata[
                        "sigma"
                    ]
                ),
            "iterations_requested":
                int(
                    task6_metadata[
                        "iterations_requested"
                    ]
                ),
            "best_iteration":
                int(
                    task6_metadata[
                        "best_iteration"
                    ]
                ),
            "best_mean_validation_ber":
                float(
                    task6_metadata[
                        "best_mean_validation_ber"
                    ]
                ),
            "particular_initialisation":
                "historical_mean",
            "adaptation_optimizer":
                "SGD",
            "adaptation_blocks":
                args.adaptation_blocks,
            "adaptation_epochs":
                args.epochs,
            "adaptation_learning_rate":
                args.learning_rate,
        })

        for target_pdp_id in (
            config.unseen_pdps
        ):
            # Use the same support-seed formula as Task 7.2.
            support_seed = (
                seed
                + 100000
                + target_pdp_id
                * 1000
            )

            support_dataset = (
                make_fixed_adaptation_dataset(
                    pdp_target=(
                        pdps[
                            target_pdp_id
                        ]
                    ),
                    pdp_id=(
                        target_pdp_id
                    ),
                    num_blocks=(
                        args
                        .adaptation_blocks
                    ),
                    ebno_linear=(
                        config
                        .training_ebno_linear
                    ),
                    seed=(
                        support_seed
                    ),
                )
            )

            clean_model()
            set_deterministic(
                seed
            )

            model = end_to_end()

            validate_partition(
                model
            )

            # Load Algorithm-1 shared parameters and the new-environment particular initialization.
            # adapt_particular() keeps the shared subset frozen.
            restore_named_layers(
                model,
                w_star,
            )

            restore_named_layers(
                model,
                v_initial,
            )

            before = (
                snapshot_layer_arrays(
                    model
                )
            )

            # Task 7.2 and Task 7.3 use the same SGD adaptation protocol with shared layers frozen.
            history = (
                adapt_particular(
                    model=model,
                    dataset=(
                        support_dataset
                    ),
                    epochs=(
                        args.epochs
                    ),
                    learning_rate=(
                        args.learning_rate
                    ),
                    seed=(
                        support_seed
                    ),
                )
            )

            audit_rows = (
                audit_parameter_changes(
                    model,
                    before,
                )
            )

            verify_particular_only_audit(
                audit_rows
            )

            for row in audit_rows:
                row.update({
                    "seed":
                        seed,
                    "target_pdp":
                        target_pdp_id,
                    "method":
                        (
                            "algorithm1_"
                            "particular_"
                            "adaptation"
                        ),
                    "adaptation_blocks":
                        args
                        .adaptation_blocks,
                    "adaptation_epochs":
                        args.epochs,
                    "learning_rate":
                        args.learning_rate,
                    "adaptation_optimizer":
                        "SGD",
                })

            all_audit_rows.extend(
                audit_rows
            )

            target_directory = (
                args.output_root
                / f"seed_{seed}"
                / (
                    f"PDP"
                    f"{target_pdp_id}"
                )
            )

            target_directory.mkdir(
                parents=True,
                exist_ok=True,
            )

            (
                target_directory
                / (
                    "adaptation_"
                    "history.json"
                )
            ).write_text(
                json.dumps(
                    history,
                    indent=2,
                ),
                encoding="utf-8",
            )

            write_csv(
                target_directory
                / (
                    "parameter_change_"
                    "audit.csv"
                ),
                audit_rows,
            )

            rows = (
                evaluate_snr_sweep(
                    model=model,
                    pdps=pdps,
                    target_pdp_id=(
                        target_pdp_id
                    ),
                    snr_db_values=(
                        config
                        .snr_db_values
                    ),
                    query_blocks=(
                        args.query_blocks
                    ),
                    seed=seed,
                    method=(
                        "algorithm1_"
                        "particular_"
                        "adaptation"
                    ),
                )
            )

            for row in rows:
                row.update({
                    "adaptation_blocks":
                        args
                        .adaptation_blocks,
                    "adaptation_epochs":
                        args.epochs,
                    "learning_rate":
                        args.learning_rate,
                    "adaptation_optimizer":
                        "SGD",
                    "optimizer_momentum":
                        0.0,
                    "particular_initialisation":
                        "historical_mean",
                    "shared_source":
                        (
                            "Algorithm1_iADMM_"
                            "PDP0_to_PDP5"
                        ),
                    "rho":
                        args.expected_rho,
                    "sigma":
                        args.expected_sigma,
                    "iadmm_iterations":
                        args
                        .expected_iterations,
                })

            algorithm_rows.extend(
                rows
            )

            print(
                f"seed={seed} | "
                f"target=PDP"
                f"{target_pdp_id} | "
                f"Algorithm1 rho="
                f"{args.expected_rho:g} "
                f"sigma="
                f"{args.expected_sigma:g} | "
                f"support="
                f"{args.adaptation_blocks} | "
                f"optimizer=SGD | "
                f"support BER="
                f"{history[-1]['ber']:.6f}"
            )

            write_csv(
                args.output_root
                / (
                    "algorithm1_"
                    "particular_snr_"
                    "raw_partial.csv"
                ),
                algorithm_rows,
            )

            write_csv(
                args.output_root
                / (
                    "algorithm1_"
                    "parameter_change_"
                    "audit_partial.csv"
                ),
                all_audit_rows,
            )

    args.output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    algorithm_path = (
        args.output_root
        / (
            "algorithm1_"
            "particular_snr_raw.csv"
        )
    )

    write_csv(
        algorithm_path,
        algorithm_rows,
    )

    audit_path = (
        args.output_root
        / (
            "algorithm1_"
            "parameter_change_audit.csv"
        )
    )

    write_csv(
        audit_path,
        all_audit_rows,
    )

    (
        args.output_root
        / (
            "algorithm1_"
            "run_metadata.json"
        )
    ).write_text(
        json.dumps(
            run_metadata,
            indent=2,
        ),
        encoding="utf-8",
    )

    baseline1_path = (
        args.task7_1_root
        / (
            "joint_no_adaptation_"
            "snr_raw.csv"
        )
    )

    baseline2_path = (
        args.task7_2_root
        / (
            "joint_particular_"
            "snr_raw.csv"
        )
    )

    for path in (
        baseline1_path,
        baseline2_path,
        algorithm_path,
    ):
        if not path.exists():
            raise FileNotFoundError(
                "Required merge input "
                "is missing: "
                f"{path}"
            )

    baseline1 = pd.read_csv(
        baseline1_path
    )

    baseline2 = pd.read_csv(
        baseline2_path
    )

    algorithm = pd.read_csv(
        algorithm_path
    )

    validate_merge_input(
        baseline1,
        "Task 7.1",
        "joint_no_adaptation",
        args.seeds,
        config.unseen_pdps,
        config.snr_db_values,
    )

    validate_merge_input(
        baseline2,
        "Task 7.2",
        "joint_particular_adaptation",
        args.seeds,
        config.unseen_pdps,
        config.snr_db_values,
    )

    validate_merge_input(
        algorithm,
        "Task 7.3",
        "algorithm1_particular_adaptation",
        args.seeds,
        config.unseen_pdps,
        config.snr_db_values,
    )

    validate_baseline_settings(
        baseline1=baseline1,
        baseline2=baseline2,
        adaptation_blocks=(
            args.adaptation_blocks
        ),
        adaptation_epochs=(
            args.epochs
        ),
        adaptation_learning_rate=(
            args.learning_rate
        ),
    )

    combined = pd.concat(
        [
            baseline1,
            baseline2,
            algorithm,
        ],
        ignore_index=True,
        sort=False,
    )

    combined_path = (
        args.output_root
        / (
            "task7_snr_"
            "comparison_raw.csv"
        )
    )

    combined.to_csv(
        combined_path,
        index=False,
    )

    summary = (
        combined
        .groupby(
            [
                "target_pdp",
                "snr_db",
                "method",
            ],
            as_index=False,
        )
        .agg(
            seed_count=(
                "seed",
                "nunique",
            ),
            mean_ber=(
                "ber",
                "mean",
            ),
            std_ber=(
                "ber",
                population_std,
            ),
            min_ber=(
                "ber",
                "min",
            ),
            max_ber=(
                "ber",
                "max",
            ),
        )
        .sort_values(
            [
                "target_pdp",
                "method",
                "snr_db",
            ]
        )
    )

    summary_path = (
        args.output_root
        / (
            "task7_snr_"
            "comparison_summary.csv"
        )
    )

    summary.to_csv(
        summary_path,
        index=False,
    )

    save_figures(
        summary,
        args.output_root,
    )

    print(
        "\nTask 7.3 and merge "
        "completed."
    )
    print(
        f"Algorithm raw: "
        f"{algorithm_path}"
    )
    print(
        f"Algorithm audit: "
        f"{audit_path}"
    )
    print(
        f"Combined raw: "
        f"{combined_path}"
    )
    print(
        f"Summary: "
        f"{summary_path}"
    )
    print(
        "Plots: "
        f"{args.output_root / 'plots'}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )