from __future__ import annotations

import argparse
import json
from pathlib import Path

from src.base_functions import (
    end_to_end,
)
from src.pdp_profiles import (
    get_known_pdps,
)
from src.task6.iadmm_state import (
    load_snapshot_npz,
    restore_named_layers,
)
from src.task6.task6_parameter_groups import (
    validate_partition,
)
from src.task7.task7_common import (
    adapt_particular,
    audit_parameter_changes,
    build_dataset,
    clean_model,
    evaluate_snr_sweep,
    set_deterministic,
    snapshot_layer_arrays,
    verify_particular_only_audit,
    write_csv,
)
from src.task7.task7_config import (
    Task7Config,
)


def parse_arguments():
    config = Task7Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 7.2 baseline 2: start from the ordinary "
            "PDP0-PDP5 joint model learned in Task 7.1, "
            "freeze the shared subset, use PDP6/PDP7 few-shot "
            "samples to fine-tune ONLY the particular subset "
            "with plain SGD, then evaluate BER versus SNR."
        )
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(
            config.seeds
        ),
    )
    parser.add_argument(
        "--adaptation-blocks",
        type=int,
        default=(
            config.adaptation_blocks
        ),
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=(
            config.adaptation_epochs
        ),
    )
    parser.add_argument(
        "--learning-rate",
        type=float,
        default=(
            config
            .adaptation_learning_rate
        ),
    )
    parser.add_argument(
        "--query-blocks",
        type=int,
        default=(
            config
            .query_blocks_per_snr
        ),
    )
    parser.add_argument(
        "--joint-root",
        type=Path,
        default=(
            config.output_root
            / "01_joint_training"
        ),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / (
                "02_joint_"
                "particular_adaptation"
            )
        ),
    )

    return parser.parse_args()


def validate_arguments(
    args,
) -> None:
    if not args.seeds:
        raise ValueError(
            "At least one seed is required."
        )
    if args.adaptation_blocks <= 0:
        raise ValueError(
            "--adaptation-blocks must "
            "be positive."
        )
    if args.epochs <= 0:
        raise ValueError(
            "--epochs must be positive."
        )
    if args.learning_rate <= 0:
        raise ValueError(
            "--learning-rate must "
            "be positive."
        )
    if args.query_blocks <= 0:
        raise ValueError(
            "--query-blocks must "
            "be positive."
        )


def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task7Config()
    pdps = get_known_pdps()

    all_snr_rows: list[
        dict
    ] = []
    all_audit_rows: list[
        dict
    ] = []

    for seed in args.seeds:
        joint_snapshot_path = (
            args.joint_root
            / f"seed_{seed}"
            / "joint_model.npz"
        )

        if not (
            joint_snapshot_path.exists()
        ):
            raise FileNotFoundError(
                "Missing Task 7.1 joint "
                "checkpoint: "
                f"{joint_snapshot_path}"
            )

        # Load the joint model produced by Baseline 1.
        joint_snapshot = (
            load_snapshot_npz(
                joint_snapshot_path
            )
        )

        for target_pdp_id in (
            config.unseen_pdps
        ):
            clean_model()
            set_deterministic(
                seed
            )

            model = end_to_end()
            validate_partition(
                model
            )

            # Initialize Baseline 2 from Baseline 1.
            restore_named_layers(
                model,
                joint_snapshot,
            )

            # PDP6/PDP7 support samples are used for fine-tuning.
            support_seed = (
                seed
                + 100000
                + target_pdp_id
                * 1000
            )

            support_dataset = (
                build_dataset(
                    pdp=pdps[
                        target_pdp_id
                    ],
                    pdp_id=(
                        target_pdp_id
                    ),
                    num_blocks=(
                        args
                        .adaptation_blocks
                    ),
                    ebno_linear=(
                        config
                        .training_ebno_linear
                    ),
                    seed=(
                        support_seed
                    ),
                )
            )

            before = (
                snapshot_layer_arrays(
                    model
                )
            )

            # adapt_particular freezes shared layers and updates only particular layers with SGD.
            history = adapt_particular(
                model=model,
                dataset=(
                    support_dataset
                ),
                epochs=args.epochs,
                learning_rate=(
                    args.learning_rate
                ),
                seed=(
                    support_seed
                ),
            )

            audit_rows = (
                audit_parameter_changes(
                    model,
                    before,
                )
            )

            # Verify that shared layers remain unchanged and particular layers are updated.
            verify_particular_only_audit(
                audit_rows
            )

            for row in audit_rows:
                row.update({
                    "seed":
                        seed,
                    "target_pdp":
                        target_pdp_id,
                    "adaptation_blocks":
                        args
                        .adaptation_blocks,
                    "method":
                        (
                            "joint_"
                            "particular_"
                            "adaptation"
                        ),
                    "optimizer":
                        "SGD",
                    "learning_rate":
                        args.learning_rate,
                })

            all_audit_rows.extend(
                audit_rows
            )

            target_directory = (
                args.output_root
                / f"seed_{seed}"
                / (
                    f"PDP"
                    f"{target_pdp_id}"
                )
            )

            target_directory.mkdir(
                parents=True,
                exist_ok=True,
            )

            (
                target_directory
                / (
                    "adaptation_"
                    "history.json"
                )
            ).write_text(
                json.dumps(
                    history,
                    indent=2,
                ),
                encoding="utf-8",
            )

            write_csv(
                target_directory
                / (
                    "parameter_change_"
                    "audit.csv"
                ),
                audit_rows,
            )

            # Evaluate on an independent fixed query set.
            snr_rows = (
                evaluate_snr_sweep(
                    model=model,
                    pdps=pdps,
                    target_pdp_id=(
                        target_pdp_id
                    ),
                    snr_db_values=(
                        config
                        .snr_db_values
                    ),
                    query_blocks=(
                        args
                        .query_blocks
                    ),
                    seed=seed,
                    method=(
                        "joint_"
                        "particular_"
                        "adaptation"
                    ),
                )
            )

            for row in snr_rows:
                row.update({
                    "adaptation_blocks":
                        args
                        .adaptation_blocks,
                    "adaptation_epochs":
                        args.epochs,
                    "learning_rate":
                        args.learning_rate,
                    "adaptation_optimizer":
                        "SGD",
                    "optimizer_momentum":
                        0.0,
                    "shared_source":
                        (
                            "ordinary_joint_"
                            "training_PDP0_"
                            "to_PDP5"
                        ),
                })

            all_snr_rows.extend(
                snr_rows
            )

            write_csv(
                args.output_root
                / (
                    "joint_particular_"
                    "snr_raw_partial.csv"
                ),
                all_snr_rows,
            )

            write_csv(
                args.output_root
                / (
                    "parameter_change_"
                    "audit_partial.csv"
                ),
                all_audit_rows,
            )

            print(
                f"seed={seed} | "
                f"target=PDP"
                f"{target_pdp_id} | "
                f"support="
                f"{args.adaptation_blocks} | "
                f"optimizer=SGD | "
                f"support BER="
                f"{history[-1]['ber']:.6f}"
            )

    final_path = (
        args.output_root
        / "joint_particular_snr_raw.csv"
    )

    write_csv(
        final_path,
        all_snr_rows,
    )

    write_csv(
        args.output_root
        / "parameter_change_audit.csv",
        all_audit_rows,
    )

    print(
        "\nTask 7.2 completed."
    )
    print(
        f"Merge input: {final_path}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )
