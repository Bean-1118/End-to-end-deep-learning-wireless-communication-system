from __future__ import annotations

import csv
import gc
from pathlib import Path
from typing import Iterable, Mapping

import numpy as np
import tensorflow as tf

from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
)
from src.task6.iadmm_state import (
    LayerSnapshot,
    snapshot_named_layers,
)
from src.task6.task6_parameter_groups import (
    PARTICULAR_LAYER_NAMES,
    validate_partition,
)


def write_csv(
    path: Path,
    rows: list[dict],
) -> None:
    if not rows:
        return

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def snr_db_to_linear(
    snr_db: float,
) -> float:
    return float(
        10.0 ** (snr_db / 10.0)
    )


def set_deterministic(
    seed: int,
) -> None:
    set_all_seeds(seed)

    try:
        tf.config.experimental.enable_op_determinism()
    except Exception:
        pass


def clean_model() -> None:
    tf.keras.backend.clear_session()
    gc.collect()


def build_dataset(
    *,
    pdp,
    pdp_id: int,
    num_blocks: int,
    ebno_linear: float,
    seed: int,
):
    return make_fixed_adaptation_dataset(
        pdp_target=pdp,
        pdp_id=pdp_id,
        num_blocks=num_blocks,
        ebno_linear=ebno_linear,
        seed=seed,
    )


def evaluate_ber(
    model: tf.keras.Model,
    dataset,
) -> float:
    total_errors = 0
    total_bits = 0

    for bits, channels, noise_std in iter_fixed_batches(
        dataset=dataset,
        epoch=0,
        shuffle_seed=0,
    ):
        labels = tf.cast(
            bits,
            tf.float32,
        )

        _, probabilities = model(
            [
                bits,
                channels,
                noise_std,
            ],
            training=False,
        )

        predictions = tf.cast(
            probabilities >= 0.5,
            tf.float32,
        )

        total_errors += int(
            tf.reduce_sum(
                tf.cast(
                    predictions != labels,
                    tf.int64,
                )
            ).numpy()
        )
        total_bits += int(
            tf.size(labels).numpy()
        )

    if total_bits <= 0:
        raise ValueError(
            "Evaluation dataset is empty."
        )

    return total_errors / total_bits


def evaluate_historical_mean_ber(
    model: tf.keras.Model,
    datasets_by_pdp: Mapping[int, object],
) -> tuple[
    float,
    float,
    dict[int, float],
]:
    by_pdp = {
        pdp_id: evaluate_ber(
            model,
            dataset,
        )
        for pdp_id, dataset
        in sorted(
            datasets_by_pdp.items()
        )
    }

    values = list(
        by_pdp.values()
    )

    return (
        float(np.mean(values)),
        float(np.max(values)),
        by_pdp,
    )


def set_all_trainable(
    model: tf.keras.Model,
) -> None:
    for layer in model.layers:
        layer.trainable = True


def set_particular_only_trainable(
    model: tf.keras.Model,
) -> None:
    particular = set(
        PARTICULAR_LAYER_NAMES
    )

    for layer in model.layers:
        layer.trainable = (
            layer.name in particular
        )

    actual = {
        layer.name
        for layer in model.layers
        if (
            layer.trainable
            and layer.trainable_weights
        )
    }

    if actual != particular:
        raise RuntimeError(
            "Incorrect particular trainable mask. "
            f"Expected={sorted(particular)}, "
            f"actual={sorted(actual)}"
        )


def make_sgd_optimizer(
    learning_rate: float,
) -> tf.keras.optimizers.Optimizer:
    """
    Create the plain SGD optimizer used by the Task-7 baselines.

    Momentum and Nesterov acceleration are disabled.
    """
    if learning_rate <= 0:
        raise ValueError(
            "learning_rate must be positive."
        )

    return tf.keras.optimizers.SGD(
        learning_rate=learning_rate,
        momentum=0.0,
        nesterov=False,
    )


def _checked_gradient_pairs(
    *,
    loss: tf.Tensor,
    tape: tf.GradientTape,
    variables: list[tf.Variable],
) -> list[
    tuple[tf.Tensor, tf.Variable]
]:
    gradients = tape.gradient(
        loss,
        variables,
    )

    pairs = []

    for gradient, variable in zip(
        gradients,
        variables,
    ):
        if gradient is None:
            raise RuntimeError(
                "Missing gradient for "
                f"{variable.name}"
            )

        if not bool(
            tf.reduce_all(
                tf.math.is_finite(
                    gradient
                )
            ).numpy()
        ):
            raise FloatingPointError(
                "Non-finite gradient for "
                f"{variable.name}"
            )

        pairs.append(
            (gradient, variable)
        )

    if not pairs:
        raise RuntimeError(
            "No gradients produced."
        )

    return pairs


def train_one_epoch(
    *,
    model: tf.keras.Model,
    datasets_by_pdp: Mapping[
        int,
        object,
    ],
    optimizer: tf.keras.optimizers.Optimizer,
    epoch: int,
    seed: int,
) -> dict:
    """
    Run one joint-training epoch on PDP0-PDP5.

    All model parameters are trainable, and PDP batches are interleaved across environments.
    """
    iterators = {
        pdp_id: iter(
            iter_fixed_batches(
                dataset=dataset,
                epoch=epoch,
                shuffle_seed=(
                    seed
                    + pdp_id * 1000
                ),
            )
        )
        for pdp_id, dataset
        in datasets_by_pdp.items()
    }

    active = set(iterators)
    losses: list[float] = []
    bers: list[float] = []
    update_count = 0

    while active:
        for pdp_id in sorted(
            list(active)
        ):
            try:
                (
                    bits,
                    channels,
                    noise_std,
                ) = next(
                    iterators[pdp_id]
                )
            except StopIteration:
                active.remove(
                    pdp_id
                )
                continue

            labels = tf.cast(
                bits,
                tf.float32,
            )

            with tf.GradientTape() as tape:
                (
                    logits,
                    probabilities,
                ) = model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        labels=labels,
                        logits=logits,
                    )
                )

            variables = list(
                model.trainable_variables
            )

            pairs = _checked_gradient_pairs(
                loss=loss,
                tape=tape,
                variables=variables,
            )

            optimizer.apply_gradients(
                pairs
            )
            update_count += 1

            predictions = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predictions != labels,
                    tf.float32,
                )
            )

            losses.append(
                float(loss.numpy())
            )
            bers.append(
                float(ber.numpy())
            )

    if not losses:
        raise RuntimeError(
            "No joint-training batches were generated."
        )

    return {
        "loss": float(
            np.mean(losses)
        ),
        "ber": float(
            np.mean(bers)
        ),
        "gradient_updates":
            update_count,
    }


def adapt_particular(
    *,
    model: tf.keras.Model,
    dataset,
    epochs: int,
    learning_rate: float,
    seed: int,
) -> list[dict]:
    """
    Adapt the predefined particular layers for a new environment.

    Shared layers are frozen and the particular layers are updated with plain SGD.
    """
    set_deterministic(seed)
    set_particular_only_trainable(
        model
    )

    optimizer = make_sgd_optimizer(
        learning_rate=learning_rate
    )

    history: list[dict] = []

    for epoch in range(epochs):
        losses: list[float] = []
        bers: list[float] = []

        for (
            bits,
            channels,
            noise_std,
        ) in iter_fixed_batches(
            dataset=dataset,
            epoch=epoch,
            shuffle_seed=(
                seed + 1000
            ),
        ):
            labels = tf.cast(
                bits,
                tf.float32,
            )

            with tf.GradientTape() as tape:
                (
                    logits,
                    probabilities,
                ) = model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        labels=labels,
                        logits=logits,
                    )
                )

            variables = list(
                model.trainable_variables
            )

            pairs = _checked_gradient_pairs(
                loss=loss,
                tape=tape,
                variables=variables,
            )

            optimizer.apply_gradients(
                pairs
            )

            predictions = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predictions != labels,
                    tf.float32,
                )
            )

            losses.append(
                float(loss.numpy())
            )
            bers.append(
                float(ber.numpy())
            )

        if not losses:
            raise RuntimeError(
                "No adaptation batches were generated."
            )

        history.append({
            "epoch": epoch + 1,
            "loss": float(
                np.mean(losses)
            ),
            "ber": float(
                np.mean(bers)
            ),
            "optimizer": "SGD",
            "learning_rate":
                learning_rate,
        })

    return history


def evaluate_snr_sweep(
    *,
    model: tf.keras.Model,
    pdps,
    target_pdp_id: int,
    snr_db_values: Iterable[
        float
    ],
    query_blocks: int,
    seed: int,
    method: str,
) -> list[dict]:
    rows: list[dict] = []

    for snr_db in snr_db_values:
        dataset = build_dataset(
            pdp=pdps[
                target_pdp_id
            ],
            pdp_id=target_pdp_id,
            num_blocks=query_blocks,
            ebno_linear=(
                snr_db_to_linear(
                    snr_db
                )
            ),
            seed=(
                seed
                + 500000
                + target_pdp_id
                * 10000
                + int(
                    round(
                        snr_db * 100
                    )
                )
            ),
        )

        rows.append({
            "seed": seed,
            "target_pdp":
                target_pdp_id,
            "snr_db": snr_db,
            "method": method,
            "ber": evaluate_ber(
                model,
                dataset,
            ),
        })

    return rows


def snapshot_joint_model(
    model: tf.keras.Model,
) -> LayerSnapshot:
    validate_partition(model)

    layer_names = [
        layer.name
        for layer in model.layers
        if layer.trainable_weights
    ]

    return snapshot_named_layers(
        model,
        layer_names,
    )


def snapshot_layer_arrays(
    model: tf.keras.Model,
) -> dict[
    str,
    list[np.ndarray],
]:
    """
    Snapshot layer.weights so frozen shared layers remain included in the audit.
    """
    return {
        layer.name: [
            np.asarray(
                variable.numpy()
            ).copy()
            for variable
            in layer.weights
        ]
        for layer in model.layers
        if layer.weights
    }


def audit_parameter_changes(
    model: tf.keras.Model,
    before: Mapping[
        str,
        list[np.ndarray],
    ],
) -> list[dict]:
    particular = set(
        PARTICULAR_LAYER_NAMES
    )
    rows: list[dict] = []

    for layer in model.layers:
        if layer.name not in before:
            continue

        after = [
            np.asarray(
                variable.numpy()
            ).copy()
            for variable
            in layer.weights
        ]
        old = before[
            layer.name
        ]

        if len(old) != len(after):
            raise ValueError(
                f"Weight count mismatch "
                f"for {layer.name}: "
                f"before={len(old)}, "
                f"after={len(after)}"
            )

        if not old:
            continue

        before_flat = np.concatenate([
            value.reshape(-1)
            for value in old
        ])

        delta_flat = np.concatenate([
            (
                new_value
                - old_value
            ).reshape(-1)
            for (
                old_value,
                new_value,
            ) in zip(
                old,
                after,
            )
        ])

        delta_l2 = float(
            np.linalg.norm(
                delta_flat
            )
        )
        before_l2 = float(
            np.linalg.norm(
                before_flat
            )
        )

        rows.append({
            "layer_name":
                layer.name,
            "parameter_group":
                (
                    "particular"
                    if layer.name
                    in particular
                    else "shared"
                ),
            "parameter_count":
                int(
                    delta_flat.size
                ),
            "delta_l2":
                delta_l2,
            "relative_delta_l2":
                (
                    delta_l2
                    / (
                        before_l2
                        + 1e-12
                    )
                ),
            "maximum_absolute_delta":
                float(
                    np.max(
                        np.abs(
                            delta_flat
                        )
                    )
                ),
        })

    if not rows:
        raise RuntimeError(
            "No parameter changes were audited."
        )

    return rows


def verify_particular_only_audit(
    audit_rows: list[dict],
    shared_tolerance: float = 1e-12,
    particular_tolerance: float = 1e-12,
) -> None:
    shared_max = max(
        (
            row[
                "maximum_absolute_delta"
            ]
            for row in audit_rows
            if row[
                "parameter_group"
            ] == "shared"
        ),
        default=0.0,
    )

    particular_max = max(
        (
            row[
                "maximum_absolute_delta"
            ]
            for row in audit_rows
            if row[
                "parameter_group"
            ] == "particular"
        ),
        default=0.0,
    )

    if shared_max > shared_tolerance:
        raise RuntimeError(
            "Shared parameters changed "
            "during particular-only adaptation: "
            f"max={shared_max:.6e}"
        )

    if (
        particular_max
        <= particular_tolerance
    ):
        raise RuntimeError(
            "Particular parameters "
            "did not change."
        )
