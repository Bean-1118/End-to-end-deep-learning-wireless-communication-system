from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


METHOD_ORDER = [
    "joint_no_adaptation",
    "joint_particular_adaptation",
    "ea_particular_adaptation",
]

METHOD_LABELS = {
    "joint_no_adaptation":
        "Joint training, no adaptation",

    "joint_particular_adaptation":
        "Joint training + particular adaptation",

    "ea_particular_adaptation":
        "Algorithm 1 shared + particular adaptation",
}


def population_std(series: pd.Series) -> float:
    values = pd.to_numeric(
        series,
        errors="coerce",
    ).dropna()

    if values.empty:
        return float("nan")

    return float(values.std(ddof=0))


def ensure_directory(path: Path) -> Path:
    path.mkdir(
        parents=True,
        exist_ok=True,
    )
    return path


def save_figure(
    figure: plt.Figure,
    path: Path,
) -> None:
    ensure_directory(path.parent)

    figure.tight_layout()

    figure.savefig(
        path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close(figure)


def load_results(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)

    dataframe = pd.read_csv(path)

    required = {
        "seed",
        "target_pdp",
        "snr_db",
        "method",
        "ber",
    }

    missing = required.difference(
        dataframe.columns
    )

    if missing:
        raise ValueError(
            "Task 7 raw result is missing columns: "
            f"{sorted(missing)}"
        )

    dataframe = dataframe.copy()

    dataframe["seed"] = pd.to_numeric(
        dataframe["seed"],
        errors="raise",
    ).astype(int)

    dataframe["target_pdp"] = pd.to_numeric(
        dataframe["target_pdp"],
        errors="raise",
    ).astype(int)

    dataframe["snr_db"] = pd.to_numeric(
        dataframe["snr_db"],
        errors="raise",
    )

    dataframe["ber"] = pd.to_numeric(
        dataframe["ber"],
        errors="raise",
    )

    return dataframe


def validate_experiment(
    dataframe: pd.DataFrame,
) -> list[str]:
    messages: list[str] = []

    duplicate_columns = [
        "seed",
        "target_pdp",
        "snr_db",
        "method",
    ]

    duplicate_count = int(
        dataframe.duplicated(
            subset=duplicate_columns,
            keep=False,
        ).sum()
    )

    if duplicate_count:
        raise ValueError(
            "Duplicate experiment rows detected: "
            f"{duplicate_count}"
        )

    methods = sorted(
        dataframe["method"].unique()
    )

    missing_methods = [
        method
        for method in METHOD_ORDER
        if method not in methods
    ]

    if missing_methods:
        raise ValueError(
            "Missing required methods: "
            f"{missing_methods}"
        )

    expected_grid = None

    for (
        method,
        target_pdp,
        seed,
    ), group in dataframe.groupby(
        [
            "method",
            "target_pdp",
            "seed",
        ]
    ):
        grid = tuple(
            sorted(
                group["snr_db"].unique()
            )
        )

        if expected_grid is None:
            expected_grid = grid

        elif grid != expected_grid:
            raise ValueError(
                "Inconsistent SNR grid for "
                f"{method}, PDP{target_pdp}, "
                f"seed={seed}."
            )

        ordered = group.sort_values(
            "snr_db"
        )

        differences = np.diff(
            ordered["ber"].to_numpy()
        )

        if np.any(differences > 1e-12):
            messages.append(
                "WARNING: BER is not monotonically "
                "non-increasing for "
                f"{method}, PDP{target_pdp}, "
                f"seed={seed}."
            )

    seed_counts = (
        dataframe
        .groupby(
            [
                "method",
                "target_pdp",
            ]
        )["seed"]
        .nunique()
    )

    if seed_counts.nunique() != 1:
        messages.append(
            "WARNING: methods do not use the same "
            "number of seeds."
        )

    messages.append(
        "Methods: "
        + ", ".join(methods)
    )

    messages.append(
        "Targets: "
        + ", ".join(
            f"PDP{value}"
            for value in sorted(
                dataframe[
                    "target_pdp"
                ].unique()
            )
        )
    )

    messages.append(
        "Seeds: "
        + ", ".join(
            str(value)
            for value in sorted(
                dataframe["seed"].unique()
            )
        )
    )

    messages.append(
        "SNR grid: "
        + ", ".join(
            f"{value:g}"
            for value in expected_grid
        )
        + " dB"
    )

    return messages


def build_summary(
    dataframe: pd.DataFrame,
) -> pd.DataFrame:
    summary = (
        dataframe
        .groupby(
            [
                "target_pdp",
                "snr_db",
                "method",
            ],
            as_index=False,
        )
        .agg(
            seed_count=(
                "seed",
                "nunique",
            ),

            mean_ber=(
                "ber",
                "mean",
            ),

            std_ber=(
                "ber",
                population_std,
            ),

            min_ber=(
                "ber",
                "min",
            ),

            max_ber=(
                "ber",
                "max",
            ),
        )
    )

    return summary.sort_values(
        [
            "target_pdp",
            "method",
            "snr_db",
        ]
    )


def build_pairwise_comparison(
    summary: pd.DataFrame,
) -> pd.DataFrame:
    pivot = summary.pivot_table(
        index=[
            "target_pdp",
            "snr_db",
        ],
        columns="method",
        values="mean_ber",
    ).reset_index()

    required = set(METHOD_ORDER)

    missing = required.difference(
        pivot.columns
    )

    if missing:
        raise ValueError(
            "Cannot build pairwise comparison; "
            f"missing methods: {sorted(missing)}"
        )

    pivot[
        "joint_adaptation_absolute_gain"
    ] = (
        pivot[
            "joint_no_adaptation"
        ]
        - pivot[
            "joint_particular_adaptation"
        ]
    )

    pivot[
        "joint_adaptation_relative_gain"
    ] = (
        pivot[
            "joint_adaptation_absolute_gain"
        ]
        / pivot[
            "joint_no_adaptation"
        ]
    )

    pivot[
        "ea_vs_joint_adapt_absolute_gain"
    ] = (
        pivot[
            "joint_particular_adaptation"
        ]
        - pivot[
            "ea_particular_adaptation"
        ]
    )

    pivot[
        "ea_vs_joint_adapt_relative_gain"
    ] = (
        pivot[
            "ea_vs_joint_adapt_absolute_gain"
        ]
        / pivot[
            "joint_particular_adaptation"
        ]
    )

    pivot[
        "ea_vs_joint_no_adapt_absolute_gain"
    ] = (
        pivot[
            "joint_no_adaptation"
        ]
        - pivot[
            "ea_particular_adaptation"
        ]
    )

    pivot[
        "ea_vs_joint_no_adapt_relative_gain"
    ] = (
        pivot[
            "ea_vs_joint_no_adapt_absolute_gain"
        ]
        / pivot[
            "joint_no_adaptation"
        ]
    )

    pivot[
        "best_method"
    ] = pivot[
        METHOD_ORDER
    ].idxmin(
        axis=1
    )

    return pivot


def build_auc_summary(
    summary: pd.DataFrame,
) -> pd.DataFrame:
    rows: list[dict] = []

    for (
        target_pdp,
        method,
    ), group in summary.groupby(
        [
            "target_pdp",
            "method",
        ]
    ):
        ordered = group.sort_values(
            "snr_db"
        )

        snr = ordered[
            "snr_db"
        ].to_numpy(
            dtype=np.float64
        )

        ber = ordered[
            "mean_ber"
        ].to_numpy(
            dtype=np.float64
        )

        linear_auc = float(
            np.trapz(
                ber,
                snr,
            )
        )

        log_auc = float(
            np.trapz(
                np.log10(
                    np.maximum(
                        ber,
                        1e-12,
                    )
                ),
                snr,
            )
        )

        rows.append({
            "target_pdp":
                target_pdp,

            "method":
                method,

            "ber_snr_auc":
                linear_auc,

            "log10_ber_snr_auc":
                log_auc,

            "mean_ber_across_snr":
                float(
                    np.mean(ber)
                ),

            "ber_at_min_snr":
                float(ber[0]),

            "ber_at_max_snr":
                float(ber[-1]),
        })

    return pd.DataFrame(
        rows
    ).sort_values(
        [
            "target_pdp",
            "ber_snr_auc",
        ]
    )


def plot_ber_vs_snr(
    summary: pd.DataFrame,
    plots_root: Path,
) -> None:
    for target_pdp in sorted(
        summary["target_pdp"].unique()
    ):
        subset = summary[
            summary["target_pdp"]
            == target_pdp
        ]

        figure, axis = plt.subplots(
            figsize=(9, 6)
        )

        for method in METHOD_ORDER:
            method_rows = (
                subset[
                    subset["method"]
                    == method
                ]
                .sort_values(
                    "snr_db"
                )
            )

            if method_rows.empty:
                continue

            axis.errorbar(
                method_rows["snr_db"],
                method_rows["mean_ber"],
                yerr=method_rows["std_ber"],
                marker="o",
                capsize=3,
                label=METHOD_LABELS[
                    method
                ],
            )

        axis.set_yscale("log")

        axis.set_xlabel(
            "SNR / Eb/N0 (dB)"
        )

        axis.set_ylabel(
            "Bit error rate"
        )

        axis.set_title(
            f"PDP{target_pdp}: BER versus SNR"
        )

        axis.grid(
            True,
            which="both",
            alpha=0.3,
        )

        axis.legend()

        save_figure(
            figure,
            plots_root
            / f"PDP{target_pdp}_ber_vs_snr.png",
        )


def plot_relative_gains(
    comparison: pd.DataFrame,
    plots_root: Path,
) -> None:
    for target_pdp in sorted(
        comparison[
            "target_pdp"
        ].unique()
    ):
        subset = (
            comparison[
                comparison[
                    "target_pdp"
                ]
                == target_pdp
            ]
            .sort_values(
                "snr_db"
            )
        )

        figure, axis = plt.subplots(
            figsize=(9, 6)
        )

        axis.plot(
            subset["snr_db"],
            100.0
            * subset[
                "joint_adaptation_relative_gain"
            ],
            marker="o",
            label=(
                "Joint + particular vs "
                "joint no-adaptation"
            ),
        )

        axis.plot(
            subset["snr_db"],
            100.0
            * subset[
                "ea_vs_joint_adapt_relative_gain"
            ],
            marker="o",
            label=(
                "Algorithm 1 shared vs "
                "joint shared"
            ),
        )

        axis.axhline(
            0.0,
            linewidth=1.0,
        )

        axis.set_xlabel(
            "SNR / Eb/N0 (dB)"
        )

        axis.set_ylabel(
            "Relative BER reduction (%)"
        )

        axis.set_title(
            f"PDP{target_pdp}: baseline-relative gains"
        )

        axis.grid(
            True,
            alpha=0.3,
        )

        axis.legend()

        save_figure(
            figure,
            plots_root
            / f"PDP{target_pdp}_relative_gains.png",
        )


def plot_auc(
    auc_summary: pd.DataFrame,
    plots_root: Path,
) -> None:
    for target_pdp in sorted(
        auc_summary[
            "target_pdp"
        ].unique()
    ):
        subset = (
            auc_summary[
                auc_summary[
                    "target_pdp"
                ]
                == target_pdp
            ]
            .copy()
        )

        subset["label"] = subset[
            "method"
        ].map(
            METHOD_LABELS
        )

        figure, axis = plt.subplots(
            figsize=(9, 5.5)
        )

        axis.bar(
            subset["label"],
            subset[
                "ber_snr_auc"
            ],
        )

        axis.set_xlabel(
            "Method"
        )

        axis.set_ylabel(
            "Area under BER-SNR curve"
        )

        axis.set_title(
            f"PDP{target_pdp}: aggregate BER across SNR"
        )

        axis.tick_params(
            axis="x",
            rotation=20,
        )

        axis.grid(
            True,
            axis="y",
            alpha=0.3,
        )

        save_figure(
            figure,
            plots_root
            / f"PDP{target_pdp}_ber_snr_auc.png",
        )


def build_report(
    *,
    dataframe: pd.DataFrame,
    summary: pd.DataFrame,
    comparison: pd.DataFrame,
    auc_summary: pd.DataFrame,
    validation_messages: list[str],
    output_path: Path,
) -> None:
    lines = [
        "Task 7 Baseline Analysis",
        "=" * 80,
        "",
        "Experiment validation",
        "-" * 80,
    ]

    lines.extend(
        validation_messages
    )

    lines.extend([
        "",
        "Main findings",
        "-" * 80,
    ])

    for target_pdp in sorted(
        comparison[
            "target_pdp"
        ].unique()
    ):
        subset = comparison[
            comparison[
                "target_pdp"
            ]
            == target_pdp
        ].sort_values(
            "snr_db"
        )

        lines.append(
            f"PDP{target_pdp}:"
        )

        winner_counts = (
            subset[
                "best_method"
            ]
            .value_counts()
        )

        for method in METHOD_ORDER:
            count = int(
                winner_counts.get(
                    method,
                    0,
                )
            )

            lines.append(
                f"  {METHOD_LABELS[method]} "
                f"was best at {count}/"
                f"{len(subset)} SNR points."
            )

        mean_joint_gain = float(
            subset[
                "joint_adaptation_relative_gain"
            ].mean()
        )

        mean_ea_gain = float(
            subset[
                "ea_vs_joint_adapt_relative_gain"
            ].mean()
        )

        lines.append(
            "  Joint particular adaptation versus "
            "joint no-adaptation: mean relative BER "
            f"change = {100.0 * mean_joint_gain:.2f}%."
        )

        lines.append(
            "  Algorithm-1 shared versus ordinary joint "
            "shared after the same particular adaptation: "
            f"mean relative BER change = "
            f"{100.0 * mean_ea_gain:.2f}%."
        )

        high_snr_row = subset.iloc[-1]

        lines.append(
            f"  At {high_snr_row['snr_db']:.1f} dB: "
            f"joint no-adaptation="
            f"{high_snr_row['joint_no_adaptation']:.6f}, "
            f"joint + particular="
            f"{high_snr_row['joint_particular_adaptation']:.6f}, "
            f"Algorithm-1 + particular="
            f"{high_snr_row['ea_particular_adaptation']:.6f}."
        )

    lines.extend([
        "",
        "Interpretation rule",
        "-" * 80,
        (
            "Positive joint_adaptation gain means that "
            "particular adaptation improved the ordinary "
            "joint model."
        ),
        (
            "Positive ea_vs_joint_adapt gain means that "
            "the Algorithm-1 shared parameters outperformed "
            "the ordinary jointly trained shared parameters "
            "under matched particular adaptation."
        ),
        (
            "A negative EA gain means that the current "
            "Algorithm-1 implementation did not outperform "
            "the joint-training baseline under the tested "
            "conditions. This result must be reported rather "
            "than re-labelled as an improvement."
        ),
        "",
        "AUC ranking",
        "-" * 80,
    ])

    for target_pdp in sorted(
        auc_summary[
            "target_pdp"
        ].unique()
    ):
        subset = (
            auc_summary[
                auc_summary[
                    "target_pdp"
                ]
                == target_pdp
            ]
            .sort_values(
                "ber_snr_auc"
            )
        )

        lines.append(
            f"PDP{target_pdp}:"
        )

        for rank, (_, row) in enumerate(
            subset.iterrows(),
            start=1,
        ):
            lines.append(
                f"  {rank}. "
                f"{METHOD_LABELS[row['method']]}: "
                f"AUC={row['ber_snr_auc']:.6f}"
            )

    ensure_directory(
        output_path.parent
    )

    output_path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def parse_arguments() -> argparse.Namespace:
    project_root = (
        Path(__file__).resolve().parents[2]
    )

    parser = argparse.ArgumentParser(
        description=(
            "Analyse Task 7 BER-versus-SNR baseline "
            "experiments."
        )
    )

    parser.add_argument(
        "--input",
        type=Path,
        default=(
            project_root
            / "outputs"
            / "task7"
            / "03_ea_baseline_comparison"
            / "task7_snr_comparison_raw.csv"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            project_root
            / "outputs"
            / "task7"
            / "final_summary"
        ),
    )

    return parser.parse_args()


def main() -> int:
    args = parse_arguments()

    tables_root = ensure_directory(
        args.output_root
        / "tables"
    )

    plots_root = ensure_directory(
        args.output_root
        / "plots"
    )

    reports_root = ensure_directory(
        args.output_root
        / "reports"
    )

    dataframe = load_results(
        args.input
    )

    validation_messages = (
        validate_experiment(
            dataframe
        )
    )

    summary = build_summary(
        dataframe
    )

    comparison = (
        build_pairwise_comparison(
            summary
        )
    )

    auc_summary = build_auc_summary(
        summary
    )

    summary.to_csv(
        tables_root
        / "task7_snr_summary.csv",
        index=False,
    )

    comparison.to_csv(
        tables_root
        / "task7_pairwise_comparison.csv",
        index=False,
    )

    auc_summary.to_csv(
        tables_root
        / "task7_auc_summary.csv",
        index=False,
    )

    plot_ber_vs_snr(
        summary=summary,
        plots_root=plots_root,
    )

    plot_relative_gains(
        comparison=comparison,
        plots_root=plots_root,
    )

    plot_auc(
        auc_summary=auc_summary,
        plots_root=plots_root,
    )

    build_report(
        dataframe=dataframe,
        summary=summary,
        comparison=comparison,
        auc_summary=auc_summary,
        validation_messages=(
            validation_messages
        ),
        output_path=(
            reports_root
            / "task7_analysis_report.txt"
        ),
    )

    print("=" * 80)
    print("Task 7 analysis completed")
    print("=" * 80)
    print(f"Input: {args.input}")
    print(f"Output: {args.output_root}")
    print(
        "\nMain report:\n"
        f"{reports_root / 'task7_analysis_report.txt'}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())