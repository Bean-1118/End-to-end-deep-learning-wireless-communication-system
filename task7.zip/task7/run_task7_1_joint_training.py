from __future__ import annotations

import argparse
import json
from pathlib import Path

import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps
from src.task4.checkpoint_utils import (
    restore_task2_checkpoint,
)
from src.task6.iadmm_state import (
    copy_snapshot,
    restore_named_layers,
    save_snapshot_npz,
)
from src.task6.task6_config import (
    Task6Config,
)
from src.task6.task6_parameter_groups import (
    validate_partition,
)
from src.task7.task7_common import (
    build_dataset,
    clean_model,
    evaluate_historical_mean_ber,
    evaluate_snr_sweep,
    make_sgd_optimizer,
    set_all_trainable,
    set_deterministic,
    snapshot_joint_model,
    train_one_epoch,
    write_csv,
)
from src.task7.task7_config import (
    Task7Config,
)


def parse_arguments():
    config = Task7Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 7.1 baseline 1: jointly train the complete model "
            "(shared + particular) using PDP0-PDP5, then deploy "
            "directly to unseen PDP6/PDP7 without adaptation. "
            "Plain SGD is used."
        )
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(
            config.seeds
        ),
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=(
            config.joint_epochs
        ),
    )
    parser.add_argument(
        "--learning-rate",
        type=float,
        default=(
            config.joint_learning_rate
        ),
    )
    parser.add_argument(
        "--blocks-per-pdp",
        type=int,
        default=(
            config.joint_blocks_per_pdp
        ),
    )
    parser.add_argument(
        "--validation-blocks-per-pdp",
        type=int,
        default=(
            config.validation_blocks_per_pdp
        ),
    )
    parser.add_argument(
        "--query-blocks",
        type=int,
        default=(
            config.query_blocks_per_snr
        ),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / "01_joint_training"
        ),
    )

    return parser.parse_args()


def validate_arguments(
    args,
) -> None:
    if not args.seeds:
        raise ValueError(
            "At least one seed is required."
        )
    if args.epochs <= 0:
        raise ValueError(
            "--epochs must be positive."
        )
    if args.learning_rate <= 0:
        raise ValueError(
            "--learning-rate must be positive."
        )
    if args.blocks_per_pdp <= 0:
        raise ValueError(
            "--blocks-per-pdp must be positive."
        )
    if (
        args.validation_blocks_per_pdp
        <= 0
    ):
        raise ValueError(
            "--validation-blocks-per-pdp "
            "must be positive."
        )
    if args.query_blocks <= 0:
        raise ValueError(
            "--query-blocks must be positive."
        )


def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task7Config()
    task6_config = Task6Config()
    pdps = get_known_pdps()

    all_snr_rows: list[
        dict
    ] = []
    all_seed_summary: list[
        dict
    ] = []

    for seed in args.seeds:
        clean_model()
        set_deterministic(
            seed
        )

        model = end_to_end()
        validate_partition(
            model
        )

        # Baseline 1 trains the complete model with both shared and particular layers trainable.
        set_all_trainable(
            model
        )

        # Baseline 1 and Algorithm 1 start from the same Task-2 PDP0 checkpoint.
        restored_checkpoint = (
            restore_task2_checkpoint(
                model=model,
                checkpoint_dir=(
                    task6_config
                    .checkpoint_root
                    / "model_trained_on_PDP0"
                ),
            )
        )

        training_datasets = {
            pdp_id: build_dataset(
                pdp=pdps[pdp_id],
                pdp_id=pdp_id,
                num_blocks=(
                    args.blocks_per_pdp
                ),
                ebno_linear=(
                    config
                    .training_ebno_linear
                ),
                seed=(
                    seed
                    + pdp_id * 1000
                ),
            )
            for pdp_id
            in config.train_pdps
        }

        validation_datasets = {
            pdp_id: build_dataset(
                pdp=pdps[pdp_id],
                pdp_id=pdp_id,
                num_blocks=(
                    args
                    .validation_blocks_per_pdp
                ),
                ebno_linear=(
                    config
                    .training_ebno_linear
                ),
                seed=(
                    seed
                    + 500000
                    + pdp_id * 1000
                ),
            )
            for pdp_id
            in config.train_pdps
        }

        # Use ordinary SGD without Adam.
        optimizer = (
            make_sgd_optimizer(
                learning_rate=(
                    args.learning_rate
                )
            )
        )

        history: list[
            dict
        ] = []

        best_snapshot = None
        best_key = None
        best_epoch = None
        total_updates = 0

        for epoch in range(
            args.epochs
        ):
            metrics = train_one_epoch(
                model=model,
                datasets_by_pdp=(
                    training_datasets
                ),
                optimizer=optimizer,
                epoch=epoch,
                seed=seed,
            )

            total_updates += int(
                metrics[
                    "gradient_updates"
                ]
            )

            (
                mean_validation_ber,
                maximum_validation_ber,
                validation_by_pdp,
            ) = (
                evaluate_historical_mean_ber(
                    model,
                    validation_datasets,
                )
            )

            row = {
                "epoch":
                    epoch + 1,
                "training_loss":
                    metrics["loss"],
                "training_ber":
                    metrics["ber"],
                "gradient_updates_this_epoch":
                    metrics[
                        "gradient_updates"
                    ],
                "cumulative_gradient_updates":
                    total_updates,
                "mean_validation_ber":
                    mean_validation_ber,
                "maximum_validation_ber":
                    maximum_validation_ber,
                "optimizer":
                    "SGD",
                "learning_rate":
                    args.learning_rate,
            }

            for (
                pdp_id,
                ber,
            ) in (
                validation_by_pdp.items()
            ):
                row[
                    f"PDP{pdp_id}"
                    "_validation_ber"
                ] = ber

            history.append(
                row
            )

            candidate_key = (
                mean_validation_ber,
                maximum_validation_ber,
            )

            if (
                best_key is None
                or candidate_key
                < best_key
            ):
                best_key = (
                    candidate_key
                )
                best_epoch = (
                    epoch + 1
                )
                best_snapshot = (
                    copy_snapshot(
                        snapshot_joint_model(
                            model
                        )
                    )
                )

            print(
                f"seed={seed} | "
                f"epoch={epoch + 1}/"
                f"{args.epochs} | "
                f"optimizer=SGD | "
                f"train BER="
                f"{metrics['ber']:.6f} | "
                f"validation BER="
                f"{mean_validation_ber:.6f} | "
                f"worst PDP="
                f"{maximum_validation_ber:.6f}"
            )

        if best_snapshot is None:
            raise RuntimeError(
                "No valid joint-training "
                "checkpoint."
            )

        restore_named_layers(
            model,
            best_snapshot,
        )

        seed_directory = (
            args.output_root
            / f"seed_{seed}"
        )

        save_snapshot_npz(
            seed_directory
            / "joint_model.npz",
            best_snapshot,
        )

        (
            seed_directory
            / "training_history.json"
        ).write_text(
            json.dumps(
                history,
                indent=2,
            ),
            encoding="utf-8",
        )

        (
            seed_directory
            / "metadata.json"
        ).write_text(
            json.dumps(
                {
                    "seed":
                        seed,
                    "epochs_requested":
                        args.epochs,
                    "best_epoch":
                        best_epoch,
                    "best_mean_validation_ber":
                        best_key[0],
                    "best_maximum_validation_ber":
                        best_key[1],
                    "total_gradient_updates":
                        total_updates,
                    "optimizer":
                        "SGD",
                    "optimizer_momentum":
                        0.0,
                    "optimizer_nesterov":
                        False,
                    "learning_rate":
                        args.learning_rate,
                    "restored_checkpoint":
                        str(
                            restored_checkpoint
                        ),
                    "initialisation":
                        (
                            "same PDP0 Task-2 "
                            "checkpoint used by "
                            "Task 6.3"
                        ),
                    "training_method":
                        (
                            "ordinary joint "
                            "training of all "
                            "shared+particular "
                            "parameters on "
                            "PDP0-PDP5"
                        ),
                    "unseen_adaptation":
                        "none",
                },
                indent=2,
            ),
            encoding="utf-8",
        )

        all_seed_summary.append({
            "seed":
                seed,
            "best_epoch":
                best_epoch,
            "best_mean_validation_ber":
                best_key[0],
            "best_maximum_validation_ber":
                best_key[1],
            "total_gradient_updates":
                total_updates,
            "optimizer":
                "SGD",
            "learning_rate":
                args.learning_rate,
        })

        # Deploy the joint model directly to PDP6/PDP7 without new-environment training samples.
        for target_pdp_id in (
            config.unseen_pdps
        ):
            rows = evaluate_snr_sweep(
                model=model,
                pdps=pdps,
                target_pdp_id=(
                    target_pdp_id
                ),
                snr_db_values=(
                    config
                    .snr_db_values
                ),
                query_blocks=(
                    args.query_blocks
                ),
                seed=seed,
                method=(
                    "joint_no_adaptation"
                ),
            )

            for row in rows:
                row.update({
                    "shared_source":
                        (
                            "ordinary_joint_"
                            "training_PDP0_to_"
                            "PDP5"
                        ),
                    "adaptation_blocks":
                        0,
                    "adaptation_epochs":
                        0,
                    "adaptation_optimizer":
                        "none",
                    "training_optimizer":
                        "SGD",
                    "learning_rate":
                        0.0,
                })

            all_snr_rows.extend(
                rows
            )

        write_csv(
            args.output_root
            / (
                "joint_no_adaptation_"
                "snr_raw_partial.csv"
            ),
            all_snr_rows,
        )

        write_csv(
            args.output_root
            / (
                "joint_training_seed_"
                "summary_partial.csv"
            ),
            all_seed_summary,
        )

    final_path = (
        args.output_root
        / "joint_no_adaptation_snr_raw.csv"
    )

    write_csv(
        final_path,
        all_snr_rows,
    )

    write_csv(
        args.output_root
        / "joint_training_seed_summary.csv",
        all_seed_summary,
    )

    print(
        "\nTask 7.1 completed."
    )
    print(
        f"Merge input: {final_path}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )
