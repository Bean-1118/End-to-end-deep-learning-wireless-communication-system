from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np
import tensorflow as tf

from src.task6.iadmm_state import (
    IADMMState,
    LayerSnapshot,
    copy_snapshot,
    restore_named_layers,
)
from src.task6.iadmm_tensor_ops import (
    dual_residual,
    dual_update,
    global_shared_update,
    local_shared_update,
    particular_update,
    primal_residual,
    relative_dual_residual,
    relative_primal_residual,
    snapshot_l2_norm,
)


def variables_by_named_layers(
    model: tf.keras.Model,
    layer_names: Iterable[str],
) -> Tuple[
    List[tf.Variable],
    List[Tuple[str, int]],
]:
    variables: List[tf.Variable] = []
    locations: List[Tuple[str, int]] = []

    for layer_name in layer_names:
        layer = model.get_layer(layer_name)

        for (
            tensor_index,
            variable,
        ) in enumerate(
            layer.trainable_weights
        ):
            variables.append(variable)
            locations.append(
                (
                    layer_name,
                    tensor_index,
                )
            )

    if not variables:
        raise RuntimeError(
            "No trainable variables were found "
            "for the requested layers."
        )

    return variables, locations


def gradients_to_snapshot(
    gradients: List[tf.Tensor | None],
    variables: List[tf.Variable],
    locations: List[Tuple[str, int]],
) -> LayerSnapshot:
    result: LayerSnapshot = {}

    for (
        gradient,
        variable,
        location,
    ) in zip(
        gradients,
        variables,
        locations,
    ):
        layer_name, tensor_index = location

        result.setdefault(
            layer_name,
            [],
        )

        while (
            len(result[layer_name])
            <= tensor_index
        ):
            result[layer_name].append(
                None
            )

        if gradient is None:
            raise RuntimeError(
                "Missing gradient for Algorithm-1 parameter: "
                f"layer={layer_name}, "
                f"tensor={tensor_index}, "
                f"variable={variable.name}, "
                f"shape={tuple(variable.shape)}"
            )

        gradient_value = np.asarray(
            gradient.numpy(),
            dtype=np.float32,
        )

        if not np.all(
            np.isfinite(
                gradient_value
            )
        ):
            raise FloatingPointError(
                "Non-finite gradient for "
                f"{layer_name}[{tensor_index}]"
            )

        result[
            layer_name
        ][tensor_index] = gradient_value

    return result


@dataclass
class EnvironmentBatchResult:
    loss: float
    ber: float


class IADMMTrainer:
    r"""
    Stochastic mini-batch implementation of Algorithm 1.

    State mapping:
        self.state.global_shared       = w^l
        self.state.local_shared[i]     = w_i^l
        self.state.particular[i]       = v_i^l
        self.state.dual[i]             = pi_i^l

    Update order:

      1) w^{l+1}
           = (1/N) sum_i (w_i^l + pi_i^l / sigma)

      2) For each environment i, evaluate

           xi_i^l   = grad_{w_i} f_i(w_i^l, v_i^l)
           zeta_i^l = grad_{v_i} f_i(w_i^l, v_i^l)

         - evaluate gradients at local parameters (w_i^l, v_i^l),
           not at the new global w^{l+1};
         - use f_i directly in the local subproblem, without a 1/N factor.

      3) Eq. (10)

           w_i^{l+1}
             = w^{l+1}
               - (xi_i^l + pi_i^l)/(rho + sigma)

           v_i^{l+1}
             = v_i^l - zeta_i^l/rho

      4) Eq. (9), multiplier update

           pi_i^{l+1}
             = pi_i^l
               + sigma (w_i^{l+1} - w^{l+1})

    The environment objective and gradients are estimated from mini-batches.
    """

    def __init__(
        self,
        model: tf.keras.Model,
        state: IADMMState,
        train_pdp_ids: Iterable[int],
        shared_layer_names: Iterable[str],
        particular_layer_names: Iterable[str],
        rho: float,
        sigma: float,
    ) -> None:
        if rho <= 0:
            raise ValueError(
                "rho must be positive."
            )
        if sigma <= 0:
            raise ValueError(
                "sigma must be positive."
            )

        self.model = model
        self.state = state
        self.train_pdp_ids = tuple(
            train_pdp_ids
        )
        self.shared_layer_names = tuple(
            shared_layer_names
        )
        self.particular_layer_names = tuple(
            particular_layer_names
        )
        self.rho = float(rho)
        self.sigma = float(sigma)

        if not self.train_pdp_ids:
            raise ValueError(
                "At least one environment is required."
            )

        (
            self.shared_variables,
            self.shared_locations,
        ) = variables_by_named_layers(
            model,
            self.shared_layer_names,
        )

        (
            self.particular_variables,
            self.particular_locations,
        ) = variables_by_named_layers(
            model,
            self.particular_layer_names,
        )

    def calculate_environment_gradients(
        self,
        pdp_id: int,
        batch,
    ) -> tuple[
        EnvironmentBatchResult,
        LayerSnapshot,
        LayerSnapshot,
    ]:
        r"""
        Evaluate xi_i^l and zeta_i^l at (w_i^l, v_i^l).

        Gradients are evaluated at the iteration-l local state
        (w_i^l, v_i^l).
        """
        bits, channels, noise_std = batch

        # xi_i^l and zeta_i^l are gradients at the iteration-l local variables.
        restore_named_layers(
            self.model,
            self.state.local_shared[
                pdp_id
            ],
        )
        restore_named_layers(
            self.model,
            self.state.particular[
                pdp_id
            ],
        )

        labels = tf.cast(
            bits,
            tf.float32,
        )

        with tf.GradientTape(
            persistent=True
        ) as tape:
            logits, probabilities = (
                self.model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )
            )

            # Eq. (10) uses grad f_i rather than grad[(1/N) f_i].
            # The 1/N factor in the global objective does not appear in the
            # per-environment argmin.
            environment_loss = (
                tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        labels=labels,
                        logits=logits,
                    )
                )
            )

        shared_gradients = tape.gradient(
            environment_loss,
            self.shared_variables,
        )
        particular_gradients = tape.gradient(
            environment_loss,
            self.particular_variables,
        )
        del tape

        shared_gradient_snapshot = (
            gradients_to_snapshot(
                shared_gradients,
                self.shared_variables,
                self.shared_locations,
            )
        )

        particular_gradient_snapshot = (
            gradients_to_snapshot(
                particular_gradients,
                self.particular_variables,
                self.particular_locations,
            )
        )

        predictions = tf.cast(
            probabilities >= 0.5,
            tf.float32,
        )

        ber = tf.reduce_mean(
            tf.cast(
                predictions != labels,
                tf.float32,
            )
        )

        return (
            EnvironmentBatchResult(
                loss=float(
                    environment_loss.numpy()
                ),
                ber=float(
                    ber.numpy()
                ),
            ),
            shared_gradient_snapshot,
            particular_gradient_snapshot,
        )

    def step(
        self,
        batch_by_pdp: Dict[int, tuple],
        iteration: int,
    ) -> Dict[str, object]:
        missing_batches = (
            set(self.train_pdp_ids)
            - set(batch_by_pdp)
        )

        if missing_batches:
            raise ValueError(
                "Missing batches for PDPs: "
                f"{sorted(missing_batches)}"
            )

        # Keep the iteration-l state for diagnostics and ordered updates.
        old_global_shared = copy_snapshot(
            self.state.global_shared
        )

        # ---------------------------------------------------------------
        # Algorithm 1 / Eq. (9): update w^{l+1} from w_i^l and pi_i^l.
        # ---------------------------------------------------------------
        new_global_shared = (
            global_shared_update(
                local_shared=(
                    self.state.local_shared
                ),
                dual=self.state.dual,
                sigma=self.sigma,
            )
        )

        new_local_shared: Dict[
            int,
            LayerSnapshot,
        ] = {}
        new_particular: Dict[
            int,
            LayerSnapshot,
        ] = {}
        new_dual: Dict[
            int,
            LayerSnapshot,
        ] = {}

        environment_results: Dict[
            int,
            dict,
        ] = {}

        shared_gradient_norms = []
        particular_gradient_norms = []
        shared_update_norms = []
        particular_update_norms = []

        for pdp_id in self.train_pdp_ids:
            # -----------------------------------------------------------
            # Eq. (10): gradients at local state (w_i^l, v_i^l).
            # -----------------------------------------------------------
            (
                batch_result,
                shared_gradient,
                particular_gradient,
            ) = (
                self.calculate_environment_gradients(
                    pdp_id=pdp_id,
                    batch=batch_by_pdp[
                        pdp_id
                    ],
                )
            )

            # -----------------------------------------------------------
            # Eq. (10): w_i^{l+1}.
            # -----------------------------------------------------------
            new_local_shared[
                pdp_id
            ] = local_shared_update(
                new_global_shared=(
                    new_global_shared
                ),
                shared_gradient_at_old_local=(
                    shared_gradient
                ),
                old_dual=(
                    self.state.dual[
                        pdp_id
                    ]
                ),
                rho=self.rho,
                sigma=self.sigma,
            )

            # -----------------------------------------------------------
            # Eq. (10): v_i^{l+1}.
            # -----------------------------------------------------------
            new_particular[
                pdp_id
            ] = particular_update(
                old_particular=(
                    self.state.particular[
                        pdp_id
                    ]
                ),
                particular_gradient_at_old_local=(
                    particular_gradient
                ),
                rho=self.rho,
            )

            # -----------------------------------------------------------
            # Eq. (9): pi_i^{l+1}.
            # -----------------------------------------------------------
            new_dual[
                pdp_id
            ] = dual_update(
                old_dual=(
                    self.state.dual[
                        pdp_id
                    ]
                ),
                new_local_shared=(
                    new_local_shared[
                        pdp_id
                    ]
                ),
                new_global_shared=(
                    new_global_shared
                ),
                sigma=self.sigma,
            )

            shared_gradient_norms.append(
                snapshot_l2_norm(
                    shared_gradient
                )
            )

            particular_gradient_norms.append(
                snapshot_l2_norm(
                    particular_gradient
                )
            )

            shared_update_norms.append(
                snapshot_l2_norm({
                    layer_name: [
                        new_value
                        - old_value
                        for (
                            new_value,
                            old_value,
                        ) in zip(
                            new_local_shared[
                                pdp_id
                            ][layer_name],
                            self.state.local_shared[
                                pdp_id
                            ][layer_name],
                        )
                    ]
                    for layer_name
                    in new_local_shared[
                        pdp_id
                    ]
                })
            )

            particular_update_norms.append(
                snapshot_l2_norm({
                    layer_name: [
                        new_value
                        - old_value
                        for (
                            new_value,
                            old_value,
                        ) in zip(
                            new_particular[
                                pdp_id
                            ][layer_name],
                            self.state.particular[
                                pdp_id
                            ][layer_name],
                        )
                    ]
                    for layer_name
                    in new_particular[
                        pdp_id
                    ]
                })
            )

            environment_results[
                pdp_id
            ] = {
                "loss": batch_result.loss,
                "ber": batch_result.ber,
            }

        # Commit l+1 simultaneously after every environment was calculated
        # from the same l-th state.
        self.state.global_shared = (
            new_global_shared
        )
        self.state.local_shared = (
            new_local_shared
        )
        self.state.particular = (
            new_particular
        )
        self.state.dual = new_dual

        current_primal = (
            primal_residual(
                self.state.local_shared,
                self.state.global_shared,
            )
        )

        current_dual = (
            dual_residual(
                self.state.global_shared,
                old_global_shared,
                self.sigma,
                len(
                    self.train_pdp_ids
                ),
            )
        )

        current_relative_primal = (
            relative_primal_residual(
                self.state.local_shared,
                self.state.global_shared,
            )
        )

        current_relative_dual = (
            relative_dual_residual(
                self.state.global_shared,
                old_global_shared,
                self.sigma,
                len(
                    self.train_pdp_ids
                ),
            )
        )

        losses = [
            result["loss"]
            for result
            in environment_results.values()
        ]

        bers = [
            result["ber"]
            for result
            in environment_results.values()
        ]

        return {
            "iteration": iteration,
            "rho": self.rho,
            "sigma": self.sigma,
            "mean_loss": float(
                np.mean(losses)
            ),
            "mean_ber": float(
                np.mean(bers)
            ),
            "maximum_ber": float(
                np.max(bers)
            ),
            "primal_residual":
                current_primal,
            "dual_residual":
                current_dual,
            "relative_primal_residual":
                current_relative_primal,
            "relative_dual_residual":
                current_relative_dual,
            "mean_shared_gradient_l2":
                float(
                    np.mean(
                        shared_gradient_norms
                    )
                ),
            "mean_particular_gradient_l2":
                float(
                    np.mean(
                        particular_gradient_norms
                    )
                ),
            "mean_local_shared_update_l2":
                float(
                    np.mean(
                        shared_update_norms
                    )
                ),
            "mean_particular_update_l2":
                float(
                    np.mean(
                        particular_update_norms
                    )
                ),
            "environment_results":
                environment_results,
            "gradient_evaluation_point":
                "old_local_w_i_and_old_v_i",
            "gradient_objective_scaling":
                "unscaled_environment_loss_f_i",
        }
