from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def population_std(series):
    return float(series.std(ddof=0))


def analyse_training_root(
    training_root: Path,
    output_root: Path,
) -> None:
    rows = []

    for seed_dir in sorted(training_root.glob("seed_*")):
        history_path = seed_dir / "convergence_history.csv"
        metadata_path = seed_dir / "metadata.json"

        if not history_path.exists():
            continue

        history = pd.read_csv(history_path)
        validation = history.dropna(
            subset=["mean_validation_ber"]
        ).copy()

        if validation.empty:
            continue

        metadata = {}
        if metadata_path.exists():
            metadata = json.loads(
                metadata_path.read_text(encoding="utf-8")
            )

        best_index = validation[
            "mean_validation_ber"
        ].idxmin()
        best_row = validation.loc[best_index]
        final_row = validation.iloc[-1]

        rows.append({
            "seed": int(seed_dir.name.split("_")[-1]),
            "rho": metadata.get("rho", np.nan),
            "sigma": metadata.get("sigma", np.nan),
            "best_iteration": metadata.get(
                "best_iteration",
                int(best_row["iteration"]),
            ),
            "best_mean_validation_ber": metadata.get(
                "best_mean_validation_ber",
                float(best_row["mean_validation_ber"]),
            ),
            "best_maximum_validation_ber": metadata.get(
                "best_maximum_validation_ber",
                float(best_row["maximum_validation_ber"]),
            ),
            "best_relative_primal_residual": metadata.get(
                "best_relative_primal_residual",
                float(best_row.get(
                    "relative_primal_residual",
                    np.nan,
                )),
            ),
            "best_relative_dual_residual": metadata.get(
                "best_relative_dual_residual",
                float(best_row.get(
                    "relative_dual_residual",
                    np.nan,
                )),
            ),
            "final_mean_validation_ber": float(
                final_row["mean_validation_ber"]
            ),
            "final_maximum_validation_ber": float(
                final_row["maximum_validation_ber"]
            ),
            "final_relative_primal_residual": float(
                final_row.get(
                    "relative_primal_residual",
                    np.nan,
                )
            ),
            "final_relative_dual_residual": float(
                final_row.get(
                    "relative_dual_residual",
                    np.nan,
                )
            ),
            "final_mean_shared_gradient_l2": float(
                final_row.get(
                    "mean_shared_gradient_l2",
                    np.nan,
                )
            ),
            "final_mean_particular_gradient_l2": float(
                final_row.get(
                    "mean_particular_gradient_l2",
                    np.nan,
                )
            ),
            "final_mean_local_shared_update_l2": float(
                final_row.get(
                    "mean_local_shared_update_l2",
                    np.nan,
                )
            ),
            "final_mean_particular_update_l2": float(
                final_row.get(
                    "mean_particular_update_l2",
                    np.nan,
                )
            ),
        })

    if not rows:
        raise FileNotFoundError(
            f"No training results found in {training_root}"
        )

    output_root.mkdir(parents=True, exist_ok=True)
    dataframe = pd.DataFrame(rows)
    dataframe.to_csv(
        output_root / "iadmm_training_seed_summary.csv",
        index=False,
    )

    aggregate = pd.DataFrame([{
        "seed_count": dataframe["seed"].nunique(),
        "rho": dataframe["rho"].iloc[0],
        "sigma": dataframe["sigma"].iloc[0],
        "mean_best_validation_ber": dataframe[
            "best_mean_validation_ber"
        ].mean(),
        "std_best_validation_ber": population_std(
            dataframe["best_mean_validation_ber"]
        ),
        "mean_best_worst_pdp_ber": dataframe[
            "best_maximum_validation_ber"
        ].mean(),
        "mean_best_relative_primal_residual": dataframe[
            "best_relative_primal_residual"
        ].mean(),
        "mean_best_relative_dual_residual": dataframe[
            "best_relative_dual_residual"
        ].mean(),
        "mean_best_iteration": dataframe[
            "best_iteration"
        ].mean(),
    }])

    aggregate.to_csv(
        output_root / "iadmm_training_aggregate.csv",
        index=False,
    )

    print("\nTask 6.3 seed summary:")
    print(dataframe.to_string(index=False))
    print("\nTask 6.3 aggregate:")
    print(aggregate.to_string(index=False))


def analyse_adaptation_root(
    adaptation_root: Path,
    output_root: Path,
) -> None:
    input_path = (
        adaptation_root / "unseen_adaptation_raw.csv"
    )
    if not input_path.exists():
        print(
            f"\nNo Task 6.4 result found at {input_path}; "
            "skipping adaptation summary."
        )
        return

    dataframe = pd.read_csv(input_path)
    required_columns = {
        "seed",
        "target_pdp",
        "adaptation_blocks",
        "method",
        "zero_shot_ber",
        "adapted_ber",
        "absolute_improvement",
        "relative_improvement",
    }
    missing = required_columns - set(dataframe.columns)
    if missing:
        raise ValueError(
            "Missing adaptation columns: "
            f"{sorted(missing)}"
        )

    summary = (
        dataframe
        .groupby(
            [
                "target_pdp",
                "adaptation_blocks",
                "method",
            ],
            as_index=False,
        )
        .agg(
            seed_count=("seed", "nunique"),
            mean_zero_shot_ber=("zero_shot_ber", "mean"),
            std_zero_shot_ber=("zero_shot_ber", population_std),
            mean_adapted_ber=("adapted_ber", "mean"),
            std_adapted_ber=("adapted_ber", population_std),
            mean_absolute_improvement=("absolute_improvement", "mean"),
            std_absolute_improvement=(
                "absolute_improvement",
                population_std,
            ),
            mean_relative_improvement=("relative_improvement", "mean"),
            positive_improvement_fraction=(
                "absolute_improvement",
                lambda values: float((values > 0).mean()),
            ),
        )
    )

    output_root.mkdir(parents=True, exist_ok=True)
    summary.to_csv(
        output_root / "unseen_adaptation_summary.csv",
        index=False,
    )

    print("\nTask 6.4 adaptation summary:")
    print(summary.to_string(index=False))


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--training-root",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--adaptation-root",
        type=Path,
        default=None,
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        required=True,
    )
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    analyse_training_root(
        args.training_root,
        args.output_root,
    )
    if args.adaptation_root is not None:
        analyse_adaptation_root(
            args.adaptation_root,
            args.output_root,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
