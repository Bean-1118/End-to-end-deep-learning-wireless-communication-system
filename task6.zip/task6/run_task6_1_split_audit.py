from __future__ import annotations

import json

from src.task6.task6_config import Task6Config


def main() -> int:
    config = Task6Config()

    train_set = set(config.train_pdps)
    unseen_set = set(config.unseen_pdps)
    overlap = train_set.intersection(unseen_set)

    if overlap:
        raise ValueError(
            "PDP leakage between historical and unseen sets: "
            f"{sorted(overlap)}"
        )

    if len(train_set) != len(config.train_pdps):
        raise ValueError("Duplicate historical PDP IDs.")
    if len(unseen_set) != len(config.unseen_pdps):
        raise ValueError("Duplicate unseen PDP IDs.")

    output_directory = (
        config.output_root / "split_audit"
    )
    output_directory.mkdir(parents=True, exist_ok=True)

    result = {
        "historical_train_pdps": list(config.train_pdps),
        "unseen_test_pdps": list(config.unseen_pdps),
        "overlap": sorted(overlap),
        "valid": len(overlap) == 0,
        "algorithm_1_environment_count": len(config.train_pdps),
    }

    (
        output_directory / "environment_split.json"
    ).write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
