from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps

from src.task4.checkpoint_utils import restore_task2_checkpoint
from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
)

from src.task6.iadmm_state import (
    average_snapshots,
    initialise_iadmm_state,
)
from src.task6.iadmm_trainer import IADMMTrainer
from src.task6.task6_config import Task6Config
from src.task6.task6_parameter_groups import (
    PARTICULAR_LAYER_NAMES,
    shared_layer_names,
    validate_partition,
)

from src.task7.task7_common import (
    adapt_particular,
    evaluate_ber,
)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return

    path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def parse_pair(text: str) -> tuple[float, float]:
    try:
        rho_text, sigma_text = text.split(":", maxsplit=1)
        rho = float(rho_text)
        sigma = float(sigma_text)
    except Exception as exc:
        raise argparse.ArgumentTypeError(
            f"Invalid pair {text!r}; use RHO:SIGMA, e.g. 100:10."
        ) from exc

    if rho <= 0 or sigma <= 0:
        raise argparse.ArgumentTypeError(
            "rho and sigma must both be positive."
        )
    if sigma >= rho:
        raise argparse.ArgumentTypeError(
            f"Require sigma < rho; received rho={rho}, sigma={sigma}."
        )

    return rho, sigma


def build_pairs(args: argparse.Namespace) -> list[tuple[float, float]]:
    if args.pairs:
        pairs = list(dict.fromkeys(args.pairs))
    else:
        pairs = [
            (rho, sigma)
            for rho in args.rho_values
            for sigma in args.sigma_values
            if sigma < rho
        ]

    if not pairs:
        raise ValueError("No valid rho/sigma pairs were supplied.")

    return pairs


def next_batch(
    *,
    pdp_id: int,
    iterators: dict[int, object],
    datasets: dict[int, object],
    iteration: int,
    seed: int,
):
    try:
        return next(iterators[pdp_id])
    except StopIteration:
        iterators[pdp_id] = iter(
            iter_fixed_batches(
                dataset=datasets[pdp_id],
                epoch=iteration + 1,
                shuffle_seed=seed + 10000 + pdp_id,
            )
        )
        return next(iterators[pdp_id])


def make_environment_datasets(
    *,
    pdps,
    pdp_ids: Iterable[int],
    num_blocks: int,
    ebno_linear: float,
    base_seed: int,
) -> dict[int, object]:
    return {
        pdp_id: make_fixed_adaptation_dataset(
            pdp_target=pdps[pdp_id],
            pdp_id=pdp_id,
            num_blocks=num_blocks,
            ebno_linear=ebno_linear,
            seed=base_seed + pdp_id * 1000,
        )
        for pdp_id in pdp_ids
    }


def train_fold(
    *,
    rho: float,
    sigma: float,
    iterations: int,
    seed: int,
    train_pdp_ids: tuple[int, ...],
    blocks_per_pdp: int,
    ebno_linear: float,
    checkpoint_root: Path,
):
    tf.keras.backend.clear_session()
    gc.collect()
    set_all_seeds(seed)

    model = end_to_end()
    validate_partition(model)

    restored_checkpoint = restore_task2_checkpoint(
        model=model,
        checkpoint_dir=(
            checkpoint_root / "model_trained_on_PDP0"
        ),
    )

    shared_names = shared_layer_names(model)

    state = initialise_iadmm_state(
        model=model,
        train_pdp_ids=train_pdp_ids,
        shared_layer_names=shared_names,
        particular_layer_names=PARTICULAR_LAYER_NAMES,
    )

    trainer = IADMMTrainer(
        model=model,
        state=state,
        train_pdp_ids=train_pdp_ids,
        shared_layer_names=shared_names,
        particular_layer_names=PARTICULAR_LAYER_NAMES,
        rho=rho,
        sigma=sigma,
    )

    pdps = get_known_pdps()
    training_datasets = make_environment_datasets(
        pdps=pdps,
        pdp_ids=train_pdp_ids,
        num_blocks=blocks_per_pdp,
        ebno_linear=ebno_linear,
        base_seed=seed,
    )

    iterators = {
        pdp_id: iter(
            iter_fixed_batches(
                dataset=dataset,
                epoch=0,
                shuffle_seed=seed + 10000 + pdp_id,
            )
        )
        for pdp_id, dataset in training_datasets.items()
    }

    final_metrics = None

    for iteration in range(iterations):
        batch_by_pdp = {
            pdp_id: next_batch(
                pdp_id=pdp_id,
                iterators=iterators,
                datasets=training_datasets,
                iteration=iteration,
                seed=seed,
            )
            for pdp_id in train_pdp_ids
        }

        final_metrics = trainer.step(
            batch_by_pdp=batch_by_pdp,
            iteration=iteration,
        )

        numeric_values = [
            final_metrics["mean_loss"],
            final_metrics["mean_ber"],
            final_metrics["primal_residual"],
            final_metrics["dual_residual"],
            final_metrics.get("relative_primal_residual", np.nan),
            final_metrics.get("relative_dual_residual", np.nan),
        ]

        finite_values = [
            value for value in numeric_values
            if not np.isnan(value)
        ]
        if not np.all(np.isfinite(finite_values)):
            raise FloatingPointError(
                "Algorithm 1 diverged to NaN/Inf."
            )

        if (
            iteration == 0
            or (iteration + 1) % 250 == 0
            or iteration + 1 == iterations
        ):
            print(
                f"    iter={iteration + 1}/{iterations} | "
                f"train BER={final_metrics['mean_ber']:.6f} | "
                f"primal={final_metrics['primal_residual']:.3e} | "
                f"dual={final_metrics['dual_residual']:.3e}"
            )

    if final_metrics is None:
        raise RuntimeError("No Algorithm-1 update was completed.")

    historical_particular = [
        trainer.state.particular[pdp_id]
        for pdp_id in train_pdp_ids
    ]

    return {
        "model": model,
        "global_shared": trainer.state.global_shared,
        "initial_particular": average_snapshots(
            historical_particular
        ),
        "final_metrics": final_metrics,
        "restored_checkpoint": restored_checkpoint,
    }


def evaluate_held_out_transfer(
    *,
    model: tf.keras.Model,
    global_shared,
    initial_particular,
    held_out_pdp: int,
    seed: int,
    support_blocks: int,
    query_blocks: int,
    adaptation_epochs: int,
    adaptation_learning_rate: float,
    ebno_linear: float,
) -> dict:
    from src.task6.iadmm_state import restore_named_layers

    pdps = get_known_pdps()

    support_seed = (
        seed + 200000 + held_out_pdp * 10000
    )
    query_seed = (
        seed + 400000 + held_out_pdp * 10000
    )

    support_dataset = make_fixed_adaptation_dataset(
        pdp_target=pdps[held_out_pdp],
        pdp_id=held_out_pdp,
        num_blocks=support_blocks,
        ebno_linear=ebno_linear,
        seed=support_seed,
    )
    query_dataset = make_fixed_adaptation_dataset(
        pdp_target=pdps[held_out_pdp],
        pdp_id=held_out_pdp,
        num_blocks=query_blocks,
        ebno_linear=ebno_linear,
        seed=query_seed,
    )

    restore_named_layers(model, global_shared)
    restore_named_layers(model, initial_particular)

    zero_shot_ber = evaluate_ber(model, query_dataset)

    adaptation_history = adapt_particular(
        model=model,
        dataset=support_dataset,
        epochs=adaptation_epochs,
        learning_rate=adaptation_learning_rate,
        seed=support_seed,
    )

    adapted_ber = evaluate_ber(model, query_dataset)

    return {
        "zero_shot_ber": zero_shot_ber,
        "adapted_ber": adapted_ber,
        "absolute_improvement": zero_shot_ber - adapted_ber,
        "relative_improvement": (
            (zero_shot_ber - adapted_ber)
            / max(zero_shot_ber, 1e-12)
        ),
        "final_support_ber": adaptation_history[-1]["ber"],
        "support_seed": support_seed,
        "query_seed": query_seed,
    }


def aggregate_results(raw: pd.DataFrame) -> pd.DataFrame:
    grouped = (
        raw
        .groupby(["rho", "sigma"], as_index=False)
        .agg(
            seed_count=("seed", "nunique"),
            fold_count=("held_out_pdp", "nunique"),
            run_count=("adapted_ber", "count"),
            mean_zero_shot_ber=("zero_shot_ber", "mean"),
            mean_adapted_ber=("adapted_ber", "mean"),
            std_adapted_ber=("adapted_ber", lambda x: float(x.std(ddof=0))),
            worst_fold_adapted_ber=("adapted_ber", "max"),
            mean_absolute_improvement=("absolute_improvement", "mean"),
            mean_relative_improvement=("relative_improvement", "mean"),
            positive_improvement_fraction=(
                "absolute_improvement",
                lambda x: float((x > 0).mean()),
            ),
            mean_final_training_ber=("final_training_ber", "mean"),
            mean_relative_primal_residual=(
                "relative_primal_residual",
                "mean",
            ),
            mean_relative_dual_residual=(
                "relative_dual_residual",
                "mean",
            ),
        )
    )

    return grouped.sort_values(
        [
            "mean_adapted_ber",
            "worst_fold_adapted_ber",
            "std_adapted_ber",
            "mean_relative_primal_residual",
            "mean_relative_dual_residual",
        ]
    ).reset_index(drop=True)


def parse_arguments() -> argparse.Namespace:
    config = Task6Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 6.2b: transfer-oriented rho/sigma selection using "
            "leave-one-PDP-out validation inside PDP0-PDP5."
        )
    )

    parser.add_argument(
        "--pairs",
        nargs="+",
        type=parse_pair,
        default=None,
        metavar="RHO:SIGMA",
        help=(
            "Explicit pairs, e.g. --pairs 75:15 100:10 200:5. "
            "If supplied, --rho-values/--sigma-values are ignored."
        ),
    )
    parser.add_argument(
        "--rho-values",
        nargs="+",
        type=float,
        default=[50, 75, 100, 150, 200],
    )
    parser.add_argument(
        "--sigma-values",
        nargs="+",
        type=float,
        default=[2.5, 5, 7.5, 10, 15, 20],
    )
    parser.add_argument(
        "--held-out-pdps",
        nargs="+",
        type=int,
        default=[1, 2, 3, 4, 5],
        help=(
            "Do not hold out PDP0 while using the PDP0-pretrained "
            "initial checkpoint; that would leak held-out data."
        ),
    )
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[2026],
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=1500,
    )
    parser.add_argument(
        "--blocks-per-pdp",
        type=int,
        default=2048,
    )
    parser.add_argument(
        "--support-blocks",
        type=int,
        default=2048,
    )
    parser.add_argument(
        "--query-blocks",
        type=int,
        default=4096,
    )
    parser.add_argument(
        "--adaptation-epochs",
        type=int,
        default=20,
    )
    parser.add_argument(
        "--adaptation-learning-rate",
        type=float,
        default=1e-4,
    )
    parser.add_argument(
        "--ebno-linear",
        type=float,
        default=config.ebno_linear,
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / "rho_sigma_transfer_search"
        ),
    )

    return parser.parse_args()


def validate_arguments(args: argparse.Namespace) -> None:
    allowed = {0, 1, 2, 3, 4, 5}
    held_out = set(args.held_out_pdps)

    if not held_out:
        raise ValueError("At least one held-out PDP is required.")
    if not held_out.issubset(allowed):
        raise ValueError(
            "Held-out PDPs must be selected from PDP0-PDP5."
        )
    if 0 in held_out:
        raise ValueError(
            "PDP0 cannot be a clean held-out fold because the current "
            "initial checkpoint was trained on PDP0. Use held-out "
            "PDPs 1-5, or provide a neutral checkpoint."
        )
    if args.iterations <= 0:
        raise ValueError("--iterations must be positive.")
    if args.blocks_per_pdp <= 0:
        raise ValueError("--blocks-per-pdp must be positive.")
    if args.support_blocks <= 0:
        raise ValueError("--support-blocks must be positive.")
    if args.query_blocks <= 0:
        raise ValueError("--query-blocks must be positive.")
    if args.adaptation_epochs <= 0:
        raise ValueError("--adaptation-epochs must be positive.")
    if args.adaptation_learning_rate <= 0:
        raise ValueError(
            "--adaptation-learning-rate must be positive."
        )


def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task6Config()
    all_historical = tuple(config.train_pdps)
    pairs = build_pairs(args)

    args.output_root.mkdir(parents=True, exist_ok=True)

    settings = {
        "pairs": [
            {"rho": rho, "sigma": sigma}
            for rho, sigma in pairs
        ],
        "held_out_pdps": args.held_out_pdps,
        "seeds": args.seeds,
        "iterations": args.iterations,
        "blocks_per_pdp": args.blocks_per_pdp,
        "support_blocks": args.support_blocks,
        "query_blocks": args.query_blocks,
        "adaptation_epochs": args.adaptation_epochs,
        "adaptation_learning_rate": (
            args.adaptation_learning_rate
        ),
        "ebno_linear": args.ebno_linear,
        "selection_target": (
            "mean held-out adapted BER after particular-only "
            "adaptation; PDP6/PDP7 are never used"
        ),
        "leakage_note": (
            "PDP0 is not held out because the common starting "
            "checkpoint was pretrained on PDP0."
        ),
    }
    (
        args.output_root / "search_settings.json"
    ).write_text(
        json.dumps(settings, indent=2),
        encoding="utf-8",
    )

    rows: list[dict] = []

    for rho, sigma in pairs:
        for seed in args.seeds:
            for held_out_pdp in args.held_out_pdps:
                train_pdp_ids = tuple(
                    pdp_id
                    for pdp_id in all_historical
                    if pdp_id != held_out_pdp
                )

                print("\n" + "=" * 80)
                print(
                    f"rho={rho:g}, sigma={sigma:g}, seed={seed}, "
                    f"held-out=PDP{held_out_pdp}, "
                    f"train={train_pdp_ids}"
                )
                print("=" * 80)

                try:
                    trained = train_fold(
                        rho=rho,
                        sigma=sigma,
                        iterations=args.iterations,
                        seed=seed,
                        train_pdp_ids=train_pdp_ids,
                        blocks_per_pdp=args.blocks_per_pdp,
                        ebno_linear=args.ebno_linear,
                        checkpoint_root=config.checkpoint_root,
                    )

                    transfer = evaluate_held_out_transfer(
                        model=trained["model"],
                        global_shared=trained["global_shared"],
                        initial_particular=trained[
                            "initial_particular"
                        ],
                        held_out_pdp=held_out_pdp,
                        seed=seed,
                        support_blocks=args.support_blocks,
                        query_blocks=args.query_blocks,
                        adaptation_epochs=args.adaptation_epochs,
                        adaptation_learning_rate=(
                            args.adaptation_learning_rate
                        ),
                        ebno_linear=args.ebno_linear,
                    )

                    metrics = trained["final_metrics"]

                    row = {
                        "rho": rho,
                        "sigma": sigma,
                        "seed": seed,
                        "held_out_pdp": held_out_pdp,
                        "train_pdps": " ".join(
                            str(value) for value in train_pdp_ids
                        ),
                        "failed": 0,
                        "iterations": args.iterations,
                        "blocks_per_pdp": args.blocks_per_pdp,
                        "support_blocks": args.support_blocks,
                        "query_blocks": args.query_blocks,
                        "adaptation_epochs": args.adaptation_epochs,
                        "adaptation_learning_rate": (
                            args.adaptation_learning_rate
                        ),
                        "zero_shot_ber": transfer[
                            "zero_shot_ber"
                        ],
                        "adapted_ber": transfer["adapted_ber"],
                        "absolute_improvement": transfer[
                            "absolute_improvement"
                        ],
                        "relative_improvement": transfer[
                            "relative_improvement"
                        ],
                        "final_support_ber": transfer[
                            "final_support_ber"
                        ],
                        "support_seed": transfer["support_seed"],
                        "query_seed": transfer["query_seed"],
                        "final_training_loss": metrics["mean_loss"],
                        "final_training_ber": metrics["mean_ber"],
                        "maximum_training_ber": metrics[
                            "maximum_ber"
                        ],
                        "primal_residual": metrics[
                            "primal_residual"
                        ],
                        "dual_residual": metrics[
                            "dual_residual"
                        ],
                        "relative_primal_residual": metrics.get(
                            "relative_primal_residual",
                            np.nan,
                        ),
                        "relative_dual_residual": metrics.get(
                            "relative_dual_residual",
                            np.nan,
                        ),
                        "restored_checkpoint": str(
                            trained["restored_checkpoint"]
                        ),
                    }

                    print(
                        f"held-out zero-shot BER="
                        f"{transfer['zero_shot_ber']:.6f} | "
                        f"adapted BER={transfer['adapted_ber']:.6f} | "
                        f"relative improvement="
                        f"{100 * transfer['relative_improvement']:.2f}%"
                    )

                except Exception as exc:
                    row = {
                        "rho": rho,
                        "sigma": sigma,
                        "seed": seed,
                        "held_out_pdp": held_out_pdp,
                        "train_pdps": " ".join(
                            str(value) for value in train_pdp_ids
                        ),
                        "failed": 1,
                        "error_type": type(exc).__name__,
                        "error_message": str(exc),
                    }
                    print(
                        f"FAILED: {type(exc).__name__}: {exc}"
                    )

                rows.append(row)
                write_csv(
                    args.output_root
                    / "transfer_search_raw_partial.csv",
                    rows,
                )

    raw_path = (
        args.output_root / "transfer_search_raw.csv"
    )
    write_csv(raw_path, rows)

    raw = pd.DataFrame(rows)
    valid = raw[raw["failed"] == 0].copy()

    if valid.empty:
        raise RuntimeError(
            "All transfer-search runs failed."
        )

    ranked = aggregate_results(valid)
    ranked.insert(
        0,
        "rank",
        np.arange(1, len(ranked) + 1),
    )

    ranked_path = (
        args.output_root
        / "transfer_search_ranked_summary.csv"
    )
    ranked.to_csv(ranked_path, index=False)

    best = ranked.iloc[0].to_dict()
    (
        args.output_root
        / "selected_transfer_hyperparameters.json"
    ).write_text(
        json.dumps(
            {
                "rho": float(best["rho"]),
                "sigma": float(best["sigma"]),
                "mean_adapted_ber": float(
                    best["mean_adapted_ber"]
                ),
                "worst_fold_adapted_ber": float(
                    best["worst_fold_adapted_ber"]
                ),
                "selection_rule": (
                    "lowest mean held-out adapted BER, then lowest "
                    "worst-fold BER, standard deviation and residuals"
                ),
                "important": (
                    "This is a transfer-validation selection on "
                    "PDP1-PDP5. Confirm the top candidates with all "
                    "five folds and three seeds before retraining "
                    "PDP0-PDP5 for the final PDP6/PDP7 test."
                ),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nTransfer-search ranking:")
    print(ranked.to_string(index=False))
    print("\nSaved:")
    print(raw_path)
    print(ranked_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
