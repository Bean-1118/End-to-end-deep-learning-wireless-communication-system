from __future__ import annotations

import numpy as np

from src.task6.iadmm_tensor_ops import (
    dual_update,
    global_shared_update,
    local_shared_update,
    particular_update,
)


def snap(value: float):
    return {
        "layer": [
            np.asarray(
                [value],
                dtype=np.float32,
            )
        ]
    }


def scalar(snapshot):
    return float(
        snapshot["layer"][0][0]
    )


def main() -> int:
    # Two environments:
    # w_1^l = 2, w_2^l = 4
    # pi_1^l = 1, pi_2^l = -1
    # sigma = 2
    #
    # Paper global update:
    # w^{l+1}
    # = 1/2 * [(2 + 1/2) + (4 - 1/2)]
    # = 3.
    local = {
        1: snap(2.0),
        2: snap(4.0),
    }
    dual = {
        1: snap(1.0),
        2: snap(-1.0),
    }

    sigma = 2.0
    rho = 3.0

    w_new = global_shared_update(
        local_shared=local,
        dual=dual,
        sigma=sigma,
    )

    assert np.isclose(
        scalar(w_new),
        3.0,
    )

    # Environment 1:
    # xi_1^l = 5
    # zeta_1^l = 6
    # v_1^l = 10
    #
    # w_1^{l+1}
    # = 3 - (5 + 1)/(3 + 2)
    # = 1.8
    #
    # v_1^{l+1}
    # = 10 - 6/3
    # = 8.
    w1_new = local_shared_update(
        new_global_shared=w_new,
        shared_gradient_at_old_local=snap(5.0),
        old_dual=dual[1],
        rho=rho,
        sigma=sigma,
    )

    v1_new = particular_update(
        old_particular=snap(10.0),
        particular_gradient_at_old_local=snap(6.0),
        rho=rho,
    )

    assert np.isclose(
        scalar(w1_new),
        1.8,
    )
    assert np.isclose(
        scalar(v1_new),
        8.0,
    )

    # pi_1^{l+1}
    # = 1 + 2*(1.8 - 3)
    # = -1.4
    pi1_new = dual_update(
        old_dual=dual[1],
        new_local_shared=w1_new,
        new_global_shared=w_new,
        sigma=sigma,
    )

    assert np.isclose(
        scalar(pi1_new),
        -1.4,
    )

    print(
        "PASS: Algorithm-1 tensor equations match "
        "the paper's one-step hand calculation."
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
