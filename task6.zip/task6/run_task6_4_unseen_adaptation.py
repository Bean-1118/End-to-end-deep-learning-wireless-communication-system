from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path
from typing import Mapping

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps

from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
)

from src.task6.iadmm_state import (
    average_snapshots,
    load_snapshot_npz,
    restore_named_layers,
)

from src.task6.task6_config import (
    Task6Config,
)

from src.task6.task6_parameter_groups import (
    PARTICULAR_LAYER_NAMES,
    validate_partition,
)


def write_csv(
    path: Path,
    rows,
) -> None:
    if not rows:
        return

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames = []

    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )

        writer.writeheader()
        writer.writerows(rows)



# ============================================================
# Parameter-change audit
# ============================================================

EPSILON = 1e-12


def snapshot_all_layer_weights(
    model: tf.keras.Model,
) -> dict[str, list[np.ndarray]]:
    """Copy every parameter-bearing layer before adaptation."""
    return {
        layer.name: [
            np.asarray(variable.numpy()).copy()
            for variable in layer.weights
        ]
        for layer in model.layers
        if layer.weights
    }


def calculate_parameter_change_audit(
    model: tf.keras.Model,
    before_snapshot: Mapping[str, list[np.ndarray]],
    seed: int,
    target_pdp: int,
    adaptation_blocks: int,
    method: str,
) -> list[dict]:
    """Calculate layer-level parameter changes after adaptation."""
    particular_layers = set(PARTICULAR_LAYER_NAMES)
    rows: list[dict] = []

    for layer in model.layers:
        if layer.name not in before_snapshot:
            continue

        before_values = before_snapshot[layer.name]
        after_values = [
            np.asarray(variable.numpy())
            for variable in layer.weights
        ]

        if len(before_values) != len(after_values):
            raise ValueError(
                f"Tensor-count mismatch for {layer.name}: "
                f"before={len(before_values)}, after={len(after_values)}"
            )

        before_flat_parts = []
        delta_flat_parts = []

        for tensor_index, (before_value, after_value) in enumerate(
            zip(before_values, after_values)
        ):
            if tuple(before_value.shape) != tuple(after_value.shape):
                raise ValueError(
                    f"Shape mismatch for {layer.name}, tensor {tensor_index}: "
                    f"before={before_value.shape}, after={after_value.shape}"
                )

            before_array = np.asarray(before_value, dtype=np.float64)
            after_array = np.asarray(after_value, dtype=np.float64)
            delta_array = after_array - before_array

            before_flat_parts.append(before_array.reshape(-1))
            delta_flat_parts.append(delta_array.reshape(-1))

        if not before_flat_parts:
            continue

        before_flat = np.concatenate(before_flat_parts)
        delta_flat = np.concatenate(delta_flat_parts)

        weight_l2_before = float(np.linalg.norm(before_flat, ord=2))
        delta_l2 = float(np.linalg.norm(delta_flat, ord=2))

        rows.append({
            "seed": seed,
            "target_pdp": target_pdp,
            "adaptation_blocks": adaptation_blocks,
            "method": method,
            "layer_name": layer.name,
            "parameter_group": (
                "particular"
                if layer.name in particular_layers
                else "shared"
            ),
            "parameter_count": int(delta_flat.size),
            "weight_l2_before": weight_l2_before,
            "delta_l2": delta_l2,
            "relative_delta_l2": (
                delta_l2 / (weight_l2_before + EPSILON)
            ),
            "mean_absolute_delta": float(
                np.mean(np.abs(delta_flat))
            ),
            "max_absolute_delta": float(
                np.max(np.abs(delta_flat))
            ),
            "changed_parameter_fraction": float(
                np.mean(np.abs(delta_flat) > 1e-8)
            ),
        })

    return rows


def verify_shared_parameters_unchanged(
    audit_rows: list[dict],
    tolerance: float,
) -> None:
    """Fail if a frozen shared layer changes beyond tolerance."""
    violating_rows = [
        row
        for row in audit_rows
        if (
            row["parameter_group"] == "shared"
            and row["max_absolute_delta"] > tolerance
        )
    ]

    if violating_rows:
        details = "\n".join(
            f"{row['layer_name']}: "
            f"max_delta={row['max_absolute_delta']:.6e}"
            for row in violating_rows
        )
        raise RuntimeError(
            "Frozen shared parameters changed during adaptation.\n"
            f"Tolerance={tolerance:.3e}\n{details}"
        )


def verify_particular_parameters_changed(
    audit_rows: list[dict],
    tolerance: float,
) -> None:
    """Verify that all selected particular layers changed."""
    particular_rows = {
        row["layer_name"]: row
        for row in audit_rows
        if row["parameter_group"] == "particular"
    }

    missing = (
        set(PARTICULAR_LAYER_NAMES)
        - set(particular_rows)
    )
    if missing:
        raise RuntimeError(
            "Particular layers missing from audit: "
            f"{sorted(missing)}"
        )

    unchanged = [
        layer_name
        for layer_name, row in particular_rows.items()
        if row["max_absolute_delta"] <= tolerance
    ]
    if unchanged:
        raise RuntimeError(
            "Particular layers did not change: "
            f"{sorted(unchanged)}"
        )


def summarise_parameter_changes(
    audit_rows: list[dict],
) -> dict[str, float]:
    """Return experiment-level shared/particular change metrics."""
    shared_rows = [
        row for row in audit_rows
        if row["parameter_group"] == "shared"
    ]
    particular_rows = [
        row for row in audit_rows
        if row["parameter_group"] == "particular"
    ]

    return {
        "shared_total_delta_l2": float(
            np.sqrt(sum(row["delta_l2"] ** 2 for row in shared_rows))
        ),
        "particular_total_delta_l2": float(
            np.sqrt(sum(row["delta_l2"] ** 2 for row in particular_rows))
        ),
        "maximum_shared_absolute_delta": float(
            max(
                (row["max_absolute_delta"] for row in shared_rows),
                default=0.0,
            )
        ),
        "maximum_particular_absolute_delta": float(
            max(
                (row["max_absolute_delta"] for row in particular_rows),
                default=0.0,
            )
        ),
        "mean_particular_relative_delta_l2": float(
            np.mean([
                row["relative_delta_l2"]
                for row in particular_rows
            ])
            if particular_rows
            else 0.0
        ),
    }

def set_particular_only_trainable(
    model: tf.keras.Model,
) -> None:
    particular = set(
        PARTICULAR_LAYER_NAMES
    )

    for layer in model.layers:
        layer.trainable = (
            layer.name in particular
        )

    if not model.trainable_variables:
        raise RuntimeError(
            "No particular variables became trainable."
        )


def evaluate_dataset(
    model: tf.keras.Model,
    dataset,
) -> float:
    total_errors = 0
    total_bits = 0

    for bits, channels, noise_std in (
        iter_fixed_batches(
            dataset=dataset,
            epoch=0,
            shuffle_seed=0,
        )
    ):
        labels = tf.cast(
            bits,
            tf.float32,
        )

        _, probabilities = model(
            [
                bits,
                channels,
                noise_std,
            ],
            training=False,
        )

        predictions = tf.cast(
            probabilities >= 0.5,
            tf.float32,
        )

        total_errors += int(
            tf.reduce_sum(
                tf.cast(
                    predictions != labels,
                    tf.int64,
                )
            ).numpy()
        )

        total_bits += int(
            tf.size(labels).numpy()
        )

    if total_bits <= 0:
        raise ValueError(
            "Evaluation dataset is empty."
        )

    return total_errors / total_bits


def evaluate_support_loss(
    model: tf.keras.Model,
    dataset,
) -> float:
    losses = []

    for bits, channels, noise_std in (
        iter_fixed_batches(
            dataset=dataset,
            epoch=0,
            shuffle_seed=0,
        )
    ):
        labels = tf.cast(
            bits,
            tf.float32,
        )

        logits, _ = model(
            [
                bits,
                channels,
                noise_std,
            ],
            training=False,
        )

        loss = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(
                labels=labels,
                logits=logits,
            )
        )

        losses.append(
            float(loss.numpy())
        )

    if not losses:
        raise ValueError(
            "Support dataset is empty."
        )

    return float(
        np.mean(losses)
    )


def adapt_particular_parameters(
    model: tf.keras.Model,
    dataset,
    epochs: int,
    learning_rate: float,
    seed: int,
) -> list[dict]:
    """
    New-environment particular-only adaptation.

    Shared w* remains fixed.
    Only v_new is updated using target support data.
    """
    set_all_seeds(seed)

    set_particular_only_trainable(
        model
    )

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=learning_rate
    )

    history = []

    for epoch in range(epochs):
        epoch_losses = []
        epoch_bers = []

        for bits, channels, noise_std in (
            iter_fixed_batches(
                dataset=dataset,
                epoch=epoch,
                shuffle_seed=(
                    seed + 1000
                ),
            )
        ):
            labels = tf.cast(
                bits,
                tf.float32,
            )

            with tf.GradientTape() as tape:
                logits, probabilities = model(
                    [
                        bits,
                        channels,
                        noise_std,
                    ],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        labels=labels,
                        logits=logits,
                    )
                )

            gradients = tape.gradient(
                loss,
                model.trainable_variables,
            )

            gradient_variable_pairs = [
                (gradient, variable)
                for gradient, variable
                in zip(
                    gradients,
                    model.trainable_variables,
                )
                if gradient is not None
            ]

            if not gradient_variable_pairs:
                raise RuntimeError(
                    "No gradients were produced "
                    "for particular parameters."
                )

            optimizer.apply_gradients(
                gradient_variable_pairs
            )

            predictions = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predictions != labels,
                    tf.float32,
                )
            )

            epoch_losses.append(
                float(loss.numpy())
            )

            epoch_bers.append(
                float(ber.numpy())
            )

        history.append({
            "epoch": epoch + 1,
            "loss": float(
                np.mean(epoch_losses)
            ),
            "ber": float(
                np.mean(epoch_bers)
            ),
        })

    return history


def parse_arguments():
    config = Task6Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 6.4 unseen-PDP "
            "particular-only adaptation."
        )
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(config.seeds),
    )

    parser.add_argument(
        "--adaptation-blocks",
        nargs="+",
        type=int,
        default=[
            512,
            1024,
            2048,
            4096,
        ],
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=1e-4,
    )

    parser.add_argument(
        "--query-blocks",
        type=int,
        default=8192,
    )

    parser.add_argument(
        "--training-root",
        type=Path,
        default=(
            config.output_root
            / "iadmm_training_revised"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / "unseen_adaptation_revised"
        ),
    )

    parser.add_argument(
        "--shared-change-tolerance",
        type=float,
        default=1e-10,
    )

    parser.add_argument(
        "--particular-change-tolerance",
        type=float,
        default=1e-12,
    )

    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    config = Task6Config()
    pdps = get_known_pdps()

    rows = []
    parameter_audit_rows = []

    args.output_root.mkdir(parents=True, exist_ok=True)

    for seed in args.seeds:
        training_directory = (
            args.training_root
            / f"seed_{seed}"
        )

        if not training_directory.exists():
            raise FileNotFoundError(
                "Missing Task 6.3 result: "
                f"{training_directory}"
            )

        w_star = load_snapshot_npz(
            training_directory
            / "global_shared_w.npz"
        )

        historical_particular = {
            pdp_id: load_snapshot_npz(
                training_directory
                / "particular"
                / f"PDP{pdp_id}_v_i.npz"
            )
            for pdp_id
            in config.train_pdps
        }

        historical_mean = (
            average_snapshots(
                list(
                    historical_particular.values()
                )
            )
        )

        for target_pdp_id in (
            config.unseen_pdps
        ):
            target_pdp = pdps[
                target_pdp_id
            ]

            # Same random support sequence for all
            # support-set sizes.
            support_seed = (
                seed
                + 100000
                + target_pdp_id * 1000
            )

            query_seed = (
                seed
                + 200000
                + target_pdp_id * 1000
            )

            for block_count in (
                args.adaptation_blocks
            ):
                support_dataset = (
                    make_fixed_adaptation_dataset(
                        pdp_target=target_pdp,
                        pdp_id=target_pdp_id,
                        num_blocks=block_count,
                        ebno_linear=(
                            config.ebno_linear
                        ),
                        seed=support_seed,
                    )
                )

                query_dataset = (
                    make_fixed_adaptation_dataset(
                        pdp_target=target_pdp,
                        pdp_id=target_pdp_id,
                        num_blocks=(
                            args.query_blocks
                        ),
                        ebno_linear=(
                            config.ebno_linear
                        ),
                        seed=query_seed,
                    )
                )

                # --------------------------------------------
                # Select v initialization using support only.
                # Query data is never used for selection.
                # --------------------------------------------

                candidate_snapshots = {
                    "historical_mean":
                        historical_mean,
                }

                candidate_snapshots.update({
                    f"PDP{pdp_id}":
                        snapshot

                    for pdp_id, snapshot
                    in historical_particular.items()
                })

                candidate_losses = {}

                for (
                    candidate_name,
                    candidate_snapshot,
                ) in candidate_snapshots.items():
                    tf.keras.backend.clear_session()
                    gc.collect()
                    set_all_seeds(seed)

                    selection_model = (
                        end_to_end()
                    )

                    validate_partition(
                        selection_model
                    )

                    restore_named_layers(
                        selection_model,
                        w_star,
                    )

                    restore_named_layers(
                        selection_model,
                        candidate_snapshot,
                    )

                    candidate_losses[
                        candidate_name
                    ] = evaluate_support_loss(
                        selection_model,
                        support_dataset,
                    )

                # Use the same deterministic historical-mean particular
                # initialisation for every unseen PDP.
                best_initialisation_name = "historical_mean"
                v_initial = historical_mean

                # --------------------------------------------
                # Build final target model
                # --------------------------------------------

                tf.keras.backend.clear_session()
                gc.collect()
                set_all_seeds(seed)

                model = end_to_end()

                validate_partition(
                    model
                )

                restore_named_layers(
                    model,
                    w_star,
                )

                restore_named_layers(
                    model,
                    v_initial,
                )

                before_adaptation_snapshot = (
                    snapshot_all_layer_weights(
                        model
                    )
                )

                # Equation (7) before adaptation
                zero_shot_ber = (
                    evaluate_dataset(
                        model,
                        query_dataset,
                    )
                )

                training_history = (
                    adapt_particular_parameters(
                        model=model,
                        dataset=support_dataset,
                        epochs=args.epochs,
                        learning_rate=(
                            args.learning_rate
                        ),
                        seed=support_seed,
                    )
                )

                # Equation (7) after obtaining v_new
                adapted_ber = (
                    evaluate_dataset(
                        model,
                        query_dataset,
                    )
                )

                experiment_audit_rows = (
                    calculate_parameter_change_audit(
                        model=model,
                        before_snapshot=(
                            before_adaptation_snapshot
                        ),
                        seed=seed,
                        target_pdp=target_pdp_id,
                        adaptation_blocks=block_count,
                        method="particular_only_tl",
                    )
                )

                verify_shared_parameters_unchanged(
                    experiment_audit_rows,
                    args.shared_change_tolerance,
                )

                verify_particular_parameters_changed(
                    experiment_audit_rows,
                    args.particular_change_tolerance,
                )

                parameter_change_summary = (
                    summarise_parameter_changes(
                        experiment_audit_rows
                    )
                )

                parameter_audit_rows.extend(
                    experiment_audit_rows
                )

                row = {
                    "seed": seed,

                    "target_pdp":
                        target_pdp_id,

                    "adaptation_blocks":
                        block_count,

                    "adaptation_epochs":
                        args.epochs,

                    "learning_rate":
                        args.learning_rate,

                    "method":
                        "particular_only_tl",

                    "historical_training":
                        (
                            "Algorithm 1 iADMM "
                            "equations (8)-(10)"
                        ),

                    "new_environment_objective":
                        (
                            "fixed shared w_star "
                            "plus target-specific "
                            "particular adaptation"
                        ),

                    "inference":
                        "equation (7)",

                    "particular_initialisation":
                        best_initialisation_name,

                    "initialisation_support_loss":
                        candidate_losses[
                            best_initialisation_name
                        ],

                    "zero_shot_ber":
                        zero_shot_ber,

                    "adapted_ber":
                        adapted_ber,

                    "absolute_improvement":
                        zero_shot_ber
                        - adapted_ber,

                    "relative_improvement":
                        (
                            zero_shot_ber
                            - adapted_ber
                        ) / zero_shot_ber
                        if zero_shot_ber > 0
                        else 0.0,

                    "final_support_loss":
                        training_history[
                            -1
                        ]["loss"],

                    "final_support_ber":
                        training_history[
                            -1
                        ]["ber"],

                    "shared_total_delta_l2":
                        parameter_change_summary[
                            "shared_total_delta_l2"
                        ],

                    "particular_total_delta_l2":
                        parameter_change_summary[
                            "particular_total_delta_l2"
                        ],

                    "maximum_shared_absolute_delta":
                        parameter_change_summary[
                            "maximum_shared_absolute_delta"
                        ],

                    "maximum_particular_absolute_delta":
                        parameter_change_summary[
                            "maximum_particular_absolute_delta"
                        ],

                    "mean_particular_relative_delta_l2":
                        parameter_change_summary[
                            "mean_particular_relative_delta_l2"
                        ],

                    "shared_change_verified":
                        int(
                            parameter_change_summary[
                                "maximum_shared_absolute_delta"
                            ]
                            <= args.shared_change_tolerance
                        ),
                }

                rows.append(row)

                result_directory = (
                    args.output_root
                    / f"PDP{target_pdp_id}"
                    / f"seed_{seed}"
                    / f"blocks_{block_count}"
                )

                result_directory.mkdir(
                    parents=True,
                    exist_ok=True,
                )

                (
                    result_directory
                    / "training_history.json"
                ).write_text(
                    json.dumps(
                        training_history,
                        indent=2,
                    ),
                    encoding="utf-8",
                )

                write_csv(
                    result_directory
                    / "parameter_change_audit.csv",
                    experiment_audit_rows,
                )

                (
                    result_directory
                    / "result.json"
                ).write_text(
                    json.dumps(
                        row,
                        indent=2,
                    ),
                    encoding="utf-8",
                )

                write_csv(
                    args.output_root
                    / "unseen_adaptation_raw_partial.csv",
                    rows,
                )

                write_csv(
                    args.output_root
                    / "parameter_change_audit_partial.csv",
                    parameter_audit_rows,
                )

                print(
                    f"PDP{target_pdp_id} | "
                    f"seed={seed} | "
                    f"blocks={block_count} | "
                    f"init={best_initialisation_name} | "
                    f"BER {zero_shot_ber:.6f} "
                    f"-> {adapted_ber:.6f} | "
                    f"shared ΔL2="
                    f"{parameter_change_summary['shared_total_delta_l2']:.3e} | "
                    f"particular ΔL2="
                    f"{parameter_change_summary['particular_total_delta_l2']:.3e}"
                )

    write_csv(
        args.output_root
        / "unseen_adaptation_raw.csv",
        rows,
    )

    write_csv(
        args.output_root
        / "parameter_change_audit.csv",
        parameter_audit_rows,
    )

    print("\nTask 6.4 completed.")
    print(
        "BER results:\n"
        f"{args.output_root / 'unseen_adaptation_raw.csv'}"
    )
    print(
        "Parameter-change audit:\n"
        f"{args.output_root / 'parameter_change_audit.csv'}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())