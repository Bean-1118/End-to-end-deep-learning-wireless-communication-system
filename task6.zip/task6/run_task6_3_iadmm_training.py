from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps
from src.task4.checkpoint_utils import restore_task2_checkpoint
from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
)
from src.task6.iadmm_state import (
    copy_iadmm_state,
    initialise_iadmm_state,
    save_snapshot_npz,
)
from src.task6.iadmm_trainer import IADMMTrainer
from src.task6.task6_config import Task6Config
from src.task6.task6_evaluation import (
    evaluate_historical_environments,
)
from src.task6.task6_parameter_groups import (
    PARTICULAR_LAYER_NAMES,
    partition_audit,
    shared_layer_names,
    validate_partition,
)


def write_csv(path: Path, rows) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def next_batch(
    pdp_id,
    iterators,
    datasets,
    iteration,
    seed,
):
    try:
        return next(iterators[pdp_id])
    except StopIteration:
        iterators[pdp_id] = iter(
            iter_fixed_batches(
                dataset=datasets[pdp_id],
                epoch=iteration + 1,
                shuffle_seed=seed + 10000 + pdp_id,
            )
        )
        return next(iterators[pdp_id])


def parse_arguments():
    config = Task6Config()
    parser = argparse.ArgumentParser(
        description=(
            "Task 6.3 revised stochastic mini-batch Algorithm-1 "
            "iADMM training."
        )
    )
    parser.add_argument(
        "--rho",
        type=float,
        default=config.default_rho,
    )
    parser.add_argument(
        "--sigma",
        type=float,
        default=config.default_sigma,
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=config.iadmm_iterations,
    )
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(config.seeds),
    )
    parser.add_argument(
        "--blocks-per-pdp",
        type=int,
        default=config.train_blocks_per_pdp,
    )
    parser.add_argument(
        "--validation-blocks-per-pdp",
        type=int,
        default=config.validation_blocks_per_pdp,
    )
    parser.add_argument(
        "--validation-interval",
        type=int,
        default=config.validation_interval,
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=config.output_root / "iadmm_training_revised",
    )
    return parser.parse_args()


def validate_arguments(args) -> None:
    if args.rho <= 0:
        raise ValueError("--rho must be positive.")
    if args.sigma <= 0:
        raise ValueError("--sigma must be positive.")
    if args.sigma >= args.rho:
        raise ValueError(
            "For the current experiment, require sigma < rho."
        )
    if args.iterations <= 0:
        raise ValueError("--iterations must be positive.")
    if args.validation_interval <= 0:
        raise ValueError("--validation-interval must be positive.")


def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task6Config()
    pdps = get_known_pdps()
    root = args.output_root

    for seed in args.seeds:
        print("\n" + "=" * 80)
        print(
            f"Task 6.3 revised | seed={seed} | "
            f"rho={args.rho} | sigma={args.sigma}"
        )
        print("=" * 80)

        tf.keras.backend.clear_session()
        gc.collect()
        set_all_seeds(seed)

        model = end_to_end()
        validate_partition(model)
        audit = partition_audit(model)

        restored_checkpoint = restore_task2_checkpoint(
            model=model,
            checkpoint_dir=(
                config.checkpoint_root
                / "model_trained_on_PDP0"
            ),
        )

        shared_names = shared_layer_names(model)
        state = initialise_iadmm_state(
            model=model,
            train_pdp_ids=config.train_pdps,
            shared_layer_names=shared_names,
            particular_layer_names=PARTICULAR_LAYER_NAMES,
        )

        trainer = IADMMTrainer(
            model=model,
            state=state,
            train_pdp_ids=config.train_pdps,
            shared_layer_names=shared_names,
            particular_layer_names=PARTICULAR_LAYER_NAMES,
            rho=args.rho,
            sigma=args.sigma,
        )

        training_datasets = {
            pdp_id: make_fixed_adaptation_dataset(
                pdp_target=pdps[pdp_id],
                pdp_id=pdp_id,
                num_blocks=args.blocks_per_pdp,
                ebno_linear=config.ebno_linear,
                seed=seed + pdp_id * 1000,
            )
            for pdp_id in config.train_pdps
        }
        validation_datasets = {
            pdp_id: make_fixed_adaptation_dataset(
                pdp_target=pdps[pdp_id],
                pdp_id=pdp_id,
                num_blocks=args.validation_blocks_per_pdp,
                ebno_linear=config.ebno_linear,
                seed=seed + 500000 + pdp_id * 1000,
            )
            for pdp_id in config.train_pdps
        }

        iterators = {
            pdp_id: iter(
                iter_fixed_batches(
                    dataset=dataset,
                    epoch=0,
                    shuffle_seed=seed + 10000 + pdp_id,
                )
            )
            for pdp_id, dataset in training_datasets.items()
        }

        history = []
        best_state = None
        best_iteration = None
        best_key = None

        for iteration in range(args.iterations):
            batch_by_pdp = {
                pdp_id: next_batch(
                    pdp_id,
                    iterators,
                    training_datasets,
                    iteration,
                    seed,
                )
                for pdp_id in config.train_pdps
            }

            metrics = trainer.step(
                batch_by_pdp=batch_by_pdp,
                iteration=iteration,
            )

            numeric_values = [
                metrics["mean_loss"],
                metrics["mean_ber"],
                metrics["primal_residual"],
                metrics["dual_residual"],
                metrics["relative_primal_residual"],
                metrics["relative_dual_residual"],
                metrics["mean_shared_gradient_l2"],
                metrics["mean_particular_gradient_l2"],
                metrics["mean_local_shared_update_l2"],
                metrics["mean_particular_update_l2"],
            ]
            if not np.all(np.isfinite(numeric_values)):
                raise FloatingPointError(
                    "iADMM diverged to NaN/Inf."
                )

            flat_row = {
                "seed": seed,
                "iteration": iteration + 1,
                "rho": args.rho,
                "sigma": args.sigma,
                "mean_training_loss": metrics["mean_loss"],
                "mean_training_ber": metrics["mean_ber"],
                "maximum_training_ber": metrics["maximum_ber"],
                "primal_residual": metrics["primal_residual"],
                "dual_residual": metrics["dual_residual"],
                "relative_primal_residual": metrics[
                    "relative_primal_residual"
                ],
                "relative_dual_residual": metrics[
                    "relative_dual_residual"
                ],
                "mean_shared_gradient_l2": metrics[
                    "mean_shared_gradient_l2"
                ],
                "mean_particular_gradient_l2": metrics[
                    "mean_particular_gradient_l2"
                ],
                "mean_local_shared_update_l2": metrics[
                    "mean_local_shared_update_l2"
                ],
                "mean_particular_update_l2": metrics[
                    "mean_particular_update_l2"
                ],
            }

            for pdp_id, result in metrics["environment_results"].items():
                flat_row[f"PDP{pdp_id}_training_loss"] = result["loss"]
                flat_row[f"PDP{pdp_id}_training_ber"] = result["ber"]

            should_validate = (
                iteration == 0
                or (iteration + 1) % args.validation_interval == 0
                or iteration + 1 == args.iterations
            )

            if should_validate:
                validation_by_pdp = (
                    evaluate_historical_environments(
                        model=model,
                        datasets_by_pdp=validation_datasets,
                        shared_weights=trainer.state.global_shared,
                        particular_by_pdp=trainer.state.particular,
                    )
                )
                values = list(validation_by_pdp.values())
                mean_validation_ber = float(np.mean(values))
                maximum_validation_ber = float(np.max(values))

                flat_row["mean_validation_ber"] = mean_validation_ber
                flat_row["maximum_validation_ber"] = maximum_validation_ber
                for pdp_id, ber in validation_by_pdp.items():
                    flat_row[f"PDP{pdp_id}_validation_ber"] = ber

                candidate_key = (
                    mean_validation_ber,
                    maximum_validation_ber,
                    metrics["relative_primal_residual"],
                    metrics["relative_dual_residual"],
                )

                if best_key is None or candidate_key < best_key:
                    best_key = candidate_key
                    best_iteration = iteration + 1
                    best_state = copy_iadmm_state(trainer.state)

                print(
                    f"iter={iteration + 1}/{args.iterations} | "
                    f"train={metrics['mean_ber']:.6f} | "
                    f"val={mean_validation_ber:.6f} | "
                    f"max={maximum_validation_ber:.6f} | "
                    f"r_rel={metrics['relative_primal_residual']:.3e} | "
                    f"s_rel={metrics['relative_dual_residual']:.3e}"
                )

            history.append(flat_row)

            seed_directory = root / f"seed_{seed}"
            if (iteration + 1) % 25 == 0:
                write_csv(
                    seed_directory
                    / "convergence_history_partial.csv",
                    history,
                )

        if best_state is None:
            raise RuntimeError(
                "No valid validation state was recorded."
            )

        trainer.state = best_state
        seed_directory = root / f"seed_{seed}"

        save_snapshot_npz(
            seed_directory / "global_shared_w.npz",
            trainer.state.global_shared,
        )
        for pdp_id in config.train_pdps:
            save_snapshot_npz(
                seed_directory
                / "local_shared"
                / f"PDP{pdp_id}_w_i.npz",
                trainer.state.local_shared[pdp_id],
            )
            save_snapshot_npz(
                seed_directory
                / "particular"
                / f"PDP{pdp_id}_v_i.npz",
                trainer.state.particular[pdp_id],
            )
            save_snapshot_npz(
                seed_directory
                / "dual"
                / f"PDP{pdp_id}_pi_i.npz",
                trainer.state.dual[pdp_id],
            )

        write_csv(
            seed_directory / "convergence_history.csv",
            history,
        )

        (
            seed_directory / "metadata.json"
        ).write_text(
            json.dumps(
                {
                    "seed": seed,
                    "rho": args.rho,
                    "sigma": args.sigma,
                    "iterations_requested": args.iterations,
                    "best_iteration": best_iteration,
                    "best_mean_validation_ber": best_key[0],
                    "best_maximum_validation_ber": best_key[1],
                    "best_relative_primal_residual": best_key[2],
                    "best_relative_dual_residual": best_key[3],
                    "validation_interval": args.validation_interval,
                    "validation_blocks_per_pdp": (
                        args.validation_blocks_per_pdp
                    ),
                    "historical_pdps": list(config.train_pdps),
                    "unseen_pdps": list(config.unseen_pdps),
                    "parameter_partition": audit,
                    "restored_checkpoint": str(restored_checkpoint),
                    "implementation_type": (
                        "stochastic mini-batch iADMM; "
                        "not strict full-objective Algorithm 1"
                    ),
                    "best_state_selection": (
                        "mean validation BER, worst-PDP validation BER, "
                        "relative primal residual, relative dual residual"
                    ),
                },
                indent=2,
            ),
            encoding="utf-8",
        )

        print(
            "Saved best state: "
            f"iteration={best_iteration}, "
            f"mean validation BER={best_key[0]:.6f}"
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
