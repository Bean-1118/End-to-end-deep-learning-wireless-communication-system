from __future__ import annotations

from typing import Dict

import tensorflow as tf

from src.task4.fixed_adaptation import (
    iter_fixed_batches,
)
from src.task6.iadmm_state import (
    LayerSnapshot,
    restore_named_layers,
)


def install_environment_model(
    model: tf.keras.Model,
    shared_weights: LayerSnapshot,
    particular_weights: LayerSnapshot,
) -> None:
    """
    Install phi(w, v_i) for evaluation.
    """
    restore_named_layers(
        model,
        shared_weights,
    )
    restore_named_layers(
        model,
        particular_weights,
    )


def evaluate_fixed_dataset(
    model: tf.keras.Model,
    dataset,
    shared_weights: LayerSnapshot,
    particular_weights: LayerSnapshot,
) -> float:
    install_environment_model(
        model=model,
        shared_weights=shared_weights,
        particular_weights=particular_weights,
    )

    total_errors = 0
    total_bits = 0

    for (
        bits,
        channels,
        noise_std,
    ) in iter_fixed_batches(
        dataset=dataset,
        epoch=0,
        shuffle_seed=0,
    ):
        labels = tf.cast(
            bits,
            tf.float32,
        )

        _, probabilities = model(
            [
                bits,
                channels,
                noise_std,
            ],
            training=False,
        )

        predictions = tf.cast(
            probabilities >= 0.5,
            tf.float32,
        )

        total_errors += int(
            tf.reduce_sum(
                tf.cast(
                    predictions != labels,
                    tf.int64,
                )
            ).numpy()
        )

        total_bits += int(
            tf.size(labels).numpy()
        )

    if total_bits <= 0:
        raise ValueError(
            "Evaluation dataset is empty."
        )

    return (
        total_errors
        / total_bits
    )


def evaluate_historical_environments(
    model: tf.keras.Model,
    datasets_by_pdp: Dict[int, object],
    shared_weights: LayerSnapshot,
    particular_by_pdp: Dict[
        int,
        LayerSnapshot,
    ],
) -> Dict[int, float]:
    if set(datasets_by_pdp) != set(
        particular_by_pdp
    ):
        raise ValueError(
            "Historical datasets and particular snapshots "
            "do not contain the same PDP IDs."
        )

    results: Dict[int, float] = {}

    for pdp_id in sorted(
        datasets_by_pdp
    ):
        results[pdp_id] = (
            evaluate_fixed_dataset(
                model=model,
                dataset=(
                    datasets_by_pdp[
                        pdp_id
                    ]
                ),
                shared_weights=(
                    shared_weights
                ),
                particular_weights=(
                    particular_by_pdp[
                        pdp_id
                    ]
                ),
            )
        )

    return results
