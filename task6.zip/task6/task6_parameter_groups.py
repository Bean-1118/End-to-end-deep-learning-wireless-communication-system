from __future__ import annotations

from typing import Dict, Tuple

import tensorflow as tf


# Auxiliary particular layers remain in the shared/fixed group.
PARTICULAR_LAYER_NAMES: Tuple[str, ...] = (
    "decoder_conv_1",
    "decoder_res1_input",
    "decoder_res1_conv2",
)


def parameter_layer_names(
    model: tf.keras.Model,
) -> Tuple[str, ...]:
    """
    Layers owning trainable parameter tensors.

    Algorithm 1 optimises only trainable model parameters. Layers containing
    only non-trainable state are excluded.
    """
    return tuple(
        layer.name
        for layer in model.layers
        if layer.trainable_weights
    )


def shared_layer_names(
    model: tf.keras.Model,
) -> Tuple[str, ...]:
    all_parameter_layers = (
        parameter_layer_names(model)
    )
    particular = set(
        PARTICULAR_LAYER_NAMES
    )

    missing = particular.difference(
        all_parameter_layers
    )

    if missing:
        raise ValueError(
            "Particular layers missing from model "
            "trainable parameters: "
            f"{sorted(missing)}"
        )

    return tuple(
        layer_name
        for layer_name
        in all_parameter_layers
        if layer_name not in particular
    )


def count_parameters_for_layers(
    model: tf.keras.Model,
    layer_names: Tuple[str, ...],
) -> int:
    return int(
        sum(
            tf.size(variable).numpy()
            for layer_name
            in layer_names
            for variable
            in model.get_layer(
                layer_name
            ).trainable_weights
        )
    )


def validate_partition(
    model: tf.keras.Model,
) -> None:
    all_layers = set(
        parameter_layer_names(model)
    )
    shared = set(
        shared_layer_names(model)
    )
    particular = set(
        PARTICULAR_LAYER_NAMES
    )

    overlap = shared.intersection(
        particular
    )

    if overlap:
        raise ValueError(
            "Shared/particular overlap detected: "
            f"{sorted(overlap)}"
        )

    union = shared.union(
        particular
    )

    if union != all_layers:
        raise ValueError(
            "Shared/particular partition is incomplete. "
            f"Missing={sorted(all_layers - union)}, "
            f"extra={sorted(union - all_layers)}"
        )

    # Algorithm 1 equations are written for optimisation parameters w and v.
    # If a partitioned layer contains additional non-trainable state (e.g.
    # BatchNorm moving statistics), that state must be handled explicitly.
    non_trainable_parameter_layers = {
        layer.name: [
            variable.name
            for variable
            in layer.non_trainable_weights
        ]
        for layer in model.layers
        if (
            layer.name in union
            and layer.non_trainable_weights
        )
    }

    if non_trainable_parameter_layers:
        raise ValueError(
            "Algorithm-1 partition includes layers "
            "with non-trainable state. "
            "Handle these states explicitly before training: "
            f"{non_trainable_parameter_layers}"
        )


def partition_audit(
    model: tf.keras.Model,
) -> Dict[str, object]:
    validate_partition(model)

    shared_names = (
        shared_layer_names(model)
    )

    shared_parameters = (
        count_parameters_for_layers(
            model,
            shared_names,
        )
    )

    particular_parameters = (
        count_parameters_for_layers(
            model,
            PARTICULAR_LAYER_NAMES,
        )
    )

    total_partitioned = (
        shared_parameters
        + particular_parameters
    )

    return {
        "shared_layers":
            list(shared_names),
        "particular_layers":
            list(
                PARTICULAR_LAYER_NAMES
            ),
        "shared_parameters":
            shared_parameters,
        "particular_parameters":
            particular_parameters,
        "total_parameters":
            total_partitioned,
        "keras_model_count_params":
            int(
                model.count_params()
            ),
        "shared_percentage":
            (
                100.0
                * shared_parameters
                / total_partitioned
            ),
        "particular_percentage":
            (
                100.0
                * particular_parameters
                / total_partitioned
            ),
        "partition_source":
            "Task 5.4 fixed/particular audit",
        "auxiliary_particular_policy":
            "fixed/shared as requested by supervisor",
    }
