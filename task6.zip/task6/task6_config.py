from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Tuple


PROJECT_ROOT = (
    Path(__file__)
    .resolve()
    .parents[2]
)


@dataclass(frozen=True)
class Task6Config:
    train_pdps: Tuple[int, ...] = (
        0, 1, 2, 3, 4, 5
    )
    unseen_pdps: Tuple[int, ...] = (
        6, 7
    )
    seeds: Tuple[int, ...] = (
        2026, 2027, 2028
    )

    # Execution defaults only.
    # Rho and sigma values depend on gradients evaluated at (w_i^l, v_i^l)
    # and on using grad f_i without a 1/N factor. Values tuned under a
    # different update rule are not valid for this implementation.
    iadmm_iterations: int = 2000
    train_blocks_per_pdp: int = 4096
    validation_blocks_per_pdp: int = 4096
    validation_interval: int = 25

    ebno_linear: float = 20.0
    test_batches: int = 100

    # Placeholder defaults; tune rho and sigma with Task 6.2 for this implementation.
    default_rho: float = 100.0
    default_sigma: float = 10.0

    checkpoint_root: Path = (
        PROJECT_ROOT
        / "outputs"
        / "checkpoints"
    )

    output_root: Path = (
        PROJECT_ROOT
        / "outputs"
        / "task6"
    )
