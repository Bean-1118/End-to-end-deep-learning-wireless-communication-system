from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path
from typing import Iterable, Mapping

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps

from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
)

from src.task6.iadmm_state import (
    LayerSnapshot,
    average_snapshots,
    load_snapshot_npz,
    restore_named_layers,
    snapshot_named_layers,
)

from src.task6.task6_config import Task6Config

from src.task6.task6_parameter_groups import (
    PARTICULAR_LAYER_NAMES,
    shared_layer_names,
    validate_partition,
)


EPSILON = 1e-12

STRATEGIES = (
    "no_adaptation",
    "particular_only_tl",
    "full_finetune",
)


# ============================================================
# Generic helpers
# ============================================================

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return

    path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames: list[str] = []

    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def population_std(values: Iterable[float]) -> float:
    array = np.asarray(
        list(values),
        dtype=np.float64,
    )

    if array.size == 0:
        return float("nan")

    return float(np.std(array, ddof=0))


def set_deterministic_execution(seed: int) -> None:
    """
    Configure deterministic execution where supported.
    """
    set_all_seeds(seed)

    try:
        tf.config.experimental.enable_op_determinism()
    except Exception:
        pass


# ============================================================
# Evaluation
# ============================================================

def evaluate_ber(
    model: tf.keras.Model,
    dataset,
) -> float:
    total_errors = 0
    total_bits = 0

    for bits, channels, noise_std in iter_fixed_batches(
        dataset=dataset,
        epoch=0,
        shuffle_seed=0,
    ):
        labels = tf.cast(bits, tf.float32)

        _, probabilities = model(
            [bits, channels, noise_std],
            training=False,
        )

        predictions = tf.cast(
            probabilities >= 0.5,
            tf.float32,
        )

        total_errors += int(
            tf.reduce_sum(
                tf.cast(
                    predictions != labels,
                    tf.int64,
                )
            ).numpy()
        )

        total_bits += int(tf.size(labels).numpy())

    if total_bits <= 0:
        raise ValueError(
            "Evaluation dataset is empty."
        )

    return total_errors / total_bits


def evaluate_loss(
    model: tf.keras.Model,
    dataset,
) -> float:
    losses: list[float] = []

    for bits, channels, noise_std in iter_fixed_batches(
        dataset=dataset,
        epoch=0,
        shuffle_seed=0,
    ):
        labels = tf.cast(bits, tf.float32)

        logits, _ = model(
            [bits, channels, noise_std],
            training=False,
        )

        loss = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(
                labels=labels,
                logits=logits,
            )
        )

        losses.append(float(loss.numpy()))

    if not losses:
        raise ValueError(
            "Dataset is empty."
        )

    return float(np.mean(losses))


def repeatability_check(
    model: tf.keras.Model,
    dataset,
    repeats: int,
) -> tuple[list[float], float]:
    """
    Evaluate BER repeatedly on the same model and dataset.
    Return all values and their range.
    """
    values = [
        evaluate_ber(model, dataset)
        for _ in range(repeats)
    ]

    return values, float(max(values) - min(values))


# ============================================================
# Strategy control
# ============================================================

def set_strategy_trainable(
    model: tf.keras.Model,
    strategy: str,
) -> None:
    particular = set(
        PARTICULAR_LAYER_NAMES
    )

    if strategy == "no_adaptation":
        for layer in model.layers:
            layer.trainable = False

    elif strategy == "particular_only_tl":
        for layer in model.layers:
            layer.trainable = (
                layer.name in particular
            )

    elif strategy == "full_finetune":
        for layer in model.layers:
            layer.trainable = True

    else:
        raise ValueError(
            f"Unknown strategy: {strategy}"
        )


def count_trainable_parameters(
    model: tf.keras.Model,
) -> int:
    return int(
        sum(
            tf.size(variable).numpy()
            for variable
            in model.trainable_variables
        )
    )


def adapt_model(
    model: tf.keras.Model,
    dataset,
    strategy: str,
    epochs: int,
    learning_rate: float,
    seed: int,
) -> list[dict]:
    set_deterministic_execution(seed)

    set_strategy_trainable(
        model=model,
        strategy=strategy,
    )

    if strategy == "no_adaptation":
        return []

    trainable_variables = list(
        model.trainable_variables
    )

    if not trainable_variables:
        raise RuntimeError(
            f"No trainable variables for {strategy}."
        )

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=learning_rate
    )

    history: list[dict] = []

    for epoch in range(epochs):
        epoch_losses: list[float] = []
        epoch_bers: list[float] = []

        for bits, channels, noise_std in iter_fixed_batches(
            dataset=dataset,
            epoch=epoch,
            shuffle_seed=seed + 1000,
        ):
            labels = tf.cast(bits, tf.float32)

            with tf.GradientTape() as tape:
                logits, probabilities = model(
                    [bits, channels, noise_std],
                    training=True,
                )

                loss = tf.reduce_mean(
                    tf.nn.sigmoid_cross_entropy_with_logits(
                        labels=labels,
                        logits=logits,
                    )
                )

            trainable_variables = list(
                model.trainable_variables
            )

            gradients = tape.gradient(
                loss,
                trainable_variables,
            )

            pairs = [
                (gradient, variable)
                for gradient, variable
                in zip(
                    gradients,
                    trainable_variables,
                )
                if gradient is not None
            ]

            if not pairs:
                raise RuntimeError(
                    f"No gradients were produced for {strategy}."
                )

            optimizer.apply_gradients(pairs)

            predictions = tf.cast(
                probabilities >= 0.5,
                tf.float32,
            )

            ber = tf.reduce_mean(
                tf.cast(
                    predictions != labels,
                    tf.float32,
                )
            )

            epoch_losses.append(
                float(loss.numpy())
            )

            epoch_bers.append(
                float(ber.numpy())
            )

        if not epoch_losses:
            raise RuntimeError(
                "No adaptation batches were generated."
            )

        history.append({
            "epoch":
                epoch + 1,
            "loss":
                float(np.mean(epoch_losses)),
            "ber":
                float(np.mean(epoch_bers)),
        })

    return history


# ============================================================
# Initialisation selection
# ============================================================

def choose_particular_initialisation(
    w_star: LayerSnapshot,
    historical_particular:
        Mapping[int, LayerSnapshot],
    support_dataset,
    seed: int,
) -> tuple[
    str,
    LayerSnapshot,
    dict[str, float],
]:
    """
    Use the same particular initialisation for every strategy.

    The historical-mean particular state is independent of the target support
    set and keeps the shared-representation comparison consistent.
    """
    historical_mean = average_snapshots(
        list(historical_particular.values())
    )

    tf.keras.backend.clear_session()
    gc.collect()
    set_deterministic_execution(seed)

    model = end_to_end()
    validate_partition(model)
    restore_named_layers(model, w_star)
    restore_named_layers(model, historical_mean)

    loss = evaluate_loss(
        model,
        support_dataset,
    )

    del model

    return (
        "historical_mean",
        historical_mean,
        {"historical_mean": loss},
    )


# ============================================================
# Parameter audit
# ============================================================

def snapshot_all_layer_weights(
    model: tf.keras.Model,
) -> dict[str, list[np.ndarray]]:
    return {
        layer.name: [
            np.asarray(
                variable.numpy()
            ).copy()
            for variable in layer.weights
        ]
        for layer in model.layers
        if layer.weights
    }


def calculate_parameter_change_audit(
    model: tf.keras.Model,
    before_snapshot:
        Mapping[str, list[np.ndarray]],
    seed: int,
    target_pdp: int,
    adaptation_blocks: int,
    method: str,
    learning_rate: float,
) -> list[dict]:
    particular_layers = set(
        PARTICULAR_LAYER_NAMES
    )

    rows: list[dict] = []

    for layer in model.layers:
        if layer.name not in before_snapshot:
            continue

        before_values = before_snapshot[
            layer.name
        ]

        after_values = [
            np.asarray(
                variable.numpy()
            )
            for variable in layer.weights
        ]

        if len(before_values) != len(
            after_values
        ):
            raise ValueError(
                f"Tensor count mismatch for {layer.name}."
            )

        before_flat_parts: list[np.ndarray] = []
        delta_flat_parts: list[np.ndarray] = []

        for before_value, after_value in zip(
            before_values,
            after_values,
        ):
            if tuple(before_value.shape) != tuple(
                after_value.shape
            ):
                raise ValueError(
                    f"Shape mismatch for {layer.name}."
                )

            before_array = np.asarray(
                before_value,
                dtype=np.float64,
            )

            after_array = np.asarray(
                after_value,
                dtype=np.float64,
            )

            before_flat_parts.append(
                before_array.reshape(-1)
            )

            delta_flat_parts.append(
                (
                    after_array
                    - before_array
                ).reshape(-1)
            )

        before_flat = np.concatenate(
            before_flat_parts
        )

        delta_flat = np.concatenate(
            delta_flat_parts
        )

        weight_l2_before = float(
            np.linalg.norm(
                before_flat,
                ord=2,
            )
        )

        delta_l2 = float(
            np.linalg.norm(
                delta_flat,
                ord=2,
            )
        )

        rows.append({
            "seed":
                seed,
            "target_pdp":
                target_pdp,
            "adaptation_blocks":
                adaptation_blocks,
            "method":
                method,
            "learning_rate":
                learning_rate,
            "layer_name":
                layer.name,
            "parameter_group":
                (
                    "particular"
                    if layer.name
                    in particular_layers
                    else "shared"
                ),
            "parameter_count":
                int(delta_flat.size),
            "weight_l2_before":
                weight_l2_before,
            "delta_l2":
                delta_l2,
            "relative_delta_l2":
                (
                    delta_l2
                    / (
                        weight_l2_before
                        + EPSILON
                    )
                ),
            "mean_absolute_delta":
                float(
                    np.mean(
                        np.abs(delta_flat)
                    )
                ),
            "max_absolute_delta":
                float(
                    np.max(
                        np.abs(delta_flat)
                    )
                ),
            "changed_parameter_fraction":
                float(
                    np.mean(
                        np.abs(delta_flat)
                        > 1e-8
                    )
                ),
        })

    return rows


def summarise_parameter_changes(
    audit_rows: list[dict],
) -> dict[str, float]:
    shared_rows = [
        row
        for row in audit_rows
        if row["parameter_group"]
        == "shared"
    ]

    particular_rows = [
        row
        for row in audit_rows
        if row["parameter_group"]
        == "particular"
    ]

    return {
        "shared_total_delta_l2":
            float(
                np.sqrt(
                    sum(
                        row["delta_l2"] ** 2
                        for row in shared_rows
                    )
                )
            ),
        "particular_total_delta_l2":
            float(
                np.sqrt(
                    sum(
                        row["delta_l2"] ** 2
                        for row in particular_rows
                    )
                )
            ),
        "maximum_shared_absolute_delta":
            float(
                max(
                    (
                        row[
                            "max_absolute_delta"
                        ]
                        for row in shared_rows
                    ),
                    default=0.0,
                )
            ),
        "maximum_particular_absolute_delta":
            float(
                max(
                    (
                        row[
                            "max_absolute_delta"
                        ]
                        for row in particular_rows
                    ),
                    default=0.0,
                )
            ),
    }


# ============================================================
# Historical forgetting
# ============================================================

def build_historical_evaluation_datasets(
    pdps,
    historical_pdps: Iterable[int],
    ebno_linear: float,
    num_blocks: int,
    seed: int,
) -> dict[int, object]:
    return {
        pdp_id: make_fixed_adaptation_dataset(
            pdp_target=pdps[pdp_id],
            pdp_id=pdp_id,
            num_blocks=num_blocks,
            ebno_linear=ebno_linear,
            seed=(
                seed
                + 300000
                + pdp_id * 1000
            ),
        )
        for pdp_id in historical_pdps
    }


def evaluate_historical_with_shared(
    shared_snapshot: LayerSnapshot,
    historical_particular:
        Mapping[int, LayerSnapshot],
    historical_datasets:
        Mapping[int, object],
    seed: int,
) -> dict[int, float]:
    results: dict[int, float] = {}

    for pdp_id, dataset in (
        historical_datasets.items()
    ):
        tf.keras.backend.clear_session()
        gc.collect()
        set_deterministic_execution(seed)

        model = end_to_end()
        validate_partition(model)

        restore_named_layers(
            model,
            shared_snapshot,
        )

        restore_named_layers(
            model,
            historical_particular[
                pdp_id
            ],
        )

        results[pdp_id] = (
            evaluate_ber(
                model,
                dataset,
            )
        )

        del model

    return results


# ============================================================
# LR sweep
# ============================================================

def run_lr_sweep(
    *,
    strategy: str,
    learning_rates: list[float],
    epochs: int,
    seed: int,
    support_dataset,
    validation_dataset,
    w_star: LayerSnapshot,
    v_initial: LayerSnapshot,
) -> tuple[
    float,
    list[dict],
]:
    """
    Select LR using target support/validation data only.
    Query data must not be used for LR selection.
    """
    if strategy == "no_adaptation":
        return 0.0, []

    sweep_rows: list[dict] = []

    for learning_rate in learning_rates:
        tf.keras.backend.clear_session()
        gc.collect()
        set_deterministic_execution(seed)

        model = end_to_end()
        validate_partition(model)

        restore_named_layers(
            model,
            w_star,
        )

        restore_named_layers(
            model,
            v_initial,
        )

        history = adapt_model(
            model=model,
            dataset=support_dataset,
            strategy=strategy,
            epochs=epochs,
            learning_rate=learning_rate,
            seed=seed,
        )

        validation_ber = evaluate_ber(
            model,
            validation_dataset,
        )

        sweep_rows.append({
            "strategy":
                strategy,
            "learning_rate":
                learning_rate,
            "validation_ber":
                validation_ber,
            "final_support_loss":
                history[-1]["loss"],
            "final_support_ber":
                history[-1]["ber"],
        })

        del model

    best_row = min(
        sweep_rows,
        key=lambda row: row[
            "validation_ber"
        ],
    )

    return float(
        best_row["learning_rate"]
    ), sweep_rows


# ============================================================
# Summary generation
# ============================================================

def build_strategy_summary(
    raw_rows: list[dict],
) -> list[dict]:
    groups: dict[
        tuple[int, int, str],
        list[dict],
    ] = {}

    for row in raw_rows:
        key = (
            int(row["target_pdp"]),
            int(row["adaptation_blocks"]),
            str(row["method"]),
        )

        groups.setdefault(
            key,
            [],
        ).append(row)

    summary_rows: list[dict] = []

    for (
        target_pdp,
        adaptation_blocks,
        method,
    ), rows in sorted(
        groups.items()
    ):
        zero_values = [
            float(row["zero_shot_ber"])
            for row in rows
        ]

        adapted_values = [
            float(row["adapted_ber"])
            for row in rows
        ]

        improvement_values = [
            float(row["absolute_improvement"])
            for row in rows
        ]

        relative_values = [
            float(row["relative_improvement"])
            for row in rows
        ]

        forgetting_values = [
            float(row["mean_historical_forgetting"])
            for row in rows
        ]

        summary_rows.append({
            "target_pdp":
                target_pdp,
            "adaptation_blocks":
                adaptation_blocks,
            "method":
                method,
            "seed_count":
                len({
                    int(row["seed"])
                    for row in rows
                }),
            "mean_zero_shot_ber":
                float(np.mean(zero_values)),
            "std_zero_shot_ber":
                population_std(zero_values),
            "mean_adapted_ber":
                float(np.mean(adapted_values)),
            "std_adapted_ber":
                population_std(adapted_values),
            "mean_absolute_improvement":
                float(
                    np.mean(
                        improvement_values
                    )
                ),
            "std_absolute_improvement":
                population_std(
                    improvement_values
                ),
            "mean_relative_improvement":
                float(
                    np.mean(
                        relative_values
                    )
                ),
            "positive_improvement_fraction":
                float(
                    np.mean(
                        np.asarray(
                            improvement_values
                        )
                        > 0
                    )
                ),
            "mean_trainable_parameters":
                float(
                    np.mean([
                        float(
                            row[
                                "trainable_parameters"
                            ]
                        )
                        for row in rows
                    ])
                ),
            "mean_trainable_percentage":
                float(
                    np.mean([
                        float(
                            row[
                                "trainable_percentage"
                            ]
                        )
                        for row in rows
                    ])
                ),
            "mean_selected_learning_rate":
                float(
                    np.mean([
                        float(
                            row[
                                "selected_learning_rate"
                            ]
                        )
                        for row in rows
                    ])
                ),
            "mean_historical_forgetting":
                float(
                    np.mean(
                        forgetting_values
                    )
                ),
            "std_historical_forgetting":
                population_std(
                    forgetting_values
                ),
            "mean_repeatability_range":
                float(
                    np.mean([
                        float(
                            row[
                                "repeatability_range"
                            ]
                        )
                        for row in rows
                    ])
                ),
        })

    indexed = {
        (
            int(row["target_pdp"]),
            int(row["adaptation_blocks"]),
            str(row["method"]),
        ):
            row
        for row in summary_rows
    }

    for row in summary_rows:
        full_row = indexed.get(
            (
                int(row["target_pdp"]),
                int(
                    row[
                        "adaptation_blocks"
                    ]
                ),
                "full_finetune",
            )
        )

        if full_row is None:
            row[
                "recovery_ratio_vs_full"
            ] = float("nan")
            continue

        full_gain = float(
            full_row[
                "mean_absolute_improvement"
            ]
        )

        method_gain = float(
            row[
                "mean_absolute_improvement"
            ]
        )

        row[
            "recovery_ratio_vs_full"
        ] = (
            method_gain / full_gain
            if full_gain > 0
            else float("nan")
        )

    return summary_rows


# ============================================================
# Arguments
# ============================================================

def parse_float_list(
    values: list[str],
) -> list[float]:
    return [
        float(value)
        for value in values
    ]


def parse_arguments() -> argparse.Namespace:
    config = Task6Config()

    parser = argparse.ArgumentParser(
        description=(
            "Task 6.5 v2: matched unseen-PDP strategy "
            "comparison with LR selection, deterministic "
            "no-adaptation baseline, parameter auditing and "
            "historical-forgetting evaluation."
        )
    )

    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=list(config.seeds),
    )

    parser.add_argument(
        "--adaptation-blocks",
        nargs="+",
        type=int,
        default=[
            512,
            1024,
            2048,
            4096,
        ],
    )

    parser.add_argument(
        "--strategies",
        nargs="+",
        choices=list(
            STRATEGIES
        ),
        default=list(
            STRATEGIES
        ),
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=20,
    )

    parser.add_argument(
        "--lr-sweep-epochs",
        type=int,
        default=10,
    )

    parser.add_argument(
        "--particular-learning-rates",
        nargs="+",
        default=[
            "1e-5",
            "3e-5",
            "1e-4",
            "3e-4",
        ],
    )

    parser.add_argument(
        "--full-learning-rates",
        nargs="+",
        default=[
            "1e-6",
            "3e-6",
            "1e-5",
            "3e-5",
            "1e-4",
        ],
    )

    parser.add_argument(
        "--query-blocks",
        type=int,
        default=8192,
    )

    parser.add_argument(
        "--lr-validation-blocks",
        type=int,
        default=2048,
    )

    parser.add_argument(
        "--historical-query-blocks",
        type=int,
        default=4096,
    )

    parser.add_argument(
        "--repeatability-checks",
        type=int,
        default=3,
    )

    parser.add_argument(
        "--training-root",
        type=Path,
        default=(
            config.output_root
            / "iadmm_training_revised"
        ),
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            config.output_root
            / "unseen_strategy_comparison_revised"
        ),
    )

    args = parser.parse_args()

    args.particular_learning_rates = (
        parse_float_list(
            args.particular_learning_rates
        )
    )

    args.full_learning_rates = (
        parse_float_list(
            args.full_learning_rates
        )
    )

    return args


def validate_arguments(
    args: argparse.Namespace,
) -> None:
    if not args.seeds:
        raise ValueError(
            "At least one seed is required."
        )

    if not args.adaptation_blocks:
        raise ValueError(
            "At least one support size is required."
        )

    if any(
        value <= 0
        for value in args.adaptation_blocks
    ):
        raise ValueError(
            "Support sizes must be positive."
        )

    if args.epochs <= 0:
        raise ValueError(
            "--epochs must be positive."
        )

    if args.lr_sweep_epochs <= 0:
        raise ValueError(
            "--lr-sweep-epochs must be positive."
        )

    if args.query_blocks <= 0:
        raise ValueError(
            "--query-blocks must be positive."
        )

    if args.lr_validation_blocks <= 0:
        raise ValueError(
            "--lr-validation-blocks must be positive."
        )

    if args.historical_query_blocks <= 0:
        raise ValueError(
            "--historical-query-blocks must be positive."
        )

    if args.repeatability_checks <= 0:
        raise ValueError(
            "--repeatability-checks must be positive."
        )


# ============================================================
# Main experiment
# ============================================================

def main() -> int:
    args = parse_arguments()
    validate_arguments(args)

    config = Task6Config()
    pdps = get_known_pdps()

    raw_rows: list[dict] = []
    parameter_audit_rows: list[dict] = []
    historical_rows: list[dict] = []
    lr_sweep_rows: list[dict] = []

    args.output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    for seed in args.seeds:
        training_directory = (
            args.training_root
            / f"seed_{seed}"
        )

        if not training_directory.exists():
            raise FileNotFoundError(
                "Missing Task 6.3 directory: "
                f"{training_directory}"
            )

        w_star = load_snapshot_npz(
            training_directory
            / "global_shared_w.npz"
        )

        historical_particular = {
            pdp_id: load_snapshot_npz(
                training_directory
                / "particular"
                / f"PDP{pdp_id}_v_i.npz"
            )
            for pdp_id
            in config.train_pdps
        }

        historical_datasets = (
            build_historical_evaluation_datasets(
                pdps=pdps,
                historical_pdps=(
                    config.train_pdps
                ),
                ebno_linear=(
                    config.ebno_linear
                ),
                num_blocks=(
                    args.historical_query_blocks
                ),
                seed=seed,
            )
        )

        historical_baseline = (
            evaluate_historical_with_shared(
                shared_snapshot=w_star,
                historical_particular=(
                    historical_particular
                ),
                historical_datasets=(
                    historical_datasets
                ),
                seed=seed,
            )
        )

        for target_pdp_id in (
            config.unseen_pdps
        ):
            target_pdp = pdps[
                target_pdp_id
            ]

            support_seed = (
                seed
                + 100000
                + target_pdp_id * 1000
            )

            lr_validation_seed = (
                seed
                + 150000
                + target_pdp_id * 1000
            )

            query_seed = (
                seed
                + 200000
                + target_pdp_id * 1000
            )

            lr_validation_dataset = (
                make_fixed_adaptation_dataset(
                    pdp_target=target_pdp,
                    pdp_id=target_pdp_id,
                    num_blocks=(
                        args.lr_validation_blocks
                    ),
                    ebno_linear=(
                        config.ebno_linear
                    ),
                    seed=lr_validation_seed,
                )
            )

            for block_count in (
                args.adaptation_blocks
            ):
                print("\n" + "=" * 80)
                print(
                    f"PDP{target_pdp_id} | "
                    f"seed={seed} | "
                    f"support={block_count}"
                )
                print("=" * 80)

                support_dataset = (
                    make_fixed_adaptation_dataset(
                        pdp_target=target_pdp,
                        pdp_id=target_pdp_id,
                        num_blocks=block_count,
                        ebno_linear=(
                            config.ebno_linear
                        ),
                        seed=support_seed,
                    )
                )

                query_dataset = (
                    make_fixed_adaptation_dataset(
                        pdp_target=target_pdp,
                        pdp_id=target_pdp_id,
                        num_blocks=(
                            args.query_blocks
                        ),
                        ebno_linear=(
                            config.ebno_linear
                        ),
                        seed=query_seed,
                    )
                )

                (
                    initialisation_name,
                    v_initial,
                    initialisation_losses,
                ) = choose_particular_initialisation(
                    w_star=w_star,
                    historical_particular=(
                        historical_particular
                    ),
                    support_dataset=(
                        support_dataset
                    ),
                    seed=seed,
                )

                # --------------------------------------------
                # Select LR separately for each trainable method.
                # The query set is not used.
                # --------------------------------------------

                selected_learning_rates = {
                    "no_adaptation":
                        0.0,
                }

                if (
                    "particular_only_tl"
                    in args.strategies
                ):
                    (
                        selected_lr,
                        sweep_rows,
                    ) = run_lr_sweep(
                        strategy=(
                            "particular_only_tl"
                        ),
                        learning_rates=(
                            args
                            .particular_learning_rates
                        ),
                        epochs=(
                            args.lr_sweep_epochs
                        ),
                        seed=support_seed,
                        support_dataset=(
                            support_dataset
                        ),
                        validation_dataset=(
                            lr_validation_dataset
                        ),
                        w_star=w_star,
                        v_initial=v_initial,
                    )

                    selected_learning_rates[
                        "particular_only_tl"
                    ] = selected_lr

                    for row in sweep_rows:
                        lr_sweep_rows.append({
                            "seed":
                                seed,
                            "target_pdp":
                                target_pdp_id,
                            "adaptation_blocks":
                                block_count,
                            **row,
                        })

                if (
                    "full_finetune"
                    in args.strategies
                ):
                    (
                        selected_lr,
                        sweep_rows,
                    ) = run_lr_sweep(
                        strategy=(
                            "full_finetune"
                        ),
                        learning_rates=(
                            args
                            .full_learning_rates
                        ),
                        epochs=(
                            args.lr_sweep_epochs
                        ),
                        seed=support_seed,
                        support_dataset=(
                            support_dataset
                        ),
                        validation_dataset=(
                            lr_validation_dataset
                        ),
                        w_star=w_star,
                        v_initial=v_initial,
                    )

                    selected_learning_rates[
                        "full_finetune"
                    ] = selected_lr

                    for row in sweep_rows:
                        lr_sweep_rows.append({
                            "seed":
                                seed,
                            "target_pdp":
                                target_pdp_id,
                            "adaptation_blocks":
                                block_count,
                            **row,
                        })

                for strategy in args.strategies:
                    tf.keras.backend.clear_session()
                    gc.collect()
                    set_deterministic_execution(seed)

                    model = end_to_end()
                    validate_partition(model)

                    restore_named_layers(
                        model,
                        w_star,
                    )

                    restore_named_layers(
                        model,
                        v_initial,
                    )

                    before_snapshot = (
                        snapshot_all_layer_weights(
                            model
                        )
                    )

                    repeat_values, repeat_range = (
                        repeatability_check(
                            model,
                            query_dataset,
                            repeats=(
                                args.repeatability_checks
                            ),
                        )
                    )

                    zero_shot_ber = float(
                        repeat_values[0]
                    )

                    selected_learning_rate = (
                        selected_learning_rates[
                            strategy
                        ]
                    )

                    set_strategy_trainable(
                        model=model,
                        strategy=strategy,
                    )

                    trainable_parameters = (
                        count_trainable_parameters(
                            model
                        )
                    )

                    total_parameters = int(
                        model.count_params()
                    )

                    history = adapt_model(
                        model=model,
                        dataset=support_dataset,
                        strategy=strategy,
                        epochs=args.epochs,
                        learning_rate=(
                            selected_learning_rate
                        ),
                        seed=support_seed,
                    )

                    # With no adaptation, post-adaptation BER equals
                    # zero-shot BER.
                    if strategy == "no_adaptation":
                        adapted_ber = zero_shot_ber
                    else:
                        adapted_ber = evaluate_ber(
                            model,
                            query_dataset,
                        )

                    audit_rows = (
                        calculate_parameter_change_audit(
                            model=model,
                            before_snapshot=(
                                before_snapshot
                            ),
                            seed=seed,
                            target_pdp=(
                                target_pdp_id
                            ),
                            adaptation_blocks=(
                                block_count
                            ),
                            method=strategy,
                            learning_rate=(
                                selected_learning_rate
                            ),
                        )
                    )

                    parameter_summary = (
                        summarise_parameter_changes(
                            audit_rows
                        )
                    )

                    parameter_audit_rows.extend(
                        audit_rows
                    )

                    shared_names = (
                        shared_layer_names(
                            model
                        )
                    )

                    adapted_shared = (
                        snapshot_named_layers(
                            model,
                            shared_names,
                        )
                    )

                    historical_after = (
                        evaluate_historical_with_shared(
                            shared_snapshot=(
                                adapted_shared
                            ),
                            historical_particular=(
                                historical_particular
                            ),
                            historical_datasets=(
                                historical_datasets
                            ),
                            seed=seed,
                        )
                    )

                    forgetting_by_pdp = {
                        pdp_id: (
                            historical_after[
                                pdp_id
                            ]
                            - historical_baseline[
                                pdp_id
                            ]
                        )
                        for pdp_id
                        in config.train_pdps
                    }

                    mean_historical_forgetting = float(
                        np.mean(
                            list(
                                forgetting_by_pdp.values()
                            )
                        )
                    )

                    maximum_historical_forgetting = float(
                        np.max(
                            list(
                                forgetting_by_pdp.values()
                            )
                        )
                    )

                    for historical_pdp_id in (
                        config.train_pdps
                    ):
                        historical_rows.append({
                            "seed":
                                seed,
                            "target_pdp":
                                target_pdp_id,
                            "adaptation_blocks":
                                block_count,
                            "method":
                                strategy,
                            "selected_learning_rate":
                                selected_learning_rate,
                            "historical_pdp":
                                historical_pdp_id,
                            "ber_before":
                                historical_baseline[
                                    historical_pdp_id
                                ],
                            "ber_after":
                                historical_after[
                                    historical_pdp_id
                                ],
                            "forgetting":
                                forgetting_by_pdp[
                                    historical_pdp_id
                                ],
                        })

                    final_support_loss = (
                        history[-1]["loss"]
                        if history
                        else evaluate_loss(
                            model,
                            support_dataset,
                        )
                    )

                    final_support_ber = (
                        history[-1]["ber"]
                        if history
                        else evaluate_ber(
                            model,
                            support_dataset,
                        )
                    )

                    row = {
                        "seed":
                            seed,
                        "target_pdp":
                            target_pdp_id,
                        "adaptation_blocks":
                            block_count,
                        "method":
                            strategy,
                        "particular_initialisation":
                            initialisation_name,
                        "initialisation_support_loss":
                            initialisation_losses[
                                initialisation_name
                            ],
                        "selected_learning_rate":
                            selected_learning_rate,
                        "zero_shot_ber":
                            zero_shot_ber,
                        "adapted_ber":
                            adapted_ber,
                        "absolute_improvement":
                            zero_shot_ber
                            - adapted_ber,
                        "relative_improvement":
                            (
                                zero_shot_ber
                                - adapted_ber
                            ) / zero_shot_ber
                            if zero_shot_ber > 0
                            else 0.0,
                        "trainable_parameters":
                            trainable_parameters,
                        "total_parameters":
                            total_parameters,
                        "trainable_percentage":
                            (
                                100.0
                                * trainable_parameters
                                / total_parameters
                            ),
                        "adaptation_epochs":
                            (
                                0
                                if strategy
                                == "no_adaptation"
                                else args.epochs
                            ),
                        "final_support_loss":
                            final_support_loss,
                        "final_support_ber":
                            final_support_ber,
                        "shared_total_delta_l2":
                            parameter_summary[
                                "shared_total_delta_l2"
                            ],
                        "particular_total_delta_l2":
                            parameter_summary[
                                "particular_total_delta_l2"
                            ],
                        "maximum_shared_absolute_delta":
                            parameter_summary[
                                "maximum_shared_absolute_delta"
                            ],
                        "maximum_particular_absolute_delta":
                            parameter_summary[
                                "maximum_particular_absolute_delta"
                            ],
                        "mean_historical_forgetting":
                            mean_historical_forgetting,
                        "maximum_historical_forgetting":
                            maximum_historical_forgetting,
                        "repeatability_values":
                            json.dumps(
                                repeat_values
                            ),
                        "repeatability_range":
                            repeat_range,
                        "historical_training":
                            (
                                "Algorithm 1 iADMM "
                                "equations (8)-(10)"
                            ),
                        "inference":
                            "equation (7)",
                    }

                    raw_rows.append(row)

                    result_directory = (
                        args.output_root
                        / f"PDP{target_pdp_id}"
                        / f"seed_{seed}"
                        / f"blocks_{block_count}"
                        / strategy
                    )

                    result_directory.mkdir(
                        parents=True,
                        exist_ok=True,
                    )

                    (
                        result_directory
                        / "training_history.json"
                    ).write_text(
                        json.dumps(
                            history,
                            indent=2,
                        ),
                        encoding="utf-8",
                    )

                    (
                        result_directory
                        / "result.json"
                    ).write_text(
                        json.dumps(
                            row,
                            indent=2,
                        ),
                        encoding="utf-8",
                    )

                    write_csv(
                        result_directory
                        / "parameter_change_audit.csv",
                        audit_rows,
                    )

                    write_csv(
                        args.output_root
                        / "strategy_comparison_raw_partial.csv",
                        raw_rows,
                    )

                    write_csv(
                        args.output_root
                        / "parameter_change_audit_partial.csv",
                        parameter_audit_rows,
                    )

                    write_csv(
                        args.output_root
                        / "historical_forgetting_raw_partial.csv",
                        historical_rows,
                    )

                    write_csv(
                        args.output_root
                        / "lr_sweep_raw_partial.csv",
                        lr_sweep_rows,
                    )

                    print(
                        f"{strategy}: "
                        f"LR={selected_learning_rate:.1e} | "
                        f"BER {zero_shot_ber:.6f} "
                        f"-> {adapted_ber:.6f} | "
                        f"trainable={trainable_parameters:,} "
                        f"({100.0 * trainable_parameters / total_parameters:.2f}%) | "
                        f"mean forgetting="
                        f"{mean_historical_forgetting:.6f} | "
                        f"repeatability range="
                        f"{repeat_range:.6e}"
                    )

                    del model
                    gc.collect()

    summary_rows = build_strategy_summary(
        raw_rows
    )

    raw_path = (
        args.output_root
        / "strategy_comparison_raw.csv"
    )

    summary_path = (
        args.output_root
        / "strategy_comparison_summary.csv"
    )

    audit_path = (
        args.output_root
        / "parameter_change_audit.csv"
    )

    forgetting_path = (
        args.output_root
        / "historical_forgetting_raw.csv"
    )

    lr_sweep_path = (
        args.output_root
        / "lr_sweep_raw.csv"
    )

    output_summary_compatible_path = (
        args.output_root
        / "unseen_adaptation_raw.csv"
    )

    write_csv(
        raw_path,
        raw_rows,
    )

    write_csv(
        output_summary_compatible_path,
        raw_rows,
    )

    write_csv(
        summary_path,
        summary_rows,
    )

    write_csv(
        audit_path,
        parameter_audit_rows,
    )

    write_csv(
        forgetting_path,
        historical_rows,
    )

    write_csv(
        lr_sweep_path,
        lr_sweep_rows,
    )

    print("\n" + "=" * 80)
    print("Task 6.5 v2 strategy comparison completed")
    print("=" * 80)
    print(f"Raw results:\n{raw_path}")
    print(f"\nSummary:\n{summary_path}")
    print(f"\nLR sweep:\n{lr_sweep_path}")
    print(f"\nParameter audit:\n{audit_path}")
    print(f"\nHistorical forgetting:\n{forgetting_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
