from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping

import numpy as np
import tensorflow as tf


TensorList = List[np.ndarray]
LayerSnapshot = Dict[str, TensorList]


def _assert_finite_array(
    value: np.ndarray,
    context: str,
) -> None:
    if not np.all(np.isfinite(value)):
        raise FloatingPointError(
            f"Non-finite values detected in {context}."
        )


def copy_snapshot(
    snapshot: Mapping[str, TensorList],
) -> LayerSnapshot:
    result: LayerSnapshot = {}

    for layer_name, values in snapshot.items():
        copied_values: TensorList = []

        for tensor_index, value in enumerate(values):
            array = np.asarray(value).copy()
            _assert_finite_array(
                array,
                f"{layer_name}[{tensor_index}]",
            )
            copied_values.append(array)

        result[layer_name] = copied_values

    return result


def copy_environment_snapshots(
    snapshots_by_pdp: Mapping[int, LayerSnapshot],
) -> Dict[int, LayerSnapshot]:
    return {
        int(pdp_id): copy_snapshot(snapshot)
        for pdp_id, snapshot in snapshots_by_pdp.items()
    }


def snapshot_named_layers(
    model: tf.keras.Model,
    layer_names: Iterable[str],
) -> LayerSnapshot:
    """
    Snapshot trainable Algorithm 1 parameters.

    Algorithm 1 uses only trainable parameters w and v. Non-trainable Keras
    state is excluded and checked by the partition validator.
    """
    result: LayerSnapshot = {}

    for layer_name in layer_names:
        layer = model.get_layer(layer_name)
        variables = list(layer.trainable_weights)

        if not variables:
            raise ValueError(
                f"Layer {layer_name!r} has no trainable weights."
            )

        values: TensorList = []

        for tensor_index, variable in enumerate(variables):
            value = np.asarray(variable.numpy()).copy()
            _assert_finite_array(
                value,
                f"{layer_name}[{tensor_index}]",
            )
            values.append(value)

        result[layer_name] = values

    return result


def restore_named_layers(
    model: tf.keras.Model,
    snapshot: Mapping[str, TensorList],
) -> None:
    """
    Restore trainable Algorithm 1 parameters.

    Relevant layers must remain trainable during Algorithm 1. Frozen Keras
    layers have an empty trainable_weights collection, so full layer weights
    are required for parameter-change checks.
    """
    for layer_name, saved_values in snapshot.items():
        layer = model.get_layer(layer_name)
        variables = list(layer.trainable_weights)

        if len(variables) != len(saved_values):
            raise ValueError(
                f"Trainable-weight count mismatch for {layer_name}: "
                f"model={len(variables)}, snapshot={len(saved_values)}"
            )

        for tensor_index, (variable, value) in enumerate(
            zip(variables, saved_values)
        ):
            array = np.asarray(value)

            _assert_finite_array(
                array,
                f"restore {layer_name}[{tensor_index}]",
            )

            if tuple(variable.shape) != tuple(array.shape):
                raise ValueError(
                    f"Shape mismatch for {layer_name}/{variable.name}: "
                    f"model={tuple(variable.shape)}, "
                    f"snapshot={tuple(array.shape)}"
                )

            variable.assign(array)


def zeros_like_snapshot(
    snapshot: Mapping[str, TensorList],
) -> LayerSnapshot:
    return {
        layer_name: [
            np.zeros_like(value)
            for value in values
        ]
        for layer_name, values in snapshot.items()
    }


def save_snapshot_npz(
    path: Path,
    snapshot: Mapping[str, TensorList],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    payload: dict[str, np.ndarray] = {}

    for layer_name, values in snapshot.items():
        for tensor_index, value in enumerate(values):
            array = np.asarray(value)

            _assert_finite_array(
                array,
                f"save {layer_name}[{tensor_index}]",
            )

            payload[f"{layer_name}::{tensor_index}"] = array

    np.savez_compressed(path, **payload)


def load_snapshot_npz(
    path: Path,
) -> LayerSnapshot:
    if not path.exists():
        raise FileNotFoundError(path)

    result: LayerSnapshot = {}

    with np.load(path, allow_pickle=False) as archive:
        for key in archive.files:
            layer_name, tensor_index_text = key.split(
                "::",
                maxsplit=1,
            )
            tensor_index = int(tensor_index_text)

            result.setdefault(layer_name, [])

            while len(result[layer_name]) <= tensor_index:
                result[layer_name].append(None)

            value = archive[key].copy()

            _assert_finite_array(
                value,
                f"{path}:{key}",
            )

            result[layer_name][tensor_index] = value

    for layer_name, values in result.items():
        if any(value is None for value in values):
            raise ValueError(
                f"Incomplete snapshot for {layer_name} in {path}"
            )

    return result


@dataclass
class IADMMState:
    """
    Algorithm 1 notation:
      global_shared  -> w^l
      local_shared[i] -> w_i^l
      particular[i]   -> v_i^l
      dual[i]         -> pi_i^l
    """
    global_shared: LayerSnapshot
    local_shared: Dict[int, LayerSnapshot]
    particular: Dict[int, LayerSnapshot]
    dual: Dict[int, LayerSnapshot]


def copy_iadmm_state(
    state: IADMMState,
) -> IADMMState:
    return IADMMState(
        global_shared=copy_snapshot(state.global_shared),
        local_shared=copy_environment_snapshots(
            state.local_shared
        ),
        particular=copy_environment_snapshots(
            state.particular
        ),
        dual=copy_environment_snapshots(
            state.dual
        ),
    )


def initialise_iadmm_state(
    model: tf.keras.Model,
    train_pdp_ids: Iterable[int],
    shared_layer_names: Iterable[str],
    particular_layer_names: Iterable[str],
) -> IADMMState:
    train_ids = tuple(train_pdp_ids)

    if not train_ids:
        raise ValueError(
            "No historical environments supplied."
        )

    initial_shared = snapshot_named_layers(
        model,
        shared_layer_names,
    )
    initial_particular = snapshot_named_layers(
        model,
        particular_layer_names,
    )

    # Algorithm 1 initialisation:
    # w^0, {w_i^0, v_i^0, pi_i^0}.
    # All local copies begin at the same pretrained model and pi_i^0 = 0.
    return IADMMState(
        global_shared=copy_snapshot(initial_shared),
        local_shared={
            pdp_id: copy_snapshot(initial_shared)
            for pdp_id in train_ids
        },
        particular={
            pdp_id: copy_snapshot(initial_particular)
            for pdp_id in train_ids
        },
        dual={
            pdp_id: zeros_like_snapshot(initial_shared)
            for pdp_id in train_ids
        },
    )


def average_snapshots(
    snapshots: List[LayerSnapshot],
) -> LayerSnapshot:
    if not snapshots:
        raise ValueError("No snapshots supplied.")

    reference_layers = set(snapshots[0])

    for snapshot in snapshots[1:]:
        if set(snapshot) != reference_layers:
            raise ValueError(
                "Snapshots contain different layers."
            )

    result: LayerSnapshot = {}

    for layer_name in sorted(reference_layers):
        tensor_count = len(
            snapshots[0][layer_name]
        )
        result[layer_name] = []

        for tensor_index in range(tensor_count):
            stacked = np.stack([
                snapshot[layer_name][tensor_index]
                for snapshot in snapshots
            ])
            mean_value = np.mean(
                stacked,
                axis=0,
            )

            _assert_finite_array(
                mean_value,
                f"average {layer_name}[{tensor_index}]",
            )

            result[layer_name].append(mean_value)

    return result
