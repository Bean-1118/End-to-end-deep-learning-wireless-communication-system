from __future__ import annotations

from typing import Dict, Mapping

import numpy as np

from src.task6.iadmm_state import LayerSnapshot


EPSILON = 1e-12


def assert_same_structure(
    first: Mapping[str, list],
    second: Mapping[str, list],
) -> None:
    if set(first) != set(second):
        raise ValueError(
            "Snapshots contain different layers."
        )

    for layer_name in first:
        if len(first[layer_name]) != len(
            second[layer_name]
        ):
            raise ValueError(
                f"Tensor count mismatch in {layer_name}."
            )


def assert_finite_snapshot(
    snapshot: Mapping[str, list],
    context: str,
) -> None:
    for layer_name, tensors in snapshot.items():
        for tensor_index, tensor in enumerate(tensors):
            if not np.all(np.isfinite(tensor)):
                raise FloatingPointError(
                    f"Non-finite snapshot in {context}: "
                    f"{layer_name}[{tensor_index}]"
                )


def global_shared_update(
    local_shared: Dict[int, LayerSnapshot],
    dual: Dict[int, LayerSnapshot],
    sigma: float,
) -> LayerSnapshot:
    r"""
    Algorithm 1, Eq. (9): global shared update.

        w^{l+1}
          = (1/N) sum_i [ w_i^l + pi_i^l / sigma ]

    Uses w_i^l and pi_i^l from iteration l.
    """
    if sigma <= 0:
        raise ValueError(
            "sigma must be positive."
        )

    environment_ids = sorted(local_shared)

    if not environment_ids:
        raise ValueError(
            "No local environments supplied."
        )

    if set(environment_ids) != set(dual):
        raise ValueError(
            "local_shared and dual environments do not match."
        )

    reference = local_shared[
        environment_ids[0]
    ]

    for pdp_id in environment_ids:
        assert_same_structure(
            reference,
            local_shared[pdp_id],
        )
        assert_same_structure(
            reference,
            dual[pdp_id],
        )

    result: LayerSnapshot = {}

    for layer_name, reference_tensors in reference.items():
        result[layer_name] = []

        for tensor_index in range(
            len(reference_tensors)
        ):
            terms = []

            for pdp_id in environment_ids:
                local_value = (
                    local_shared[pdp_id]
                    [layer_name][tensor_index]
                )
                dual_value = (
                    dual[pdp_id]
                    [layer_name][tensor_index]
                )

                terms.append(
                    local_value
                    + dual_value / sigma
                )

            result[layer_name].append(
                np.mean(
                    np.stack(
                        terms,
                        axis=0,
                    ),
                    axis=0,
                )
            )

    assert_finite_snapshot(
        result,
        "global_shared_update",
    )

    return result


def local_shared_update(
    new_global_shared: LayerSnapshot,
    shared_gradient_at_old_local: LayerSnapshot,
    old_dual: LayerSnapshot,
    rho: float,
    sigma: float,
) -> LayerSnapshot:
    r"""
    Algorithm 1, Eq. (10): local shared update.

        w_i^{l+1}
          = w^{l+1}
            - [ xi_i^l + pi_i^l ] / (rho + sigma),

    where

        xi_i^l = grad_{w_i} f_i(w_i^l, v_i^l).

    Evaluate the gradient at (w_i^l, v_i^l), not at
    (w^{l+1}, v_i^l).
    """
    if rho <= 0:
        raise ValueError(
            "rho must be positive."
        )
    if sigma <= 0:
        raise ValueError(
            "sigma must be positive."
        )

    assert_same_structure(
        new_global_shared,
        shared_gradient_at_old_local,
    )
    assert_same_structure(
        new_global_shared,
        old_dual,
    )

    denominator = rho + sigma
    result: LayerSnapshot = {}

    for (
        layer_name,
        global_tensors,
    ) in new_global_shared.items():
        result[layer_name] = []

        for (
            tensor_index,
            global_value,
        ) in enumerate(global_tensors):
            gradient_value = (
                shared_gradient_at_old_local[
                    layer_name
                ][tensor_index]
            )
            dual_value = (
                old_dual[layer_name][tensor_index]
            )

            result[layer_name].append(
                global_value
                - (
                    gradient_value
                    + dual_value
                ) / denominator
            )

    assert_finite_snapshot(
        result,
        "local_shared_update",
    )

    return result


def particular_update(
    old_particular: LayerSnapshot,
    particular_gradient_at_old_local: LayerSnapshot,
    rho: float,
) -> LayerSnapshot:
    r"""
    Algorithm 1, Eq. (10): particular update.

        v_i^{l+1}
          = v_i^l - zeta_i^l / rho,

    where

        zeta_i^l = grad_{v_i} f_i(w_i^l, v_i^l).

    Use grad f_i directly, without a 1/N factor.
    """
    if rho <= 0:
        raise ValueError(
            "rho must be positive."
        )

    assert_same_structure(
        old_particular,
        particular_gradient_at_old_local,
    )

    result: LayerSnapshot = {}

    for (
        layer_name,
        old_tensors,
    ) in old_particular.items():
        result[layer_name] = []

        for (
            tensor_index,
            old_value,
        ) in enumerate(old_tensors):
            gradient_value = (
                particular_gradient_at_old_local[
                    layer_name
                ][tensor_index]
            )

            result[layer_name].append(
                old_value
                - gradient_value / rho
            )

    assert_finite_snapshot(
        result,
        "particular_update",
    )

    return result


def dual_update(
    old_dual: LayerSnapshot,
    new_local_shared: LayerSnapshot,
    new_global_shared: LayerSnapshot,
    sigma: float,
) -> LayerSnapshot:
    r"""
    Algorithm 1, Eq. (9): dual update.

        pi_i^{l+1}
          = pi_i^l
            + sigma ( w_i^{l+1} - w^{l+1} ).
    """
    if sigma <= 0:
        raise ValueError(
            "sigma must be positive."
        )

    assert_same_structure(
        old_dual,
        new_local_shared,
    )
    assert_same_structure(
        old_dual,
        new_global_shared,
    )

    result: LayerSnapshot = {}

    for (
        layer_name,
        old_dual_tensors,
    ) in old_dual.items():
        result[layer_name] = []

        for (
            tensor_index,
            old_dual_value,
        ) in enumerate(old_dual_tensors):
            local_value = (
                new_local_shared[
                    layer_name
                ][tensor_index]
            )
            global_value = (
                new_global_shared[
                    layer_name
                ][tensor_index]
            )

            result[layer_name].append(
                old_dual_value
                + sigma
                * (
                    local_value
                    - global_value
                )
            )

    assert_finite_snapshot(
        result,
        "dual_update",
    )

    return result


# -------------------------------------------------------------------------
# Compatibility aliases for existing runners.
# Global and dual updates use Eq. (9); local shared and particular updates
# use Eq. (10).
# -------------------------------------------------------------------------

global_shared_update_equation_9 = global_shared_update
local_shared_update_equation_10 = local_shared_update
particular_update_equation_10 = particular_update
dual_update_equation_9 = dual_update


def snapshot_l2_norm(
    snapshot: Mapping[str, list],
) -> float:
    squared_sum = 0.0

    for tensors in snapshot.values():
        for tensor in tensors:
            array = np.asarray(
                tensor,
                dtype=np.float64,
            )
            squared_sum += float(
                np.sum(
                    np.square(array)
                )
            )

    return float(
        np.sqrt(squared_sum)
    )


def difference_snapshot(
    first: LayerSnapshot,
    second: LayerSnapshot,
) -> LayerSnapshot:
    assert_same_structure(
        first,
        second,
    )

    return {
        layer_name: [
            first_value - second_value
            for first_value, second_value
            in zip(
                first[layer_name],
                second[layer_name],
            )
        ]
        for layer_name in first
    }


def primal_residual(
    local_shared: Dict[int, LayerSnapshot],
    global_shared: LayerSnapshot,
) -> float:
    squared_sum = 0.0

    for local_snapshot in (
        local_shared.values()
    ):
        difference = (
            difference_snapshot(
                local_snapshot,
                global_shared,
            )
        )

        squared_sum += (
            snapshot_l2_norm(
                difference
            ) ** 2
        )

    return float(
        np.sqrt(squared_sum)
    )


def relative_primal_residual(
    local_shared: Dict[int, LayerSnapshot],
    global_shared: LayerSnapshot,
) -> float:
    numerator = primal_residual(
        local_shared,
        global_shared,
    )

    denominator_sq = 0.0

    for local_snapshot in (
        local_shared.values()
    ):
        denominator_sq += (
            snapshot_l2_norm(
                local_snapshot
            ) ** 2
        )

    return float(
        numerator
        / (
            np.sqrt(denominator_sq)
            + EPSILON
        )
    )


def dual_residual(
    new_global_shared: LayerSnapshot,
    old_global_shared: LayerSnapshot,
    sigma: float,
    num_environments: int,
) -> float:
    difference = difference_snapshot(
        new_global_shared,
        old_global_shared,
    )

    return float(
        sigma
        * np.sqrt(num_environments)
        * snapshot_l2_norm(
            difference
        )
    )


def relative_dual_residual(
    new_global_shared: LayerSnapshot,
    old_global_shared: LayerSnapshot,
    sigma: float,
    num_environments: int,
) -> float:
    numerator = dual_residual(
        new_global_shared,
        old_global_shared,
        sigma,
        num_environments,
    )

    denominator = (
        sigma
        * np.sqrt(num_environments)
        * snapshot_l2_norm(
            old_global_shared
        )
        + EPSILON
    )

    return float(
        numerator / denominator
    )
