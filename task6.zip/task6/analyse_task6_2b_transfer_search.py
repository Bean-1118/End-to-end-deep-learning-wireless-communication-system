from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--top",
        type=int,
        default=10,
    )
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    dataframe = pd.read_csv(args.input)

    columns = [
        "rank",
        "rho",
        "sigma",
        "seed_count",
        "fold_count",
        "mean_zero_shot_ber",
        "mean_adapted_ber",
        "std_adapted_ber",
        "worst_fold_adapted_ber",
        "mean_relative_improvement",
        "positive_improvement_fraction",
        "mean_relative_primal_residual",
        "mean_relative_dual_residual",
    ]

    available = [
        column
        for column in columns
        if column in dataframe.columns
    ]

    print(
        dataframe[available]
        .head(args.top)
        .to_string(index=False)
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
