from __future__ import annotations

import argparse
import csv
import gc
import json
from pathlib import Path

import numpy as np
import tensorflow as tf

from src.base_functions import end_to_end
from src.pdp_profiles import get_known_pdps
from src.task4.checkpoint_utils import restore_task2_checkpoint
from src.task4.fixed_adaptation import (
    iter_fixed_batches,
    make_fixed_adaptation_dataset,
    set_all_seeds,
)
from src.task6.iadmm_state import (
    copy_iadmm_state,
    initialise_iadmm_state,
)
from src.task6.iadmm_trainer import IADMMTrainer
from src.task6.task6_config import Task6Config
from src.task6.task6_evaluation import (
    evaluate_historical_environments,
)
from src.task6.task6_parameter_groups import (
    PARTICULAR_LAYER_NAMES,
    shared_layer_names,
    validate_partition,
)


def write_csv(path: Path, rows) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def next_batch(
    pdp_id,
    iterators,
    datasets,
    iteration,
    seed,
):
    try:
        return next(iterators[pdp_id])
    except StopIteration:
        iterators[pdp_id] = iter(
            iter_fixed_batches(
                dataset=datasets[pdp_id],
                epoch=iteration + 1,
                shuffle_seed=seed + 10000 + pdp_id,
            )
        )
        return next(iterators[pdp_id])


def parse_arguments():
    config = Task6Config()
    parser = argparse.ArgumentParser(
        description=(
            "Task 6.2 validation-based rho/sigma search "
            "on all historical PDP0-PDP5."
        )
    )
    parser.add_argument(
        "--rho-values",
        nargs="+",
        type=float,
        default=[30.0, 50.0, 75.0, 100.0, 150.0, 200.0],
    )
    parser.add_argument(
        "--sigma-values",
        nargs="+",
        type=float,
        default=[3.0, 5.0, 7.5, 10.0, 15.0, 20.0],
    )
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[2026],
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=1000,
    )
    parser.add_argument(
        "--blocks-per-pdp",
        type=int,
        default=config.train_blocks_per_pdp,
    )
    parser.add_argument(
        "--validation-blocks-per-pdp",
        type=int,
        default=config.validation_blocks_per_pdp,
    )
    parser.add_argument(
        "--validation-interval",
        type=int,
        default=config.validation_interval,
    )
    parser.add_argument(
        "--require-sigma-less-than-rho",
        action="store_true",
        default=True,
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=config.output_root / "rho_sigma_search_revised",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    config = Task6Config()
    pdps = get_known_pdps()

    summary_rows = []
    history_rows = []

    for seed in args.seeds:
        for rho in args.rho_values:
            for sigma in args.sigma_values:
                if args.require_sigma_less_than_rho and sigma >= rho:
                    continue

                print("\n" + "=" * 80)
                print(f"seed={seed} | rho={rho} | sigma={sigma}")
                print("=" * 80)

                tf.keras.backend.clear_session()
                gc.collect()
                set_all_seeds(seed)

                model = end_to_end()
                validate_partition(model)

                restored_checkpoint = restore_task2_checkpoint(
                    model=model,
                    checkpoint_dir=(
                        config.checkpoint_root
                        / "model_trained_on_PDP0"
                    ),
                )

                shared_names = shared_layer_names(model)
                state = initialise_iadmm_state(
                    model=model,
                    train_pdp_ids=config.train_pdps,
                    shared_layer_names=shared_names,
                    particular_layer_names=PARTICULAR_LAYER_NAMES,
                )

                trainer = IADMMTrainer(
                    model=model,
                    state=state,
                    train_pdp_ids=config.train_pdps,
                    shared_layer_names=shared_names,
                    particular_layer_names=PARTICULAR_LAYER_NAMES,
                    rho=rho,
                    sigma=sigma,
                )

                training_datasets = {
                    pdp_id: make_fixed_adaptation_dataset(
                        pdp_target=pdps[pdp_id],
                        pdp_id=pdp_id,
                        num_blocks=args.blocks_per_pdp,
                        ebno_linear=config.ebno_linear,
                        seed=seed + pdp_id * 1000,
                    )
                    for pdp_id in config.train_pdps
                }
                validation_datasets = {
                    pdp_id: make_fixed_adaptation_dataset(
                        pdp_target=pdps[pdp_id],
                        pdp_id=pdp_id,
                        num_blocks=args.validation_blocks_per_pdp,
                        ebno_linear=config.ebno_linear,
                        seed=seed + 500000 + pdp_id * 1000,
                    )
                    for pdp_id in config.train_pdps
                }

                iterators = {
                    pdp_id: iter(
                        iter_fixed_batches(
                            dataset=dataset,
                            epoch=0,
                            shuffle_seed=seed + 10000 + pdp_id,
                        )
                    )
                    for pdp_id, dataset in training_datasets.items()
                }

                run_history = []
                best_state = None
                best_key = None
                best_iteration = None
                failed = False

                for iteration in range(args.iterations):
                    batch_by_pdp = {
                        pdp_id: next_batch(
                            pdp_id,
                            iterators,
                            training_datasets,
                            iteration,
                            seed,
                        )
                        for pdp_id in config.train_pdps
                    }

                    try:
                        metrics = trainer.step(
                            batch_by_pdp=batch_by_pdp,
                            iteration=iteration,
                        )
                    except (FloatingPointError, RuntimeError) as exc:
                        failed = True
                        print(f"FAILED: {exc}")
                        break

                    numeric_values = [
                        metrics["mean_loss"],
                        metrics["mean_ber"],
                        metrics["primal_residual"],
                        metrics["dual_residual"],
                        metrics["relative_primal_residual"],
                        metrics["relative_dual_residual"],
                    ]
                    if not np.all(np.isfinite(numeric_values)):
                        failed = True
                        print("FAILED: non-finite metric.")
                        break

                    row = {
                        "seed": seed,
                        "rho": rho,
                        "sigma": sigma,
                        "iteration": iteration + 1,
                        "mean_training_loss": metrics["mean_loss"],
                        "mean_training_ber": metrics["mean_ber"],
                        "maximum_training_ber": metrics["maximum_ber"],
                        "primal_residual": metrics["primal_residual"],
                        "dual_residual": metrics["dual_residual"],
                        "relative_primal_residual": metrics[
                            "relative_primal_residual"
                        ],
                        "relative_dual_residual": metrics[
                            "relative_dual_residual"
                        ],
                        "mean_shared_gradient_l2": metrics[
                            "mean_shared_gradient_l2"
                        ],
                        "mean_particular_gradient_l2": metrics[
                            "mean_particular_gradient_l2"
                        ],
                        "mean_local_shared_update_l2": metrics[
                            "mean_local_shared_update_l2"
                        ],
                        "mean_particular_update_l2": metrics[
                            "mean_particular_update_l2"
                        ],
                    }

                    should_validate = (
                        iteration == 0
                        or (iteration + 1) % args.validation_interval == 0
                        or iteration + 1 == args.iterations
                    )

                    if should_validate:
                        validation_by_pdp = (
                            evaluate_historical_environments(
                                model=model,
                                datasets_by_pdp=validation_datasets,
                                shared_weights=trainer.state.global_shared,
                                particular_by_pdp=trainer.state.particular,
                            )
                        )
                        values = list(validation_by_pdp.values())
                        mean_validation_ber = float(np.mean(values))
                        maximum_validation_ber = float(np.max(values))

                        row["mean_validation_ber"] = mean_validation_ber
                        row["maximum_validation_ber"] = maximum_validation_ber
                        for pdp_id, ber in validation_by_pdp.items():
                            row[f"PDP{pdp_id}_validation_ber"] = ber

                        candidate_key = (
                            mean_validation_ber,
                            maximum_validation_ber,
                            metrics["relative_primal_residual"],
                            metrics["relative_dual_residual"],
                        )
                        if best_key is None or candidate_key < best_key:
                            best_key = candidate_key
                            best_iteration = iteration + 1
                            best_state = copy_iadmm_state(trainer.state)

                        print(
                            f"iter={iteration + 1}/{args.iterations} | "
                            f"val={mean_validation_ber:.6f} | "
                            f"max={maximum_validation_ber:.6f} | "
                            f"r_rel={metrics['relative_primal_residual']:.3e} | "
                            f"s_rel={metrics['relative_dual_residual']:.3e}"
                        )

                    run_history.append(row)
                    history_rows.append(row)

                run_dir = (
                    args.output_root
                    / f"rho{rho:g}_sigma{sigma:g}"
                    / f"seed_{seed}"
                )
                write_csv(
                    run_dir / "search_history.csv",
                    run_history,
                )

                if failed or best_state is None:
                    summary_rows.append({
                        "seed": seed,
                        "rho": rho,
                        "sigma": sigma,
                        "failed": 1,
                    })
                    continue

                summary_rows.append({
                    "seed": seed,
                    "rho": rho,
                    "sigma": sigma,
                    "failed": 0,
                    "best_iteration": best_iteration,
                    "best_mean_validation_ber": best_key[0],
                    "best_maximum_validation_ber": best_key[1],
                    "best_relative_primal_residual": best_key[2],
                    "best_relative_dual_residual": best_key[3],
                    "restored_checkpoint": str(restored_checkpoint),
                })

                write_csv(
                    args.output_root / "search_summary_partial.csv",
                    summary_rows,
                )

    write_csv(
        args.output_root / "search_history.csv",
        history_rows,
    )
    write_csv(
        args.output_root / "search_summary.csv",
        summary_rows,
    )

    valid = [row for row in summary_rows if row.get("failed") == 0]
    if not valid:
        raise RuntimeError("Every rho/sigma combination failed.")

    grouped = {}
    for row in valid:
        key = (row["rho"], row["sigma"])
        grouped.setdefault(key, []).append(row)

    ranked = []
    for (rho, sigma), rows in grouped.items():
        ranked.append({
            "rho": rho,
            "sigma": sigma,
            "seed_count": len(rows),
            "mean_best_validation_ber": float(np.mean([
                row["best_mean_validation_ber"] for row in rows
            ])),
            "mean_best_maximum_validation_ber": float(np.mean([
                row["best_maximum_validation_ber"] for row in rows
            ])),
            "mean_best_relative_primal_residual": float(np.mean([
                row["best_relative_primal_residual"] for row in rows
            ])),
            "mean_best_relative_dual_residual": float(np.mean([
                row["best_relative_dual_residual"] for row in rows
            ])),
        })

    ranked.sort(
        key=lambda row: (
            row["mean_best_validation_ber"],
            row["mean_best_maximum_validation_ber"],
            row["mean_best_relative_primal_residual"],
            row["mean_best_relative_dual_residual"],
        )
    )

    write_csv(
        args.output_root / "rho_sigma_ranked_summary.csv",
        ranked,
    )

    best = ranked[0]
    (
        args.output_root / "selected_hyperparameters.json"
    ).write_text(
        json.dumps(
            {
                "rho": best["rho"],
                "sigma": best["sigma"],
                "selection_rule": (
                    "validation BER, worst-PDP validation BER, "
                    "relative primal residual, relative dual residual"
                ),
                "warning": (
                    "This search is stochastic mini-batch iADMM and "
                    "must be confirmed with three seeds before Task 7."
                ),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nSelected provisional values:")
    print(f"rho={best['rho']}, sigma={best['sigma']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
