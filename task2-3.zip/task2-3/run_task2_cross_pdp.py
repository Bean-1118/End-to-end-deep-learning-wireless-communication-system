import os
import random
import gc
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

from src.base_functions import len_h
from src.pdp_profiles import get_known_pdps
from src.train_eval import (
    train_model_on_pdp,
    evaluate_ber_single_ebno,
)


def setup_gpu():
    gpus = tf.config.list_physical_devices("GPU")

    for gpu in gpus:
        tf.config.experimental.set_memory_growth(gpu, True)

    print("GPUs:", gpus)


def plot_ber_matrix(
    ber_matrix,
    ebno_linear,
    save_path,
):
    num_envs = ber_matrix.shape[0]

    # Convert linear Eb/N0 to dB only for display.
    ebno_db = 10.0 * np.log10(ebno_linear)

    plt.figure(figsize=(8, 6))

    image = plt.imshow(
        ber_matrix,
        aspect="auto",
    )

    plt.colorbar(
        image,
        label="BER",
    )

    plt.xlabel("Test PDP")
    plt.ylabel("Training PDP")

    plt.title(
        f"Cross-PDP BER Matrix at "
        f"Eb/N0 = {ebno_linear:g} linear "
        f"({ebno_db:.2f} dB)"
    )

    plt.xticks(
        np.arange(num_envs),
        [f"PDP{i}" for i in range(num_envs)],
    )

    plt.yticks(
        np.arange(num_envs),
        [f"PDP{i}" for i in range(num_envs)],
    )

    for i in range(num_envs):
        for j in range(num_envs):
            plt.text(
                j,
                i,
                f"{ber_matrix[i, j]:.3f}",
                ha="center",
                va="center",
            )

    plt.tight_layout()

    plt.savefig(
        save_path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.show()
    plt.close()


def main():
    setup_gpu()

    os.makedirs(
        "outputs/checkpoints",
        exist_ok=True,
    )

    os.makedirs(
        "outputs/results",
        exist_ok=True,
    )

    os.makedirs(
        "outputs/figures",
        exist_ok=True,
    )

    pdp_list = get_known_pdps(len_h)

    # Direct 8x8 experiment.
    num_envs = 8
    pdp_list = pdp_list[:num_envs]

    # Experiment settings.
    number_steps = 3000
    num_test_batches = 30

    # Eb/N0 is specified in linear scale.
    # The value below is already in linear scale.
    ebno_linear = 20.0

    ebno_db = 10.0 * np.log10(ebno_linear)

    print("\nExperiment configuration")
    print("------------------------")

    print(f"Number of PDP environments: {num_envs}")
    print(f"Training steps per model: {number_steps}")
    print(f"Test batches per PDP pair: {num_test_batches}")
    print(f"Eb/N0 linear: {ebno_linear:g}")
    print(f"Equivalent Eb/N0 in dB: {ebno_db:.2f} dB")

    ber_matrix = np.zeros(
        (num_envs, num_envs),
        dtype=np.float32,
    )

    for train_id, pdp_train in enumerate(pdp_list):
        print("\n==============================")
        print(f"Training model on PDP{train_id}")
        print("==============================")
        model_seed = 12345

        random.seed(model_seed)
        np.random.seed(model_seed)
        tf.random.set_seed(model_seed)

        model, loss_history, ber_history = train_model_on_pdp(
            pdp_train=pdp_train,
            train_id=train_id,
            number_steps=number_steps,
            learning_rate=1e-4,
            ebno_train_linear=ebno_linear,
        )

        # Save training histories.
        np.save(
            f"outputs/results/loss_history_PDP{train_id}.npy",
            loss_history,
        )

        np.save(
            f"outputs/results/train_ber_history_PDP{train_id}.npy",
            ber_history,
        )

        print(
            f"\nTesting model trained on PDP{train_id}"
        )

        for test_id, pdp_test in enumerate(pdp_list):
            ber = evaluate_ber_single_ebno(
                model=model,
                pdp_test=pdp_test,
                ebno_linear=ebno_linear,
                num_test_batches=num_test_batches,
            )

            ber_matrix[train_id, test_id] = ber

            print(
                f"Train PDP{train_id} -> "
                f"Test PDP{test_id} | "
                f"BER at Eb/N0 = {ebno_linear:g} linear "
                f"({ebno_db:.2f} dB) = {ber:.6f}"
            )

        # Save the partial matrix after each training environment.
        np.save(
            "outputs/results/ber_matrix_partial.npy",
            ber_matrix,
        )

        # Save the partial matrix as CSV.
        np.savetxt(
            "outputs/results/ber_matrix_partial.csv",
            ber_matrix,
            delimiter=",",
            fmt="%.8f",
        )

        # Save the model checkpoint.
        checkpoint_dir = (
            f"outputs/checkpoints/"
            f"model_trained_on_PDP{train_id}"
        )

        os.makedirs(
            checkpoint_dir,
            exist_ok=True,
        )

        checkpoint = tf.train.Checkpoint(
            model=model
        )

        checkpoint.save(
            os.path.join(
                checkpoint_dir,
                "ckpt",
            )
        )

        print(
            f"Saved checkpoint for PDP{train_id}"
        )

        # Release model and GPU memory before training the next PDP.
        del model
        tf.keras.backend.clear_session()
        gc.collect()

    # Save final matrix.
    np.save(
        "outputs/results/ber_matrix.npy",
        ber_matrix,
    )

    np.savetxt(
        "outputs/results/ber_matrix.csv",
        ber_matrix,
        delimiter=",",
        fmt="%.8f",
    )

    print("\nFinal BER matrix")
    print("----------------")
    print(ber_matrix)

    plot_ber_matrix(
        ber_matrix=ber_matrix,
        ebno_linear=ebno_linear,
        save_path=(
            "outputs/figures/"
            "cross_pdp_ber_matrix_"
            "ebno_linear_20.png"
        ),
    )


if __name__ == "__main__":
    main()