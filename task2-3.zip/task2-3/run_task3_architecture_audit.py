#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared/Particular architecture audit.

Extract the definitions required by end_to_end(), build the model without running top-level training code, and export layer and parameter summaries.
"""

from __future__ import annotations

import argparse
import ast
import contextlib
import csv
import io
import json
import sys
import traceback
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Global values commonly required by end_to_end().
# AST dependency analysis adds any other required definitions.
PREFERRED_GLOBALS: Set[str] = {
    "M",
    "batch_size",
    "block_length",
    "len_h",
    "len_info",
    "R",
    "EbNo_train",
    "std",
}

# Helper functions used by end_to_end() are included through dependency analysis.
PREFERRED_FUNCTIONS: Set[str] = {
    "end_to_end",
    "convolution",
    "bilinear_mul",
}

# Expected trainable-layer order:
# Encoder: 4 x Conv1D
# Channel feature extractor: 5 x Conv1D + 2 x Dense
# Decoder: 9 x Conv1D
EXPECTED_TRAINABLE_LAYOUT = {
    "encoder_conv_count": 4,
    "channel_extractor_conv_count": 5,
    "channel_extractor_dense_count": 2,
}


# ---------------------------------------------------------------------------
# AST model extraction without top-level training
# ---------------------------------------------------------------------------

def collect_top_level_definitions(tree: ast.Module) -> Tuple[
    Dict[str, ast.FunctionDef],
    Dict[str, ast.AsyncFunctionDef],
    Dict[str, ast.ClassDef],
    Dict[str, ast.AST],
]:
    """Collect top-level functions, classes and assignments."""
    functions: Dict[str, ast.FunctionDef] = {}
    async_functions: Dict[str, ast.AsyncFunctionDef] = {}
    classes: Dict[str, ast.ClassDef] = {}
    assignments: Dict[str, ast.AST] = {}

    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            functions[node.name] = node
        elif isinstance(node, ast.AsyncFunctionDef):
            async_functions[node.name] = node
        elif isinstance(node, ast.ClassDef):
            classes[node.name] = node
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            names = assigned_names(node)
            for name in names:
                assignments[name] = node

    return functions, async_functions, classes, assignments


def assigned_names(node: ast.AST) -> Set[str]:
    """Return names defined by a top-level assignment."""
    names: Set[str] = set()

    def visit_target(target: ast.AST) -> None:
        if isinstance(target, ast.Name):
            names.add(target.id)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for elt in target.elts:
                visit_target(elt)

    if isinstance(node, ast.Assign):
        for target in node.targets:
            visit_target(target)
    elif isinstance(node, ast.AnnAssign):
        visit_target(node.target)

    return names


def loaded_names(node: ast.AST) -> Set[str]:
    """Return names loaded within an AST node."""
    result: Set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            result.add(child.id)
    return result


def imported_names(tree: ast.Module) -> Set[str]:
    """Return names introduced by import statements."""
    result: Set[str] = set()
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                result.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    # Wildcard imports cannot be resolved statically.
                    continue
                result.add(alias.asname or alias.name)
    return result


def dependency_closure(
    root_names: Iterable[str],
    functions: Dict[str, ast.FunctionDef],
    async_functions: Dict[str, ast.AsyncFunctionDef],
    classes: Dict[str, ast.ClassDef],
    assignments: Dict[str, ast.AST],
    imports: Set[str],
) -> Set[str]:
    """Find custom functions, classes and global values required by the requested roots."""
    required: Set[str] = set(root_names)
    queue: List[str] = list(root_names)

    known_defs = set(functions) | set(async_functions) | set(classes) | set(assignments)

    while queue:
        name = queue.pop()
        node: Optional[ast.AST] = None
        if name in functions:
            node = functions[name]
        elif name in async_functions:
            node = async_functions[name]
        elif name in classes:
            node = classes[name]
        elif name in assignments:
            node = assignments[name]

        if node is None:
            continue

        for dep in loaded_names(node):
            if dep in imports:
                continue
            if dep in known_defs and dep not in required:
                required.add(dep)
                queue.append(dep)

    return required


def build_safe_module_ast(source_text: str, source_path: Path) -> ast.Module:
    """Build an AST containing imports and definitions required to construct end_to_end(), while excluding unrelated top-level training and data-generation code."""
    tree = ast.parse(source_text, filename=str(source_path))
    functions, async_functions, classes, assignments = collect_top_level_definitions(tree)
    imports = imported_names(tree)

    if "end_to_end" not in functions:
        raise RuntimeError(
            f"在 {source_path.name} 中没有找到顶层函数 end_to_end()。"
        )

    required = dependency_closure(
        root_names={"end_to_end"} | PREFERRED_FUNCTIONS | PREFERRED_GLOBALS,
        functions=functions,
        async_functions=async_functions,
        classes=classes,
        assignments=assignments,
        imports=imports,
    )

    safe_body: List[ast.stmt] = []

    # Keep the module docstring when present.
    if (
        tree.body
        and isinstance(tree.body[0], ast.Expr)
        and isinstance(tree.body[0].value, ast.Constant)
        and isinstance(tree.body[0].value.value, str)
    ):
        safe_body.append(tree.body[0])

    # Keep imports required by the extracted model definition.
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            safe_body.append(node)

    # Keep required definitions in source order.
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = getattr(node, "name", None)
            if name in required:
                safe_body.append(node)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            names = assigned_names(node)
            if names & required:
                # Keep required top-level assignments.
                # Examples include M=128, block_length=M and std=np.sqrt(...).
                # Unrelated data-generation assignments are excluded.
                safe_body.append(node)

    module = ast.Module(body=safe_body, type_ignores=[])
    ast.fix_missing_locations(module)
    return module


def load_model_without_training(source_path: Path):
    """Build the model without executing top-level training logic."""
    source_text = source_path.read_text(encoding="utf-8")
    safe_ast = build_safe_module_ast(source_text, source_path)

    namespace: Dict[str, Any] = {
        "__name__": "__task1_model_audit__",
        "__file__": str(source_path),
    }

    compiled = compile(safe_ast, filename=str(source_path), mode="exec")
    exec(compiled, namespace, namespace)

    end_to_end = namespace.get("end_to_end")
    if not callable(end_to_end):
        raise RuntimeError("安全加载后没有得到可调用的 end_to_end()。")

    model = end_to_end()
    return model, namespace, safe_ast


# ---------------------------------------------------------------------------
# Model structure analysis
# ---------------------------------------------------------------------------

def safe_shape(value: Any) -> str:
    """Convert a Tensor or KerasTensor shape to text."""
    try:
        shape = value.shape
        return str(tuple(dim if dim is not None else None for dim in shape))
    except Exception:
        try:
            return str(value)
        except Exception:
            return "N/A"


def layer_input_shape(layer: Any) -> str:
    try:
        value = layer.input
        if isinstance(value, (list, tuple)):
            return " | ".join(safe_shape(v) for v in value)
        return safe_shape(value)
    except Exception:
        return "N/A"


def layer_output_shape(layer: Any) -> str:
    try:
        value = layer.output
        if isinstance(value, (list, tuple)):
            return " | ".join(safe_shape(v) for v in value)
        return safe_shape(value)
    except Exception:
        return "N/A"


def count_trainable_params(layer: Any) -> int:
    total = 0
    for weight in getattr(layer, "trainable_weights", []):
        try:
            size = 1
            for dim in weight.shape:
                size *= int(dim)
            total += size
        except Exception:
            pass
    return total


def count_non_trainable_params(layer: Any) -> int:
    total = 0
    for weight in getattr(layer, "non_trainable_weights", []):
        try:
            size = 1
            for dim in weight.shape:
                size *= int(dim)
            total += size
        except Exception:
            pass
    return total


def classify_trainable_layers(model: Any) -> Dict[int, Dict[str, str]]:
    """Classify trainable layers by their creation order in the network."""
    classification: Dict[int, Dict[str, str]] = {}

    conv_index = 0
    dense_index = 0

    for layer in model.layers:
        cls_name = layer.__class__.__name__

        if cls_name == "Conv1D":
            conv_index += 1
            if conv_index <= EXPECTED_TRAINABLE_LAYOUT["encoder_conv_count"]:
                module = "Encoder / Transmitter"
                role = f"Encoder Conv1D #{conv_index}"
                hypothesis = (
                    "Shared-leaning"
                    if conv_index <= 3
                    else "Uncertain: transmitted waveform may adapt to PDP"
                )
            elif conv_index <= (
                EXPECTED_TRAINABLE_LAYOUT["encoder_conv_count"]
                + EXPECTED_TRAINABLE_LAYOUT["channel_extractor_conv_count"]
            ):
                ce_idx = conv_index - EXPECTED_TRAINABLE_LAYOUT["encoder_conv_count"]
                module = "Channel feature extractor"
                role = f"Channel-extractor Conv1D #{ce_idx}"
                hypothesis = (
                    "Particular-leaning: directly processes received channel observations"
                )
            else:
                rx_idx = conv_index - (
                    EXPECTED_TRAINABLE_LAYOUT["encoder_conv_count"]
                    + EXPECTED_TRAINABLE_LAYOUT["channel_extractor_conv_count"]
                )
                module = "Decoder / Data recovery"
                role = f"Decoder Conv1D #{rx_idx}"
                if rx_idx == 1:
                    hypothesis = (
                        "Uncertain: directly interprets channel-conditioned bilinear features"
                    )
                elif rx_idx >= 8:
                    hypothesis = (
                        "Shared-leaning: final bit reconstruction/decision"
                    )
                else:
                    hypothesis = (
                        "Mixed: general recovery plus possible PDP-dependent equalisation"
                    )

            classification[id(layer)] = {
                "module": module,
                "role": role,
                "hypothesis": hypothesis,
            }

        elif cls_name == "Dense":
            dense_index += 1
            module = "Channel feature extractor"
            role = (
                "Channel feature bottleneck Dense"
                if dense_index == 1
                else "40-D estimated-channel feature output"
            )
            hypothesis = (
                "Strong particular candidate: maps observations into environment-sensitive "
                "channel representation"
            )
            classification[id(layer)] = {
                "module": module,
                "role": role,
                "hypothesis": hypothesis,
            }

    return classification


def classify_non_trainable_layer(layer: Any) -> Tuple[str, str, str]:
    """Assign a functional group to non-trainable layers and operations."""
    name = getattr(layer, "name", "")
    cls_name = layer.__class__.__name__
    lname = name.lower()

    if cls_name == "InputLayer":
        return "Model interface", "External model input", "Not classified"

    if any(token in lname for token in ("random", "noise")):
        return (
            "Wireless channel / noise",
            "AWGN generation or injection",
            "Environment operation; no trainable parameters",
        )

    if any(token in lname for token in ("matmul", "bilinear")):
        return (
            "Bilinear fusion",
            "Combines received samples with global channel feature",
            "No trainable parameters",
        )

    if any(token in lname for token in ("pad", "concat", "reshape", "strided_slice")):
        return (
            "Tensor operation",
            "Shape alignment / complex-signal processing",
            "No trainable parameters",
        )

    if any(token in lname for token in ("sigmoid",)):
        return (
            "Output decision",
            "Converts logits to bit probabilities",
            "Shared-leaning; no trainable parameters",
        )

    if any(token in lname for token in ("add",)):
        return (
            "Residual / arithmetic operation",
            "Residual connection or channel arithmetic",
            "No trainable parameters",
        )

    return (
        "TensorFlow operation",
        cls_name,
        "No direct shared/particular parameter classification",
    )


def audit_layers(model: Any) -> List[Dict[str, Any]]:
    trainable_map = classify_trainable_layers(model)
    rows: List[Dict[str, Any]] = []

    for index, layer in enumerate(model.layers):
        total_params = int(layer.count_params())
        trainable_params = count_trainable_params(layer)
        non_trainable_params = count_non_trainable_params(layer)

        if id(layer) in trainable_map:
            info = trainable_map[id(layer)]
            module = info["module"]
            role = info["role"]
            hypothesis = info["hypothesis"]
        else:
            module, role, hypothesis = classify_non_trainable_layer(layer)

        rows.append(
            {
                "index": index,
                "layer_name": getattr(layer, "name", f"layer_{index}"),
                "layer_type": layer.__class__.__name__,
                "input_shape": layer_input_shape(layer),
                "output_shape": layer_output_shape(layer),
                "total_params": total_params,
                "trainable_params": trainable_params,
                "non_trainable_params": non_trainable_params,
                "layer_trainable_flag": bool(getattr(layer, "trainable", False)),
                "functional_module": module,
                "interpreted_role": role,
                "shared_particular_hypothesis": hypothesis,
            }
        )

    return rows


def module_summary(layer_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    agg: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: {
            "layer_count": 0,
            "parameterised_layer_count": 0,
            "total_params": 0,
            "trainable_params": 0,
            "non_trainable_params": 0,
        }
    )

    for row in layer_rows:
        module = str(row["functional_module"])
        agg[module]["layer_count"] += 1
        if int(row["total_params"]) > 0:
            agg[module]["parameterised_layer_count"] += 1
        agg[module]["total_params"] += int(row["total_params"])
        agg[module]["trainable_params"] += int(row["trainable_params"])
        agg[module]["non_trainable_params"] += int(row["non_trainable_params"])

    total_model_params = sum(
        values["total_params"] for values in agg.values()
    )

    result: List[Dict[str, Any]] = []
    for module, values in agg.items():
        total = values["total_params"]
        result.append(
            {
                "functional_module": module,
                **values,
                "percentage_of_model_params": (
                    100.0 * total / total_model_params
                    if total_model_params > 0
                    else 0.0
                ),
            }
        )

    result.sort(key=lambda x: x["total_params"], reverse=True)
    return result



# ---------------------------------------------------------------------------
# Parameter sensitivity ranking
# ---------------------------------------------------------------------------

def build_parameter_sensitivity_ranking(
    layer_rows: Sequence[Dict[str, Any]],
    model_total_params: int,
) -> List[Dict[str, Any]]:
    """Rank parameter groups using architecture-based scores.
    
        The ranking is heuristic rather than an empirical sensitivity measurement. Scores combine PDP dependence, parameter efficiency and proximity to the channel representation.
    """
    groups = [
        {
            "component": "Channel extractor Dense head",
            "layer_names": {"channel_est_dense_1", "estimated_channel"},
            "pdp_dependence_score": 5,
            "representation_proximity_score": 5,
            "rationale": (
                "Directly maps the extracted received-signal features into the "
                "40-dimensional latent channel representation; strongest "
                "environment-specific candidate."
            ),
            "recommended_experiment": (
                "First adaptation experiment: freeze all other layers and "
                "fine-tune channel_est_dense_1 + estimated_channel."
            ),
        },
        {
            "component": "Channel extractor convolutional backbone",
            "layer_names": {
                "channel_est_conv_1",
                "channel_est_conv_2",
                "channel_est_conv_3",
                "channel_est_conv_4",
                "channel_est_conv_5",
            },
            "pdp_dependence_score": 4,
            "representation_proximity_score": 4,
            "rationale": (
                "Directly processes the noisy channel output and likely captures "
                "multipath patterns, although early convolutional features may "
                "remain transferable across PDPs."
            ),
            "recommended_experiment": (
                "Compare against Dense-head-only adaptation to test whether "
                "early channel-observation features also require updating."
            ),
        },
        {
            "component": "Decoder early channel-conditioned layer",
            "layer_names": {"decoder_conv_1"},
            "pdp_dependence_score": 4,
            "representation_proximity_score": 4,
            "rationale": (
                "Immediately consumes the bilinear combination of received "
                "samples and estimated channel features, so it may be sensitive "
                "to a mismatched channel representation."
            ),
            "recommended_experiment": (
                "Fine-tune decoder_conv_1 alone after the channel-head tests."
            ),
        },
        {
            "component": "Encoder waveform output",
            "layer_names": {"encoder_conv_4"},
            "pdp_dependence_score": 3,
            "representation_proximity_score": 2,
            "rationale": (
                "Produces the two-channel transmitted waveform. It may adapt to "
                "the training PDP, but contains very few parameters."
            ),
            "recommended_experiment": (
                "Optional small-parameter ablation: adapt encoder_conv_4 only."
            ),
        },
        {
            "component": "Decoder residual recovery backbone",
            "layer_names": {
                "decoder_res1_input",
                "decoder_res1_conv1",
                "decoder_res1_conv2",
                "decoder_res2_input",
                "decoder_res2_conv1",
                "decoder_res2_conv2",
            },
            "pdp_dependence_score": 3,
            "representation_proximity_score": 3,
            "rationale": (
                "Performs most of the nonlinear signal recovery. It may combine "
                "general decoding knowledge with PDP-dependent equalisation, but "
                "contains a large fraction of the total parameters."
            ),
            "recommended_experiment": (
                "Use as a later comparison, not the first few-shot candidate, "
                "because of its high parameter cost."
            ),
        },
        {
            "component": "Encoder early backbone",
            "layer_names": {
                "encoder_conv_1",
                "encoder_conv_2",
                "encoder_conv_3",
            },
            "pdp_dependence_score": 2,
            "representation_proximity_score": 1,
            "rationale": (
                "Primarily forms a general bit-to-waveform representation and is "
                "far from the target channel representation."
            ),
            "recommended_experiment": (
                "Keep frozen in initial transfer experiments; test only as part "
                "of full-model fine-tuning."
            ),
        },
        {
            "component": "Decoder final decision head",
            "layer_names": {"decoder_conv_final", "pred_logits_full"},
            "pdp_dependence_score": 2,
            "representation_proximity_score": 2,
            "rationale": (
                "Maps recovered features to bit logits. It is close to the output "
                "but not necessarily close to PDP-specific channel statistics."
            ),
            "recommended_experiment": (
                "Low-cost control experiment: adapt final decision head only."
            ),
        },
    ]

    rows_by_name = {
        str(row["layer_name"]): row
        for row in layer_rows
    }

    ranking: List[Dict[str, Any]] = []

    for group in groups:
        selected = [
            rows_by_name[name]
            for name in group["layer_names"]
            if name in rows_by_name
        ]

        params = sum(int(row["total_params"]) for row in selected)
        model_share = (
            100.0 * params / model_total_params
            if model_total_params > 0
            else 0.0
        )

        # Smaller parameter groups receive higher efficiency scores.
        if model_share <= 1.0:
            efficiency = 5
        elif model_share <= 6.0:
            efficiency = 5
        elif model_share <= 15.0:
            efficiency = 4
        elif model_share <= 25.0:
            efficiency = 3
        elif model_share <= 45.0:
            efficiency = 2
        else:
            efficiency = 1

        pdp_score = int(group["pdp_dependence_score"])
        proximity_score = int(group["representation_proximity_score"])

        priority_score = (
            0.50 * pdp_score
            + 0.30 * efficiency
            + 0.20 * proximity_score
        )

        ranking.append(
            {
                "component": group["component"],
                "included_layers": ", ".join(
                    sorted(row["layer_name"] for row in selected)
                ),
                "parameters": params,
                "percentage_of_model_params": model_share,
                "pdp_dependence_score_1_to_5": pdp_score,
                "parameter_efficiency_score_1_to_5": efficiency,
                "representation_proximity_score_1_to_5": proximity_score,
                "adaptation_priority_score_1_to_5": priority_score,
                "hypothesis_level": (
                    "Very high"
                    if priority_score >= 4.5
                    else "High"
                    if priority_score >= 3.8
                    else "Medium"
                    if priority_score >= 3.0
                    else "Low"
                ),
                "research_rationale": group["rationale"],
                "recommended_next_experiment": group["recommended_experiment"],
                "evidence_status": (
                    "Architecture-based hypothesis; requires empirical "
                    "cross-PDP freezing/fine-tuning validation"
                ),
            }
        )

    ranking.sort(
        key=lambda row: (
            float(row["adaptation_priority_score_1_to_5"]),
            -int(row["parameters"]),
        ),
        reverse=True,
    )

    for index, row in enumerate(ranking, start=1):
        row["rank"] = index

    # Put rank in the first column.
    return [
        {"rank": row.pop("rank"), **row}
        for row in ranking
    ]


def write_parameter_sensitivity_report(
    path: Path,
    ranking_rows: Sequence[Dict[str, Any]],
) -> None:
    lines = [
        "Task 3 — Parameter Sensitivity Ranking\n",
        "======================================\n\n",
        "Interpretation\n",
        "--------------\n",
        "This is an architecture-based adaptation-priority hypothesis, not an\n",
        "empirically measured sensitivity result. The ranking is intended to\n",
        "decide which parameter subsets should be tested first in the next\n",
        "cross-PDP freezing/fine-tuning experiment.\n\n",
        "Scoring\n",
        "-------\n",
        "Priority = 0.50 × PDP dependence + 0.30 × parameter efficiency\n",
        "         + 0.20 × proximity to the latent channel representation.\n\n",
    ]

    for row in ranking_rows:
        lines.extend(
            [
                f"Rank {row['rank']}: {row['component']}\n",
                "-" * (8 + len(str(row["rank"])) + len(row["component"])) + "\n",
                f"Layers: {row['included_layers']}\n",
                f"Parameters: {int(row['parameters']):,} "
                f"({float(row['percentage_of_model_params']):.2f}% of model)\n",
                f"PDP dependence: {row['pdp_dependence_score_1_to_5']}/5\n",
                f"Parameter efficiency: "
                f"{row['parameter_efficiency_score_1_to_5']}/5\n",
                f"Representation proximity: "
                f"{row['representation_proximity_score_1_to_5']}/5\n",
                f"Priority score: "
                f"{float(row['adaptation_priority_score_1_to_5']):.2f}/5 "
                f"({row['hypothesis_level']})\n",
                f"Rationale: {row['research_rationale']}\n",
                f"Recommended experiment: "
                f"{row['recommended_next_experiment']}\n",
                f"Evidence status: {row['evidence_status']}\n\n",
            ]
        )

    lines.extend(
        [
            "Recommended experimental order\n",
            "------------------------------\n",
            "1. Channel extractor Dense head only.\n",
            "2. Entire channel feature extractor.\n",
            "3. Decoder early channel-conditioned layer.\n",
            "4. Final decision head and encoder waveform output as lightweight controls.\n",
            "5. Decoder recovery backbone.\n",
            "6. Full-model fine-tuning and target-PDP training from scratch as references.\n",
        ]
    )

    path.write_text("".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# Output files
# ---------------------------------------------------------------------------

def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: Any) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def capture_model_summary(model: Any) -> str:
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        model.summary()
    return buffer.getvalue()


def format_parameter_table(rows: Sequence[Dict[str, Any]]) -> str:
    header = (
        f"{'Module':36s} {'Layers':>8s} {'Param layers':>13s} "
        f"{'Parameters':>14s} {'Share':>9s}\n"
    )
    divider = "-" * 86 + "\n"
    lines = [header, divider]
    for row in rows:
        lines.append(
            f"{str(row['functional_module'])[:36]:36s} "
            f"{int(row['layer_count']):8d} "
            f"{int(row['parameterised_layer_count']):13d} "
            f"{int(row['total_params']):14,d} "
            f"{float(row['percentage_of_model_params']):8.2f}%\n"
        )
    return "".join(lines)


def write_candidate_splits(path: Path, module_rows: Sequence[Dict[str, Any]]) -> None:
    text = """Task 3: Shared / Particular Candidate Splits
================================================

Important interpretation
------------------------
The following are hypotheses for Task 2 experiments, not final conclusions.
A layer is not classified as particular merely because it is near the output.
The functional dependence on the PDP and the number of adaptation parameters
must both be considered.

Candidate A — Functional module split
-------------------------------------
Shared:
- Encoder / transmitter
- Decoder / data-recovery network

Particular:
- Entire channel feature extractor

Research rationale:
The channel feature extractor directly maps noisy received samples into a
global latent channel representation, so it is the strongest PDP-specific
candidate.

Risk:
The whole extractor may contain too many parameters for stable few-shot
adaptation, and its early convolutions may still learn reusable channel
observation features.


Candidate B — Channel-feature head split
----------------------------------------
Shared:
- Encoder / transmitter
- Channel-extractor convolutional backbone
- Decoder / data-recovery network

Particular:
- Channel-extractor Dense bottleneck
- Final 40-dimensional estimated-channel feature layer

Research rationale:
The convolutional part may learn general ways of detecting multipath/channel
patterns, while the Dense head may encode how these observations are mapped
into a representation suited to one PDP family.

Expected advantage:
Far fewer adaptation parameters than retraining the complete extractor.


Candidate C — Shared backbone plus lightweight adapters
-------------------------------------------------------
Shared:
- Existing encoder, channel extractor and decoder backbone

Particular:
- Newly added small scale/shift parameters or adapter layers

Research rationale:
This is closest to the few-shot shared/particular framework. The main network
retains transferable communication knowledge, while a small environment-
specific parameter set adapts to the target PDP.

Risk:
It requires an architectural change and should normally be attempted only
after Candidates A and B establish where mismatch-sensitive representations
are concentrated.


Suggested Task 2 controls
-------------------------
For the same source model and target PDP, compare:
1. No adaptation.
2. Fine-tune channel-feature Dense head only.
3. Fine-tune entire channel feature extractor.
4. Fine-tune decoder only.
5. Fine-tune all trainable layers.
6. Train from scratch on the target PDP as an upper-reference baseline.

Keep constant:
- Target adaptation sample count.
- Optimiser and learning-rate policy.
- Number of adaptation updates.
- Test PDP and independent channel realisations.
- SNR evaluation grid.
- Random seeds or repeated-run protocol.

Primary evidence:
- Target BER after adaptation.
- Number and percentage of updated parameters.
- Adaptation sample count.
- Convergence speed.
- Mean and standard deviation across repeated runs.
"""
    path.write_text(text, encoding="utf-8")


def write_research_note(
    path: Path,
    source_path: Path,
    model: Any,
    namespace: Dict[str, Any],
    module_rows: Sequence[Dict[str, Any]],
) -> None:
    important_globals = {
        key: namespace.get(key)
        for key in sorted(PREFERRED_GLOBALS)
        if key in namespace
    }

    text = f"""Task 3 Architecture Audit — Research Note
=========================================

Source code
-----------
{source_path.resolve()}

Model
-----
Name: {getattr(model, 'name', 'N/A')}
Inputs: {getattr(model, 'inputs', 'N/A')}
Outputs: {getattr(model, 'outputs', 'N/A')}
Total parameters: {model.count_params():,}

Recovered global configuration
------------------------------
{json.dumps(important_globals, ensure_ascii=False, indent=2, default=str)}

Current training interpretation
-------------------------------
The original training code updates model.trainable_variables, therefore the
baseline does not explicitly separate shared and particular parameters.
Encoder, channel-feature extractor and decoder parameters are jointly trained
for the selected training PDP.

Task 3 research question
------------------------
Which parts of the current end-to-end receiver learn transferable
environment-invariant communication knowledge, and which parts capture
PDP-specific channel statistics?

Initial hypothesis
------------------
The channel feature extractor, especially its Dense feature head, is the
strongest particular-parameter candidate because it directly converts global
received-signal observations into a latent channel representation.

However, this is not yet a conclusion. The early feature-extraction layers may
learn reusable multipath-observation features, while PDP dependence may be
concentrated in the later mapping layers. Controlled target-environment
freezing/fine-tuning experiments are required.

Module parameter table
----------------------
{format_parameter_table(module_rows)}

Deliverables generated by this script
-------------------------------------
- model_summary.txt
- layer_audit.csv
- layer_audit.json
- module_summary.csv
- module_summary.json
- candidate_splits.txt
- research_note.txt
- task3_parameter_sensitivity_ranking.csv
- task3_parameter_sensitivity_ranking.json
- task3_parameter_sensitivity_ranking.txt
- model_architecture.png, when Graphviz/pydot are available
"""
    path.write_text(text, encoding="utf-8")


def try_plot_model(model: Any, output_path: Path) -> Tuple[bool, str]:
    try:
        import tensorflow as tf

        tf.keras.utils.plot_model(
            model,
            to_file=str(output_path),
            show_shapes=True,
            show_layer_names=True,
            show_dtype=False,
            show_layer_activations=True,
            expand_nested=True,
            dpi=160,
        )
        return True, f"网络图已生成：{output_path.name}"
    except Exception as exc:
        return (
            False,
            "未生成网络图。通常是未安装 Graphviz/pydot；"
            f"其余分析结果不受影响。原因：{exc}",
        )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "在不执行原始训练循环的情况下，审查学长端到端模型的网络结构。"
        )
    )
    parser.add_argument(
        "--source",
        required=False,
        type=Path,
        default=Path(__file__).resolve().parents[1] / "src" / "base_functions.py",
        help="包含 end_to_end() 的模型文件；默认使用 src/base_functions.py。",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "outputs" / "task3_architecture_audit",
        help="输出目录，默认：outputs/task3_architecture_audit",
    )
    parser.add_argument(
        "--no-plot",
        action="store_true",
        help="不尝试生成 PNG 网络结构图。",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source_path: Path = args.source.expanduser().resolve()
    out_dir: Path = args.out_dir.expanduser().resolve()

    if not source_path.exists():
        print(f"[ERROR] 找不到原始代码文件：{source_path}", file=sys.stderr)
        return 2

    if source_path.suffix.lower() != ".py":
        print("[ERROR] --source 必须指向 .py 文件。", file=sys.stderr)
        return 2

    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("Task 3 — Shared / Particular Architecture Audit")
    print("=" * 72)
    print(f"原始代码：{source_path}")
    print(f"输出目录：{out_dir}")
    print("正在安全加载模型定义；不会执行原始训练循环……")

    try:
        model, namespace, safe_ast = load_model_without_training(source_path)
    except Exception:
        print("\n[ERROR] 模型构建失败。完整错误如下：", file=sys.stderr)
        traceback.print_exc()
        print(
            "\n常见原因：\n"
            "1. 本地 TensorFlow/Keras 版本与原代码不兼容；\n"
            "2. end_to_end() 依赖了脚本未识别的顶层对象；\n"
            "3. 原代码中的原生 tf 操作在 Keras 3 中不接受 KerasTensor。\n",
            file=sys.stderr,
        )
        return 1

    summary_text = capture_model_summary(model)
    (out_dir / "task3_model_summary.txt").write_text(summary_text, encoding="utf-8")

    layer_rows = audit_layers(model)
    module_rows = module_summary(layer_rows)
    sensitivity_rows = build_parameter_sensitivity_ranking(
        layer_rows,
        model.count_params(),
    )

    write_csv(out_dir / "task3_layer_audit.csv", layer_rows)
    write_json(out_dir / "task3_layer_audit.json", layer_rows)
    write_csv(out_dir / "task3_module_summary.csv", module_rows)
    write_json(out_dir / "task3_module_summary.json", module_rows)
    write_csv(
        out_dir / "task3_parameter_sensitivity_ranking.csv",
        sensitivity_rows,
    )
    write_json(
        out_dir / "task3_parameter_sensitivity_ranking.json",
        sensitivity_rows,
    )
    write_parameter_sensitivity_report(
        out_dir / "task3_parameter_sensitivity_ranking.txt",
        sensitivity_rows,
    )
    write_candidate_splits(out_dir / "task3_candidate_splits.txt", module_rows)
    write_research_note(
        out_dir / "task3_research_note.txt",
        source_path,
        model,
        namespace,
        module_rows,
    )

    # Save the extracted model-only source.
    try:
        extracted_source = ast.unparse(safe_ast)
        (out_dir / "task3_extracted_model_definition_only.py").write_text(
            extracted_source + "\n",
            encoding="utf-8",
        )
    except Exception:
        # Skip source export if AST unparsing is unavailable.
        pass

    plot_message = "已跳过网络图生成。"
    if not args.no_plot:
        _, plot_message = try_plot_model(
            model,
            out_dir / "task3_model_architecture.png",
        )

    print("\n模型构建成功。")
    print(f"模型总参数量：{model.count_params():,}")
    print("\n模块参数统计：")
    print(format_parameter_table(module_rows))
    print(plot_message)

    print("\nParameter Sensitivity Ranking（架构假设）:")
    for row in sensitivity_rows:
        print(
            f"  {row['rank']}. {row['component']}: "
            f"score={row['adaptation_priority_score_1_to_5']:.2f}/5, "
            f"params={row['parameters']:,} "
            f"({row['percentage_of_model_params']:.2f}%)"
        )

    print("\n已生成：")
    for path in sorted(out_dir.iterdir()):
        print(f"  - {path.name}")

    print(
        "\nTask 3 解释：这些结果用于形成 shared/particular 候选假设；"
        "它们不是最终分类结论。最终判断需要由两个 PDP 环境下的"
        "冻结/微调实验验证。"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())