import os
import csv
import random
import numpy as np
import tensorflow as tf

from src.base_functions import (
    end_to_end,
    sample_h_mp,
    batch_size,
    block_length,
    len_h,
    R,
)

from src.pdp_profiles import get_known_pdps


# ============================================================
# Experiment configuration
# ============================================================

# Only test the three rows currently under question.
TRAIN_PDP_IDS = [2, 4, 7]

# Use several independent but reproducible test seeds.
TEST_SEEDS = [101, 202, 303, 404, 505]

# Eb/N0 is specified in linear scale.
# A value of 20 corresponds to about 13.01 dB.
EBNO_LINEAR = 20.0

# Keep the same test size as the previous formal matrix.
NUM_TEST_BATCHES = 30

CHECKPOINT_ROOT = "outputs/checkpoints"

RESULT_CSV = (
    "outputs/results/"
    "seeded_pdp0_vs_matched_results.csv"
)


# ============================================================
# Reproducibility
# ============================================================

def set_all_seeds(seed):
    """
    Reset Python, NumPy and TensorFlow random-number generators.

    By resetting the same seed before testing PDP0 and the matched PDP,
    both tests use the same random test bits and the same underlying
    Gaussian random-number sequences.
    """

    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


# ============================================================
# Checkpoint loading
# ============================================================

def load_trained_model(train_pdp_id):
    """
    Build the current model architecture and restore the saved checkpoint
    for one training PDP.
    """

    checkpoint_dir = os.path.join(
        CHECKPOINT_ROOT,
        f"model_trained_on_PDP{train_pdp_id}",
    )

    latest_checkpoint = tf.train.latest_checkpoint(
        checkpoint_dir
    )

    if latest_checkpoint is None:
        raise FileNotFoundError(
            "\nNo checkpoint was found for "
            f"PDP{train_pdp_id}.\n"
            f"Expected directory:\n{checkpoint_dir}\n"
            "Please check that the earlier 3000-step run saved "
            "its checkpoints successfully."
        )

    model = end_to_end()

    checkpoint = tf.train.Checkpoint(
        model=model
    )

    restore_status = checkpoint.restore(
        latest_checkpoint
    )

    # Check that model variables were restored from the checkpoint.
    restore_status.assert_existing_objects_matched()

    print(
        f"Loaded PDP{train_pdp_id} model from: "
        f"{latest_checkpoint}"
    )

    return model


# ============================================================
# Seeded BER evaluation
# ============================================================

def evaluate_one_seed(
    model,
    pdp_test,
    seed,
    ebno_linear=EBNO_LINEAR,
    num_test_batches=NUM_TEST_BATCHES,
):
    """
    Evaluate one fixed model on one PDP with one reproducible seed.

    No model parameters are updated.
    """

    set_all_seeds(seed)

    noise_std_value = np.float32(
        np.sqrt(
            1.0 / (2.0 * R * ebno_linear)
        )
    )

    total_errors = 0
    total_bits = 0

    for _ in range(num_test_batches):

        test_bits = np.random.binomial(
            n=1,
            p=0.5,
            size=(
                batch_size,
                block_length,
                1,
            ),
        ).astype(np.float32)

        h_test = sample_h_mp(
            (
                batch_size,
                len_h,
                2,
            ),
            pdp_test,
        ).astype(np.float32)

        noise_std = np.full(
            (
                batch_size,
                1,
            ),
            noise_std_value,
            dtype=np.float32,
        )

        _, predicted_probabilities = model(
            [
                test_bits,
                h_test,
                noise_std,
            ],
            training=False,
        )

        predicted_bits = tf.cast(
            predicted_probabilities >= 0.5,
            tf.float32,
        )

        target_bits = tf.convert_to_tensor(
            test_bits,
            dtype=tf.float32,
        )

        batch_errors = tf.reduce_sum(
            tf.cast(
                predicted_bits != target_bits,
                tf.int64,
            )
        )

        total_errors += int(
            batch_errors.numpy()
        )

        total_bits += int(
            np.prod(test_bits.shape)
        )

    return total_errors / total_bits


def evaluate_multiple_seeds(
    model,
    pdp_test,
    seeds,
):
    """
    Evaluate one model/PDP pair over all requested seeds.
    """

    ber_values = []

    for seed in seeds:
        ber = evaluate_one_seed(
            model=model,
            pdp_test=pdp_test,
            seed=seed,
        )

        ber_values.append(ber)

        print(
            f"    Seed {seed}: BER = {ber:.8f}"
        )

    return np.asarray(
        ber_values,
        dtype=np.float64,
    )


# ============================================================
# Result presentation and saving
# ============================================================

def print_comparison(
    train_pdp_id,
    pdp0_results,
    matched_results,
):
    pdp0_mean = float(np.mean(pdp0_results))
    pdp0_std = float(np.std(pdp0_results, ddof=1))

    matched_mean = float(np.mean(matched_results))
    matched_std = float(np.std(matched_results, ddof=1))

    difference = matched_mean - pdp0_mean

    print("\n----------------------------------------")
    print(f"PDP{train_pdp_id}-trained model summary")
    print("----------------------------------------")

    print(
        f"Test PDP0: "
        f"{pdp0_mean:.8f} ± {pdp0_std:.8f}"
    )

    print(
        f"Test PDP{train_pdp_id}: "
        f"{matched_mean:.8f} ± {matched_std:.8f}"
    )

    print(
        "Matched BER - PDP0 BER = "
        f"{difference:+.8f}"
    )

    if matched_mean < pdp0_mean:
        print(
            "Result: matched PDP is better."
        )
    elif matched_mean > pdp0_mean:
        print(
            "Result: PDP0 remains better."
        )
    else:
        print(
            "Result: both means are equal."
        )

    return {
        "train_pdp": train_pdp_id,
        "pdp0_mean": pdp0_mean,
        "pdp0_std": pdp0_std,
        "matched_mean": matched_mean,
        "matched_std": matched_std,
        "matched_minus_pdp0": difference,
    }


def save_results_to_csv(
    detailed_rows,
    summary_rows,
):
    os.makedirs(
        os.path.dirname(RESULT_CSV),
        exist_ok=True,
    )

    with open(
        RESULT_CSV,
        "w",
        newline="",
        encoding="utf-8",
    ) as csv_file:

        fieldnames = [
            "row_type",
            "train_pdp",
            "test_pdp",
            "seed",
            "ber",
            "mean_ber",
            "std_ber",
            "matched_minus_pdp0",
        ]

        writer = csv.DictWriter(
            csv_file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for row in detailed_rows:
            writer.writerow(row)

        for summary in summary_rows:
            writer.writerow(
                {
                    "row_type": "summary_pdp0",
                    "train_pdp":
                        summary["train_pdp"],
                    "test_pdp": 0,
                    "seed": "",
                    "ber": "",
                    "mean_ber":
                        summary["pdp0_mean"],
                    "std_ber":
                        summary["pdp0_std"],
                    "matched_minus_pdp0":
                        summary["matched_minus_pdp0"],
                }
            )

            writer.writerow(
                {
                    "row_type": "summary_matched",
                    "train_pdp":
                        summary["train_pdp"],
                    "test_pdp":
                        summary["train_pdp"],
                    "seed": "",
                    "ber": "",
                    "mean_ber":
                        summary["matched_mean"],
                    "std_ber":
                        summary["matched_std"],
                    "matched_minus_pdp0":
                        summary["matched_minus_pdp0"],
                }
            )

    print(
        f"\nSaved results to:\n{RESULT_CSV}"
    )


# ============================================================
# Main experiment
# ============================================================

def main():
    pdp_list = get_known_pdps(len_h)

    ebno_db = 10.0 * np.log10(
        EBNO_LINEAR
    )

    bits_per_evaluation = (
        NUM_TEST_BATCHES
        * batch_size
        * block_length
    )

    print("\nSeeded PDP0-versus-matched sanity test")
    print("=====================================")
    print(f"Training PDP models: {TRAIN_PDP_IDS}")
    print(f"Seeds: {TEST_SEEDS}")
    print(f"Test batches per seed: {NUM_TEST_BATCHES}")
    print(f"Batch size: {batch_size}")
    print(f"Bits per BER estimate: {bits_per_evaluation:,}")
    print(f"Eb/N0 linear: {EBNO_LINEAR:g}")
    print(f"Equivalent Eb/N0: {ebno_db:.2f} dB")

    detailed_rows = []
    summary_rows = []

    for train_pdp_id in TRAIN_PDP_IDS:

        print("\n========================================")
        print(
            f"Loading model trained on PDP{train_pdp_id}"
        )
        print("========================================")

        model = load_trained_model(
            train_pdp_id
        )

        print(
            f"\nPDP{train_pdp_id}-trained "
            "model tested on PDP0"
        )

        pdp0_results = evaluate_multiple_seeds(
            model=model,
            pdp_test=pdp_list[0],
            seeds=TEST_SEEDS,
        )

        print(
            f"\nPDP{train_pdp_id}-trained "
            f"model tested on matched PDP{train_pdp_id}"
        )

        matched_results = evaluate_multiple_seeds(
            model=model,
            pdp_test=pdp_list[train_pdp_id],
            seeds=TEST_SEEDS,
        )

        for seed, ber in zip(
            TEST_SEEDS,
            pdp0_results,
        ):
            detailed_rows.append(
                {
                    "row_type": "individual",
                    "train_pdp": train_pdp_id,
                    "test_pdp": 0,
                    "seed": seed,
                    "ber": ber,
                    "mean_ber": "",
                    "std_ber": "",
                    "matched_minus_pdp0": "",
                }
            )

        for seed, ber in zip(
            TEST_SEEDS,
            matched_results,
        ):
            detailed_rows.append(
                {
                    "row_type": "individual",
                    "train_pdp": train_pdp_id,
                    "test_pdp": train_pdp_id,
                    "seed": seed,
                    "ber": ber,
                    "mean_ber": "",
                    "std_ber": "",
                    "matched_minus_pdp0": "",
                }
            )

        summary = print_comparison(
            train_pdp_id=train_pdp_id,
            pdp0_results=pdp0_results,
            matched_results=matched_results,
        )

        summary_rows.append(summary)

        del model
        tf.keras.backend.clear_session()

    save_results_to_csv(
        detailed_rows=detailed_rows,
        summary_rows=summary_rows,
    )

    print("\n=====================================")
    print("All seeded comparisons are complete.")
    print("=====================================")


if __name__ == "__main__":
    main()