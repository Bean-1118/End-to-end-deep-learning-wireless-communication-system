from src import base_functions as bf

print("base_functions imported successfully")
print("block_length:", bf.block_length)
print("len_h:", bf.len_h)
print("batch_size:", bf.batch_size)
print("R:", bf.R)