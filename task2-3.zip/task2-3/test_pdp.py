# from src.pdp_profiles import get_known_pdps
# from src.base_functions import len_h

# pdp_list = get_known_pdps(len_h)

# for i, pdp in enumerate(pdp_list):
#     print(f"PDP{i}:", pdp)
#     print("sum =", pdp.sum())
import numpy as np

from src.base_functions import sample_h_mp, len_h
from src.pdp_profiles import get_known_pdps


def main():
    pdp_list = get_known_pdps(len_h)

    num_samples = 200000

    for pdp_id, pdp in enumerate(pdp_list):
        h = sample_h_mp(
            (num_samples, len_h, 2),
            pdp,
        ).astype(np.float32)

        # Complex tap power = real^2 + imag^2
        empirical_power = np.mean(
            h[:, :, 0] ** 2 + h[:, :, 1] ** 2,
            axis=0,
        )

        empirical_power /= empirical_power.sum()

        print(f"\nPDP{pdp_id}")
        print("Target:   ", np.round(pdp, 4))
        print("Empirical:", np.round(empirical_power, 4))
        print(
            "Max error:",
            np.max(np.abs(empirical_power - pdp)),
        )


if __name__ == "__main__":
    main()