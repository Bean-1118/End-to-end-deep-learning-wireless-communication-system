import numpy as np
import tensorflow as tf

from src.base_functions import (
    end_to_end,
    sample_h_mp,
    generate_batch_data,
    batch_size,
    block_length,
    len_h,
    R,
)

from src.pdp_profiles import get_known_pdps


def main():
    model = end_to_end()
    optimizer = tf.keras.optimizers.Adam(learning_rate=1e-4)

    pdp_list = get_known_pdps(len_h)
    pdp0 = pdp_list[0]

    batch_x = generate_batch_data(batch_size)

    h_train = sample_h_mp(
        (batch_size, len_h, 2),
        pdp0,
    ).astype(np.float32)

    snr_db = 20
    ebno = 10 ** (snr_db / 10)

    noise_std_value = np.sqrt(
        1 / (2 * R * ebno)
    ).astype(np.float32)

    noise_std = np.full(
        (batch_size, 1),
        noise_std_value,
        dtype=np.float32,
    )

    batch_x_tensor = tf.cast(batch_x, tf.float32)

    with tf.GradientTape() as tape:
        pred_logits, pred_prob = model(
            [
                batch_x,
                h_train,
                noise_std,
            ],
            training=True,
        )

        loss = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(
                logits=pred_logits,
                labels=batch_x_tensor,
            )
        )

    gradients = tape.gradient(
        loss,
        model.trainable_variables,
    )

    optimizer.apply_gradients(
        zip(gradients, model.trainable_variables)
    )

    predicted_bits = tf.cast(
        pred_prob >= 0.5,
        tf.float32,
    )

    ber = tf.reduce_mean(
        tf.cast(
            predicted_bits != batch_x_tensor,
            tf.float32,
        )
    )

    print("One training step successful")
    print("Loss:", loss.numpy())
    print("BER:", ber.numpy())
    print(
        "Number of gradients:",
        sum(g is not None for g in gradients),
        "/",
        len(gradients),
    )


if __name__ == "__main__":
    main()