import numpy as np
import tensorflow as tf

from src.base_functions import (
    end_to_end,
    sample_h_mp,
    generate_batch_data,
    block_length,
    len_h,
    R,
    batch_size,
)


# ============================================================
# Train one model on one PDP
# ============================================================

def train_model_on_pdp(
    pdp_train,
    train_id,
    number_steps=300,
    learning_rate=1e-4,
    ebno_train_linear=20.0,
):
    """
    Train one independent end-to-end model on one PDP.

    Parameters
    ----------
    pdp_train:
        PDP used to generate the training channels.

    train_id:
        PDP index used for printing progress.

    number_steps:
        Number of gradient-update steps.

    learning_rate:
        Adam learning rate.

    ebno_train_linear:
        Linear Eb/N0 value, not dB.

        For example:
            ebno_train_linear = 20

        corresponds to approximately:
            10 * log10(20) = 13.01 dB
    """

    model = end_to_end()

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=learning_rate
    )

    # Eb/N0 is specified in linear scale.
    # The supplied value is already in linear scale.
    noise_std_value = np.float32(
        np.sqrt(
            1.0 / (2.0 * R * ebno_train_linear)
        )
    )

    loss_history = []
    ber_history = []

    for step in range(1, number_steps + 1):

        # Generate a training batch.
        batch_x = generate_batch_data(batch_size)

        # Generate channel real/imaginary components according to pdp_train.
        h_train = sample_h_mp(
            (batch_size, len_h, 2),
            pdp_train,
        ).astype(np.float32)

        # Model input_sdv has shape (batch_size, 1).
        noise_std = np.full(
            (batch_size, 1),
            noise_std_value,
            dtype=np.float32,
        )

        batch_x_tensor = tf.cast(
            batch_x,
            tf.float32,
        )

        with tf.GradientTape() as tape:

            y_pred_logits, y_pred = model(
                [
                    batch_x,
                    h_train,
                    noise_std,
                ],
                training=True,
            )

            loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(
                    logits=y_pred_logits,
                    labels=batch_x_tensor,
                )
            )

        grads = tape.gradient(
            loss,
            model.trainable_variables,
        )

        # Ignore variables without a gradient.
        grads_and_vars = [
            (grad, variable)
            for grad, variable in zip(
                grads,
                model.trainable_variables,
            )
            if grad is not None
        ]

        optimizer.apply_gradients(
            grads_and_vars
        )

        predicted_bits = tf.cast(
            y_pred >= 0.5,
            tf.float32,
        )

        train_ber = tf.reduce_mean(
            tf.cast(
                predicted_bits != batch_x_tensor,
                tf.float32,
            )
        )

        loss_history.append(
            float(loss.numpy())
        )

        ber_history.append(
            float(train_ber.numpy())
        )

        if step % 100 == 0 or step == 1:
            print(
                f"Train PDP{train_id} | "
                f"Step {step}/{number_steps} | "
                f"Eb/N0 linear = {ebno_train_linear:g} | "
                f"Noise std = {noise_std_value:.6f} | "
                f"Loss = {loss.numpy():.5f} | "
                f"Training BER = {train_ber.numpy():.5f}"
            )

    return (
        model,
        np.asarray(loss_history, dtype=np.float32),
        np.asarray(ber_history, dtype=np.float32),
    )


# ============================================================
# Evaluate one model on one PDP at one linear Eb/N0
# ============================================================

def evaluate_ber_single_ebno(
    model,
    pdp_test,
    ebno_linear=20.0,
    num_test_batches=10,
):
    """Evaluate BER at one linear Eb/N0 value.
    
        ebno_linear is in linear scale; a value of 20 corresponds to about 13.01 dB.
    """

    noise_std_value = np.float32(
        np.sqrt(
            1.0 / (2.0 * R * ebno_linear)
        )
    )

    total_errors = 0
    total_bits = 0

    for _ in range(num_test_batches):

        # Generate independent random test bits.
        test_bits = np.random.binomial(
            n=1,
            p=0.5,
            size=(
                batch_size,
                block_length,
                1,
            ),
        ).astype(np.float32)

        # Generate test channels according to pdp_test.
        h_test = sample_h_mp(
            (batch_size, len_h, 2),
            pdp_test,
        ).astype(np.float32)

        noise_std = np.full(
            (batch_size, 1),
            noise_std_value,
            dtype=np.float32,
        )

        _, y_pred = model(
            [
                test_bits,
                h_test,
                noise_std,
            ],
            training=False,
        )

        predicted_bits = tf.cast(
            y_pred >= 0.5,
            tf.float32,
        )

        test_bits_tensor = tf.cast(
            test_bits,
            tf.float32,
        )

        errors = tf.reduce_sum(
            tf.cast(
                predicted_bits != test_bits_tensor,
                tf.int64,
            )
        )

        total_errors += int(
            errors.numpy()
        )

        total_bits += int(
            np.prod(test_bits.shape)
        )

    ber = total_errors / total_bits

    return ber