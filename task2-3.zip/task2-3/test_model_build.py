from src.base_functions import end_to_end

model = end_to_end()

print("end_to_end model created successfully")
print("Inputs:")
for model_input in model.inputs:
    print(model_input.shape)

print("Outputs:")
for model_output in model.outputs:
    print(model_output.shape)

model.summary()