import os
import gc
import csv
import random

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

from src.base_functions import (
    end_to_end,
    sample_h_mp,
    generate_batch_data,
    batch_size,
    block_length,
    len_h,
    R,
)


# ============================================================
# Experiment configuration
# ============================================================

# Extreme one-tap PDP environments.
#
# PDP-A: no delay, only tap 0.
# PDP-B: pure delay at tap 3.
# PDP-C: pure delay at tap 7.
EXTREME_PDPS = [
    np.array(
        [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        dtype=np.float32,
    ),
    np.array(
        [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0],
        dtype=np.float32,
    ),
    np.array(
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
        dtype=np.float32,
    ),
]

PDP_NAMES = [
    "Tap0",
    "Tap2",
    "Tap7",
]

NUM_ENVIRONMENTS = len(EXTREME_PDPS)

# Training steps per model.
# Increase this value only when a longer training run is required.
NUMBER_STEPS = 3000

LEARNING_RATE = 1e-4

# Eb/N0 is specified in linear scale.
# A value of 20 corresponds to about 13.01 dB.
EBNO_LINEAR = 20.0

# 30 batches means almost 2 million tested bits per matrix cell
# when batch_size=512 and block_length=128.
NUM_TEST_BATCHES = 30

# Print training progress every N steps.
PRINT_INTERVAL = 100

# Independent training seeds for the three models.
TRAINING_SEEDS = [
    1001,
    1002,
    1003,
]

# Fixed test seed.
TEST_SEED = 98765

OUTPUT_ROOT = "outputs/extreme_pdp_sanity"
RESULT_DIR = os.path.join(OUTPUT_ROOT, "results")
FIGURE_DIR = os.path.join(OUTPUT_ROOT, "figures")
CHECKPOINT_DIR = os.path.join(OUTPUT_ROOT, "checkpoints")


# ============================================================
# Random seed control
# ============================================================

def set_all_seeds(seed):
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


# ============================================================
# GPU configuration
# ============================================================

def setup_gpu():
    gpus = tf.config.list_physical_devices("GPU")

    for gpu in gpus:
        try:
            tf.config.experimental.set_memory_growth(
                gpu,
                True,
            )
        except RuntimeError:
            # Memory growth may already have been configured.
            pass

    print("GPUs:", gpus)


# ============================================================
# Noise generation
# ============================================================

def calculate_noise_std(ebno_linear):
    return np.float32(
        np.sqrt(
            1.0 / (2.0 * R * ebno_linear)
        )
    )


# ============================================================
# Train one independent model
# ============================================================

def train_one_extreme_model(
    train_pdp,
    train_id,
    training_seed,
):
    """
    Train a completely new model on one extreme PDP.
    """

    set_all_seeds(training_seed)

    # Model isolation:
    # Use a separate model instance for each training PDP.
    model = end_to_end()

    optimizer = tf.keras.optimizers.Adam(
        learning_rate=LEARNING_RATE
    )

    noise_std_value = calculate_noise_std(
        EBNO_LINEAR
    )

    loss_history = []
    ber_history = []

    print("\n========================================")
    print(
        f"Training model {train_id} "
        f"on extreme PDP {PDP_NAMES[train_id]}"
    )
    print("========================================")
    print("PDP:", train_pdp)
    print("Training seed:", training_seed)

    for step in range(1, NUMBER_STEPS + 1):

        batch_x = generate_batch_data(
            batch_size
        ).astype(np.float32)

        h_train = sample_h_mp(
            (
                batch_size,
                len_h,
                2,
            ),
            train_pdp,
        ).astype(np.float32)

        noise_std = np.full(
            (
                batch_size,
                1,
            ),
            noise_std_value,
            dtype=np.float32,
        )

        batch_x_tensor = tf.convert_to_tensor(
            batch_x,
            dtype=tf.float32,
        )

        with tf.GradientTape() as tape:

            pred_logits, pred_prob = model(
                [
                    batch_x,
                    h_train,
                    noise_std,
                ],
                training=True,
            )

            loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(
                    labels=batch_x_tensor,
                    logits=pred_logits,
                )
            )

        gradients = tape.gradient(
            loss,
            model.trainable_variables,
        )

        gradients_and_variables = [
            (gradient, variable)
            for gradient, variable in zip(
                gradients,
                model.trainable_variables,
            )
            if gradient is not None
        ]

        optimizer.apply_gradients(
            gradients_and_variables
        )

        predicted_bits = tf.cast(
            pred_prob >= 0.5,
            tf.float32,
        )

        train_ber = tf.reduce_mean(
            tf.cast(
                predicted_bits != batch_x_tensor,
                tf.float32,
            )
        )

        loss_value = float(
            loss.numpy()
        )

        ber_value = float(
            train_ber.numpy()
        )

        loss_history.append(
            loss_value
        )

        ber_history.append(
            ber_value
        )

        if (
            step == 1
            or step % PRINT_INTERVAL == 0
            or step == NUMBER_STEPS
        ):
            print(
                f"Model {PDP_NAMES[train_id]} | "
                f"Step {step}/{NUMBER_STEPS} | "
                f"Loss = {loss_value:.6f} | "
                f"Training BER = {ber_value:.6f}"
            )

    return (
        model,
        np.asarray(
            loss_history,
            dtype=np.float32,
        ),
        np.asarray(
            ber_history,
            dtype=np.float32,
        ),
    )


# ============================================================
# Evaluate one model/PDP pair
# ============================================================

def evaluate_one_pair(
    model,
    test_pdp,
    test_seed,
):
    """
    Evaluate one fixed model on one fixed extreme PDP.

    The model parameters are not updated.
    """

    set_all_seeds(test_seed)

    noise_std_value = calculate_noise_std(
        EBNO_LINEAR
    )

    total_errors = 0
    total_bits = 0

    for _ in range(NUM_TEST_BATCHES):

        test_bits = np.random.binomial(
            n=1,
            p=0.5,
            size=(
                batch_size,
                block_length,
                1,
            ),
        ).astype(np.float32)

        h_test = sample_h_mp(
            (
                batch_size,
                len_h,
                2,
            ),
            test_pdp,
        ).astype(np.float32)

        noise_std = np.full(
            (
                batch_size,
                1,
            ),
            noise_std_value,
            dtype=np.float32,
        )

        _, predicted_probabilities = model(
            [
                test_bits,
                h_test,
                noise_std,
            ],
            training=False,
        )

        predicted_bits = tf.cast(
            predicted_probabilities >= 0.5,
            tf.float32,
        )

        target_bits = tf.convert_to_tensor(
            test_bits,
            dtype=tf.float32,
        )

        errors = tf.reduce_sum(
            tf.cast(
                predicted_bits != target_bits,
                tf.int64,
            )
        )

        total_errors += int(
            errors.numpy()
        )

        total_bits += int(
            np.prod(
                test_bits.shape
            )
        )

    return total_errors / total_bits


# ============================================================
# Saving
# ============================================================

def save_matrix_csv(
    matrix,
    save_path,
):
    with open(
        save_path,
        "w",
        newline="",
        encoding="utf-8",
    ) as csv_file:

        writer = csv.writer(
            csv_file
        )

        writer.writerow(
            [
                "Training PDP / Test PDP",
                *PDP_NAMES,
            ]
        )

        for row_id, row in enumerate(matrix):
            writer.writerow(
                [
                    PDP_NAMES[row_id],
                    *[
                        f"{value:.10f}"
                        for value in row
                    ],
                ]
            )


def plot_matrix(
    matrix,
    save_path,
):
    ebno_db = 10.0 * np.log10(
        EBNO_LINEAR
    )

    plt.figure(
        figsize=(7, 6)
    )

    image = plt.imshow(
        matrix,
        aspect="auto",
    )

    plt.colorbar(
        image,
        label="BER",
    )

    plt.xticks(
        np.arange(
            NUM_ENVIRONMENTS
        ),
        PDP_NAMES,
    )

    plt.yticks(
        np.arange(
            NUM_ENVIRONMENTS
        ),
        PDP_NAMES,
    )

    plt.xlabel(
        "Test Extreme PDP"
    )

    plt.ylabel(
        "Training Extreme PDP"
    )

    plt.title(
        "Extreme-PDP Sanity Matrix\n"
        f"Eb/N0 = {EBNO_LINEAR:g} linear "
        f"({ebno_db:.2f} dB), "
        f"{NUMBER_STEPS} training steps"
    )

    for row in range(
        NUM_ENVIRONMENTS
    ):
        for column in range(
            NUM_ENVIRONMENTS
        ):
            plt.text(
                column,
                row,
                f"{matrix[row, column]:.4f}",
                ha="center",
                va="center",
            )

    plt.tight_layout()

    plt.savefig(
        save_path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()


# ============================================================
# Matrix diagnostics
# ============================================================

def analyse_diagonal_dominance(
    matrix,
):
    print("\n========================================")
    print("Diagonal-dominance diagnostic")
    print("========================================")

    all_rows_pass = True

    for train_id in range(
        NUM_ENVIRONMENTS
    ):

        row = matrix[
            train_id
        ]

        diagonal_ber = row[
            train_id
        ]

        best_test_id = int(
            np.argmin(row)
        )

        best_ber = row[
            best_test_id
        ]

        mismatch_values = np.delete(
            row,
            train_id,
        )

        best_mismatch_ber = float(
            np.min(
                mismatch_values
            )
        )

        margin = (
            best_mismatch_ber
            - diagonal_ber
        )

        row_passes = (
            best_test_id == train_id
        )

        if not row_passes:
            all_rows_pass = False

        print(
            f"\nModel trained on {PDP_NAMES[train_id]}"
        )

        print(
            f"Matched BER: {diagonal_ber:.8f}"
        )

        print(
            f"Best test environment: "
            f"{PDP_NAMES[best_test_id]}"
        )

        print(
            f"Best BER: {best_ber:.8f}"
        )

        print(
            f"Matched advantage over best mismatch: "
            f"{margin:+.8f}"
        )

        print(
            "PASS: matched PDP is best."
            if row_passes
            else
            "FAIL: a mismatched PDP is better."
        )

    print("\n========================================")

    if all_rows_pass:
        print(
            "OVERALL PASS: all extreme models have "
            "their lowest BER on the matched PDP."
        )
    else:
        print(
            "OVERALL FAIL: at least one extreme model "
            "does not have its lowest BER on the matched PDP."
        )

    print("========================================")


# ============================================================
# Main
# ============================================================

def main():
    setup_gpu()

    os.makedirs(
        RESULT_DIR,
        exist_ok=True,
    )

    os.makedirs(
        FIGURE_DIR,
        exist_ok=True,
    )

    os.makedirs(
        CHECKPOINT_DIR,
        exist_ok=True,
    )

    if len_h != 8:
        raise ValueError(
            "This sanity script currently assumes len_h = 8, "
            f"but base_functions.py reports len_h = {len_h}."
        )

    for pdp_id, pdp in enumerate(
        EXTREME_PDPS
    ):
        if not np.isclose(
            np.sum(pdp),
            1.0,
        ):
            raise ValueError(
                f"Extreme PDP {pdp_id} does not sum to 1."
            )

    bits_per_matrix_cell = (
        NUM_TEST_BATCHES
        * batch_size
        * block_length
    )

    print("\nExtreme PDP sanity experiment")
    print("=============================")

    print(
        f"Training steps per model: "
        f"{NUMBER_STEPS}"
    )

    print(
        f"Test batches per pair: "
        f"{NUM_TEST_BATCHES}"
    )

    print(
        f"Bits per BER matrix cell: "
        f"{bits_per_matrix_cell:,}"
    )

    print(
        f"Batch size: {batch_size}"
    )

    print(
        f"Eb/N0 linear: {EBNO_LINEAR:g}"
    )

    print(
        f"Equivalent Eb/N0: "
        f"{10.0 * np.log10(EBNO_LINEAR):.2f} dB"
    )

    print("\nExtreme PDP definitions:")

    for pdp_id, pdp in enumerate(
        EXTREME_PDPS
    ):
        print(
            f"{PDP_NAMES[pdp_id]}: {pdp}"
        )

    ber_matrix = np.zeros(
        (
            NUM_ENVIRONMENTS,
            NUM_ENVIRONMENTS,
        ),
        dtype=np.float64,
    )

    for train_id, train_pdp in enumerate(
        EXTREME_PDPS
    ):

        model, loss_history, ber_history = (
            train_one_extreme_model(
                train_pdp=train_pdp,
                train_id=train_id,
                training_seed=TRAINING_SEEDS[
                    train_id
                ],
            )
        )

        np.save(
            os.path.join(
                RESULT_DIR,
                f"loss_history_{PDP_NAMES[train_id]}.npy",
            ),
            loss_history,
        )

        np.save(
            os.path.join(
                RESULT_DIR,
                f"train_ber_history_{PDP_NAMES[train_id]}.npy",
            ),
            ber_history,
        )

        print(
            f"\nTesting model trained on "
            f"{PDP_NAMES[train_id]}"
        )

        for test_id, test_pdp in enumerate(
            EXTREME_PDPS
        ):

            ber = evaluate_one_pair(
                model=model,
                test_pdp=test_pdp,
                test_seed=TEST_SEED,
            )

            ber_matrix[
                train_id,
                test_id,
            ] = ber

            print(
                f"Train {PDP_NAMES[train_id]} "
                f"-> Test {PDP_NAMES[test_id]} | "
                f"BER = {ber:.8f}"
            )

        model_checkpoint_dir = os.path.join(
            CHECKPOINT_DIR,
            f"model_trained_on_{PDP_NAMES[train_id]}",
        )

        os.makedirs(
            model_checkpoint_dir,
            exist_ok=True,
        )

        checkpoint = tf.train.Checkpoint(
            model=model
        )

        checkpoint.save(
            os.path.join(
                model_checkpoint_dir,
                "ckpt",
            )
        )

        # Save partial results after each completed training row.
        np.save(
            os.path.join(
                RESULT_DIR,
                "extreme_ber_matrix_partial.npy",
            ),
            ber_matrix,
        )

        del model

        tf.keras.backend.clear_session()

        gc.collect()

    # Save final results.
    matrix_npy_path = os.path.join(
        RESULT_DIR,
        "extreme_ber_matrix.npy",
    )

    matrix_csv_path = os.path.join(
        RESULT_DIR,
        "extreme_ber_matrix.csv",
    )

    figure_path = os.path.join(
        FIGURE_DIR,
        "extreme_pdp_sanity_matrix.png",
    )

    np.save(
        matrix_npy_path,
        ber_matrix,
    )

    save_matrix_csv(
        matrix=ber_matrix,
        save_path=matrix_csv_path,
    )

    plot_matrix(
        matrix=ber_matrix,
        save_path=figure_path,
    )

    print("\nFinal extreme-PDP BER matrix")
    print("============================")
    print(ber_matrix)

    analyse_diagonal_dominance(
        ber_matrix
    )

    print("\nSaved files:")
    print(matrix_npy_path)
    print(matrix_csv_path)
    print(figure_path)


if __name__ == "__main__":
    main()