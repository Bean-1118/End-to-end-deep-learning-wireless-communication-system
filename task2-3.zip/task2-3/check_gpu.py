import tensorflow as tf

gpus = tf.config.list_physical_devices("GPU")

for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

print("TensorFlow version:", tf.__version__)
print("GPUs:", gpus)