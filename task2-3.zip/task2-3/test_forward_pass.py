import numpy as np
import tensorflow as tf

from src.base_functions import (
    end_to_end,
    sample_h_mp,
    batch_size,
    block_length,
    len_h,
    R,
)

from src.pdp_profiles import get_known_pdps


def main():
    model = end_to_end()

    pdp_list = get_known_pdps(len_h)
    pdp0 = pdp_list[0]

    test_bits = np.random.binomial(
        n=1,
        p=0.5,
        size=(batch_size, block_length, 1),
    ).astype(np.float32)

    test_h = sample_h_mp(
        (batch_size, len_h, 2),
        pdp0,
    ).astype(np.float32)

    snr_db = 20
    ebno = 10 ** (snr_db / 10)

    noise_std_value = np.sqrt(
        1 / (2 * R * ebno)
    ).astype(np.float32)

    test_noise_std = np.full(
        (batch_size, 1),
        noise_std_value,
        dtype=np.float32,
    )

    pred_logits, pred_prob = model(
        [
            test_bits,
            test_h,
            test_noise_std,
        ],
        training=False,
    )

    print("Forward pass successful")
    print("Logits shape:", pred_logits.shape)
    print("Probability shape:", pred_prob.shape)
    print("Probability minimum:", tf.reduce_min(pred_prob).numpy())
    print("Probability maximum:", tf.reduce_max(pred_prob).numpy())
    print("Probability mean:", tf.reduce_mean(pred_prob).numpy())


if __name__ == "__main__":
    main()