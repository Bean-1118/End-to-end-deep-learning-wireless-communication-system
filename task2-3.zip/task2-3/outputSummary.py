from __future__ import annotations

import argparse
import json
import math
import warnings
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ============================================================
# Project paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DEFAULT_UNSEEN_ROOT = (
    PROJECT_ROOT
    / "outputs"
    / "task6"
    / "unseen_adaptation_v2"
)

DEFAULT_IADMM_ROOT = (
    PROJECT_ROOT
    / "outputs"
    / "task6"
    / "iadmm_training_v2"
)

DEFAULT_OUTPUT_ROOT = (
    PROJECT_ROOT
    / "outputs"
    / "task6"
    / "final_summary"
)


# ============================================================
# General utilities
# ============================================================

def population_std(series: pd.Series) -> float:
    """Return the population standard deviation.
    
        A single value returns 0 instead of NaN.
    """
    numeric = pd.to_numeric(
        series,
        errors="coerce",
    ).dropna()

    if numeric.empty:
        return float("nan")

    return float(
        numeric.std(ddof=0)
    )


def safe_mean(series: pd.Series) -> float:
    numeric = pd.to_numeric(
        series,
        errors="coerce",
    ).dropna()

    if numeric.empty:
        return float("nan")

    return float(
        numeric.mean()
    )


def ensure_directory(path: Path) -> Path:
    path.mkdir(
        parents=True,
        exist_ok=True,
    )
    return path


def save_figure(
    figure: plt.Figure,
    path: Path,
) -> None:
    ensure_directory(
        path.parent
    )

    figure.tight_layout()

    figure.savefig(
        path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close(
        figure
    )


def write_text(
    path: Path,
    text: str,
) -> None:
    ensure_directory(
        path.parent
    )

    path.write_text(
        text,
        encoding="utf-8",
    )


def find_first_existing(
    candidates: Iterable[Path],
) -> Path | None:
    for candidate in candidates:
        if candidate.exists():
            return candidate

    return None


def load_unseen_results(
    unseen_root: Path,
) -> tuple[pd.DataFrame, Path]:
    candidates = [
        unseen_root
        / "unseen_adaptation_raw.csv",

        unseen_root
        / "unseen_adaptation_raw_partial.csv",

        PROJECT_ROOT
        / "outputs"
        / "task6"
        / "unseen_adaptation"
        / "unseen_adaptation_raw.csv",
    ]

    selected = find_first_existing(
        candidates
    )

    if selected is None:
        raise FileNotFoundError(
            "Could not find unseen-adaptation raw results. "
            "Checked:\n"
            + "\n".join(
                str(path)
                for path in candidates
            )
        )

    dataframe = pd.read_csv(
        selected
    )

    required = {
        "seed",
        "target_pdp",
        "adaptation_blocks",
        "method",
        "zero_shot_ber",
        "adapted_ber",
        "absolute_improvement",
    }

    missing = required.difference(
        dataframe.columns
    )

    if missing:
        raise ValueError(
            "Unseen-adaptation result file is missing "
            f"columns: {sorted(missing)}"
        )

    if "relative_improvement" not in dataframe:
        denominator = dataframe[
            "zero_shot_ber"
        ].replace(
            0,
            np.nan,
        )

        dataframe[
            "relative_improvement"
        ] = (
            dataframe[
                "absolute_improvement"
            ]
            / denominator
        )

    return (
        dataframe,
        selected,
    )


# ============================================================
# Core summary table
# ============================================================

def build_unseen_summary(
    dataframe: pd.DataFrame,
) -> pd.DataFrame:
    summary = (
        dataframe
        .groupby(
            [
                "target_pdp",
                "adaptation_blocks",
                "method",
            ],
            as_index=False,
        )
        .agg(
            seed_count=(
                "seed",
                "nunique",
            ),

            mean_zero_shot_ber=(
                "zero_shot_ber",
                "mean",
            ),

            std_zero_shot_ber=(
                "zero_shot_ber",
                population_std,
            ),

            mean_adapted_ber=(
                "adapted_ber",
                "mean",
            ),

            std_adapted_ber=(
                "adapted_ber",
                population_std,
            ),

            mean_absolute_improvement=(
                "absolute_improvement",
                "mean",
            ),

            std_absolute_improvement=(
                "absolute_improvement",
                population_std,
            ),

            mean_relative_improvement=(
                "relative_improvement",
                "mean",
            ),

            std_relative_improvement=(
                "relative_improvement",
                population_std,
            ),

            positive_improvement_fraction=(
                "absolute_improvement",
                lambda values: float(
                    (
                        pd.to_numeric(
                            values,
                            errors="coerce",
                        )
                        > 0
                    ).mean()
                ),
            ),
        )
    )

    return summary.sort_values(
        [
            "target_pdp",
            "adaptation_blocks",
            "method",
        ]
    )


# ============================================================
# A. Strategy comparison
# ============================================================

def task_a_strategy_comparison(
    dataframe: pd.DataFrame,
    tables_directory: Path,
    plots_directory: Path,
    reports_directory: Path,
) -> dict[str, object]:
    """
    Compare particular-only adaptation with full fine-tuning
    or other strategies, when such data exist.
    """
    methods = sorted(
        dataframe["method"]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    result = {
        "available_methods":
            methods,

        "comparison_available":
            len(methods) >= 2,
    }

    if len(methods) < 2:
        message = (
            "Task A could not be completed because the raw "
            "Task 6 result contains only one method:\n\n"
            f"{methods}\n\n"
            "To compare particular-only adaptation with "
            "full fine-tuning, append full-finetune rows to "
            "the same raw CSV using the same columns, seeds, "
            "support sizes and query datasets.\n"
        )

        write_text(
            reports_directory
            / "A_strategy_comparison_status.txt",
            message,
        )

        return result

    comparison = (
        dataframe
        .groupby(
            [
                "target_pdp",
                "adaptation_blocks",
                "method",
            ],
            as_index=False,
        )
        .agg(
            mean_adapted_ber=(
                "adapted_ber",
                "mean",
            ),

            std_adapted_ber=(
                "adapted_ber",
                population_std,
            ),

            mean_absolute_improvement=(
                "absolute_improvement",
                "mean",
            ),

            seed_count=(
                "seed",
                "nunique",
            ),
        )
    )

    comparison.to_csv(
        tables_directory
        / "A_strategy_comparison.csv",
        index=False,
    )

    for target_pdp in sorted(
        comparison["target_pdp"].unique()
    ):
        subset = comparison[
            comparison["target_pdp"]
            == target_pdp
        ]

        figure, axis = plt.subplots(
            figsize=(8.5, 5.5)
        )

        for method in sorted(
            subset["method"].unique()
        ):
            method_rows = (
                subset[
                    subset["method"]
                    == method
                ]
                .sort_values(
                    "adaptation_blocks"
                )
            )

            axis.errorbar(
                method_rows[
                    "adaptation_blocks"
                ],
                method_rows[
                    "mean_adapted_ber"
                ],
                yerr=method_rows[
                    "std_adapted_ber"
                ],
                marker="o",
                capsize=4,
                label=method,
            )

        axis.set_xlabel(
            "Number of target support blocks"
        )

        axis.set_ylabel(
            "Query BER after adaptation"
        )

        axis.set_title(
            f"PDP{target_pdp}: adaptation strategy comparison"
        )

        axis.grid(
            True,
            alpha=0.3,
        )

        axis.legend()

        save_figure(
            figure,
            plots_directory
            / (
                f"A_PDP{target_pdp}"
                "_strategy_comparison.png"
            ),
        )

    return result


# ============================================================
# B. Support size versus BER
# ============================================================

def task_b_support_size_ber(
    summary: pd.DataFrame,
    tables_directory: Path,
    plots_directory: Path,
) -> None:
    summary.to_csv(
        tables_directory
        / "B_support_size_ber_summary.csv",
        index=False,
    )

    for method in sorted(
        summary["method"].unique()
    ):
        subset = summary[
            summary["method"]
            == method
        ]

        figure, axis = plt.subplots(
            figsize=(8.5, 5.5)
        )

        for target_pdp in sorted(
            subset["target_pdp"].unique()
        ):
            pdp_rows = (
                subset[
                    subset["target_pdp"]
                    == target_pdp
                ]
                .sort_values(
                    "adaptation_blocks"
                )
            )

            axis.errorbar(
                pdp_rows[
                    "adaptation_blocks"
                ],
                pdp_rows[
                    "mean_adapted_ber"
                ],
                yerr=pdp_rows[
                    "std_adapted_ber"
                ],
                marker="o",
                capsize=4,
                label=f"PDP{target_pdp}",
            )

        axis.set_xlabel(
            "Number of target support blocks"
        )

        axis.set_ylabel(
            "Query BER after adaptation"
        )

        axis.set_title(
            f"Support size versus BER — {method}"
        )

        axis.grid(
            True,
            alpha=0.3,
        )

        axis.legend()

        save_figure(
            figure,
            plots_directory
            / (
                "B_support_size_vs_ber"
                f"__{method}.png"
            ),
        )


# ============================================================
# C. Learning curves
# ============================================================

def discover_training_histories(
    unseen_root: Path,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []

    for path in unseen_root.rglob(
        "training_history.json"
    ):
        try:
            relative = path.relative_to(
                unseen_root
            )

            parts = relative.parts

            pdp_id = None
            seed = None
            block_count = None
            method = "particular_only_tl"

            for part in parts:
                if part in {
                    "no_adaptation",
                    "particular_only_tl",
                    "full_finetune",
                }:
                    method = part

                elif part.startswith("PDP"):
                    pdp_id = int(
                        part.replace(
                            "PDP",
                            "",
                        )
                    )

                elif part.startswith("seed_"):
                    seed = int(
                        part.replace(
                            "seed_",
                            "",
                        )
                    )

                elif part.startswith("blocks_"):
                    block_count = int(
                        part.replace(
                            "blocks_",
                            "",
                        )
                    )

            payload = json.loads(
                path.read_text(
                    encoding="utf-8"
                )
            )

            if isinstance(
                payload,
                dict,
            ):
                if (
                    "epoch_loss" in payload
                    and "epoch_ber" in payload
                ):
                    payload = [
                        {
                            "epoch": index + 1,
                            "loss": loss,
                            "ber": ber,
                        }
                        for index, (
                            loss,
                            ber,
                        ) in enumerate(
                            zip(
                                payload[
                                    "epoch_loss"
                                ],
                                payload[
                                    "epoch_ber"
                                ],
                            )
                        )
                    ]

                elif "history" in payload:
                    payload = payload[
                        "history"
                    ]

            if not isinstance(
                payload,
                list,
            ):
                warnings.warn(
                    f"Unsupported history format: {path}"
                )
                continue

            for entry in payload:
                if not isinstance(
                    entry,
                    dict,
                ):
                    continue

                if "epoch" not in entry:
                    continue

                rows.append({
                    "target_pdp":
                        pdp_id,

                    "seed":
                        seed,

                    "adaptation_blocks":
                        block_count,

                    "method":
                        method,

                    "epoch":
                        entry.get(
                            "epoch"
                        ),

                    "support_loss":
                        entry.get(
                            "loss",
                            np.nan,
                        ),

                    "support_ber":
                        entry.get(
                            "ber",
                            np.nan,
                        ),

                    "history_path":
                        str(path),
                })

        except Exception as error:
            warnings.warn(
                f"Could not read {path}: {error}"
            )

    if not rows:
        return pd.DataFrame()

    return pd.DataFrame(
        rows
    )


def task_c_learning_curves(
    unseen_root: Path,
    tables_directory: Path,
    plots_directory: Path,
    reports_directory: Path,
) -> pd.DataFrame:
    history = discover_training_histories(
        unseen_root
    )

    if history.empty:
        write_text(
            reports_directory
            / "C_learning_curve_status.txt",
            (
                "No training_history.json files were found "
                f"under {unseen_root}.\n"
            ),
        )

        return history

    history.to_csv(
        tables_directory
        / "C_learning_history_raw.csv",
        index=False,
    )

    grouped = (
        history
        .groupby(
            [
                "target_pdp",
                "adaptation_blocks",
                "method",
                "epoch",
            ],
            as_index=False,
        )
        .agg(
            seed_count=(
                "seed",
                "nunique",
            ),

            mean_support_loss=(
                "support_loss",
                "mean",
            ),

            std_support_loss=(
                "support_loss",
                population_std,
            ),

            mean_support_ber=(
                "support_ber",
                "mean",
            ),

            std_support_ber=(
                "support_ber",
                population_std,
            ),
        )
    )

    grouped.to_csv(
        tables_directory
        / "C_learning_curve_summary.csv",
        index=False,
    )

    for target_pdp in sorted(
        grouped["target_pdp"]
        .dropna()
        .unique()
    ):
        pdp_rows = grouped[
            grouped["target_pdp"]
            == target_pdp
        ]

        for block_count in sorted(
            pdp_rows[
                "adaptation_blocks"
            ]
            .dropna()
            .unique()
        ):
            subset = (
                pdp_rows[
                    pdp_rows[
                        "adaptation_blocks"
                    ]
                    == block_count
                ]
                .sort_values(
                    "epoch"
                )
            )

            figure, axis = plt.subplots(
                figsize=(8.5, 5.5)
            )

            axis.errorbar(
                subset["epoch"],
                subset[
                    "mean_support_loss"
                ],
                yerr=subset[
                    "std_support_loss"
                ],
                marker="o",
                capsize=3,
            )

            axis.set_xlabel(
                "Adaptation epoch"
            )

            axis.set_ylabel(
                "Support loss"
            )

            axis.set_title(
                f"PDP{int(target_pdp)}, "
                f"{int(block_count)} blocks: "
                "support-loss convergence"
            )

            axis.grid(
                True,
                alpha=0.3,
            )

            save_figure(
                figure,
                plots_directory
                / (
                    f"C_PDP{int(target_pdp)}"
                    f"__blocks{int(block_count)}"
                    "__support_loss.png"
                ),
            )

            figure, axis = plt.subplots(
                figsize=(8.5, 5.5)
            )

            axis.errorbar(
                subset["epoch"],
                subset[
                    "mean_support_ber"
                ],
                yerr=subset[
                    "std_support_ber"
                ],
                marker="o",
                capsize=3,
            )

            axis.set_xlabel(
                "Adaptation epoch"
            )

            axis.set_ylabel(
                "Support BER"
            )

            axis.set_title(
                f"PDP{int(target_pdp)}, "
                f"{int(block_count)} blocks: "
                "support-BER convergence"
            )

            axis.grid(
                True,
                alpha=0.3,
            )

            save_figure(
                figure,
                plots_directory
                / (
                    f"C_PDP{int(target_pdp)}"
                    f"__blocks{int(block_count)}"
                    "__support_ber.png"
                ),
            )

    return grouped


# ============================================================
# D. Relative improvement
# ============================================================

def task_d_relative_improvement(
    summary: pd.DataFrame,
    tables_directory: Path,
    plots_directory: Path,
) -> None:
    columns = [
        "target_pdp",
        "adaptation_blocks",
        "method",
        "seed_count",
        "mean_relative_improvement",
        "std_relative_improvement",
        "positive_improvement_fraction",
    ]

    result = summary[
        columns
    ].copy()

    result[
        "mean_relative_improvement_percent"
    ] = (
        100.0
        * result[
            "mean_relative_improvement"
        ]
    )

    result[
        "std_relative_improvement_percent"
    ] = (
        100.0
        * result[
            "std_relative_improvement"
        ]
    )

    result.to_csv(
        tables_directory
        / "D_relative_improvement_summary.csv",
        index=False,
    )

    for method in sorted(
        result["method"].unique()
    ):
        subset = result[
            result["method"]
            == method
        ]

        figure, axis = plt.subplots(
            figsize=(8.5, 5.5)
        )

        for target_pdp in sorted(
            subset["target_pdp"].unique()
        ):
            pdp_rows = (
                subset[
                    subset["target_pdp"]
                    == target_pdp
                ]
                .sort_values(
                    "adaptation_blocks"
                )
            )

            axis.errorbar(
                pdp_rows[
                    "adaptation_blocks"
                ],
                pdp_rows[
                    "mean_relative_improvement_percent"
                ],
                yerr=pdp_rows[
                    "std_relative_improvement_percent"
                ],
                marker="o",
                capsize=4,
                label=f"PDP{target_pdp}",
            )

        axis.set_xlabel(
            "Number of target support blocks"
        )

        axis.set_ylabel(
            "Relative BER improvement (%)"
        )

        axis.set_title(
            f"Relative adaptation improvement — {method}"
        )

        axis.grid(
            True,
            alpha=0.3,
        )

        axis.legend()

        save_figure(
            figure,
            plots_directory
            / (
                "D_relative_improvement"
                f"__{method}.png"
            ),
        )


# ============================================================
# E. Particular initialisation analysis
# ============================================================

def task_e_initialisation_analysis(
    dataframe: pd.DataFrame,
    tables_directory: Path,
    plots_directory: Path,
    reports_directory: Path,
) -> None:
    if (
        "particular_initialisation"
        not in dataframe.columns
    ):
        write_text(
            reports_directory
            / "E_initialisation_status.txt",
            (
                "The raw result does not contain the column "
                "'particular_initialisation'. Initialisation "
                "selection analysis cannot be generated.\n"
            ),
        )

        return

    summary = (
        dataframe
        .groupby(
            [
                "target_pdp",
                "adaptation_blocks",
                "particular_initialisation",
            ],
            as_index=False,
        )
        .agg(
            selection_count=(
                "seed",
                "count",
            ),

            unique_seed_count=(
                "seed",
                "nunique",
            ),

            mean_adapted_ber=(
                "adapted_ber",
                "mean",
            ),

            std_adapted_ber=(
                "adapted_ber",
                population_std,
            ),

            mean_initialisation_support_loss=(
                "initialisation_support_loss",
                safe_mean,
            )
            if (
                "initialisation_support_loss"
                in dataframe.columns
            )
            else (
                "adapted_ber",
                lambda values: float(
                    "nan"
                ),
            ),
        )
    )

    summary.to_csv(
        tables_directory
        / "E_initialisation_summary.csv",
        index=False,
    )

    count_summary = (
        dataframe
        .groupby(
            "particular_initialisation",
            as_index=False,
        )
        .size()
        .rename(
            columns={
                "size":
                    "selection_count",
            }
        )
        .sort_values(
            "selection_count",
            ascending=False,
        )
    )

    count_summary.to_csv(
        tables_directory
        / "E_initialisation_total_counts.csv",
        index=False,
    )

    figure, axis = plt.subplots(
        figsize=(9, 5.5)
    )

    axis.bar(
        count_summary[
            "particular_initialisation"
        ].astype(str),
        count_summary[
            "selection_count"
        ],
    )

    axis.set_xlabel(
        "Selected particular initialisation"
    )

    axis.set_ylabel(
        "Number of experiment selections"
    )

    axis.set_title(
        "Historical particular initialisation selections"
    )

    axis.tick_params(
        axis="x",
        rotation=35,
    )

    axis.grid(
        True,
        axis="y",
        alpha=0.3,
    )

    save_figure(
        figure,
        plots_directory
        / "E_initialisation_selection_counts.png",
    )


# ============================================================
# F. Shared/fixed versus particular parameter audit
# ============================================================

def task_f_parameter_change_audit(
    unseen_root: Path,
    tables_directory: Path,
    plots_directory: Path,
    reports_directory: Path,
) -> None:
    """Generate parameter-change tables and figures for each adaptation method.
    
        no_adaptation changes no parameters, particular_only_tl changes only the selected particular layers, and full_finetune may change both shared and particular layers.
    """
    candidate_paths = [
        unseen_root
        / "parameter_change_audit.csv",

        unseen_root
        / "parameter_changes.csv",

        PROJECT_ROOT
        / "outputs"
        / "task6"
        / "parameter_change_audit.csv",
    ]

    audit_path = find_first_existing(
        candidate_paths
    )

    if audit_path is None:
        message = (
            "Task F could not be calculated from the current "
            "Task 6 outputs.\n\n"
            "Expected file:\n"
            f"{unseen_root / 'parameter_change_audit.csv'}\n\n"
            "Required columns:\n"
            "method,seed,target_pdp,adaptation_blocks,"
            "layer_name,parameter_group,delta_l2,"
            "relative_delta_l2\n"
        )

        write_text(
            reports_directory
            / "F_parameter_change_status.txt",
            message,
        )

        return

    audit = pd.read_csv(
        audit_path
    )

    required = {
        "method",
        "layer_name",
        "parameter_group",
        "delta_l2",
        "relative_delta_l2",
    }

    missing = required.difference(
        audit.columns
    )

    if missing:
        write_text(
            reports_directory
            / "F_parameter_change_status.txt",
            (
                f"Found {audit_path}, but it is missing "
                f"columns: {sorted(missing)}\n"
            ),
        )

        return

    # Remove an obsolete status file.
    stale_status = (
        reports_directory
        / "F_parameter_change_status.txt"
    )

    if stale_status.exists():
        stale_status.unlink()

    layer_summary = (
        audit
        .groupby(
            [
                "method",
                "parameter_group",
                "layer_name",
            ],
            as_index=False,
        )
        .agg(
            experiment_count=(
                "relative_delta_l2",
                "count",
            ),

            mean_relative_delta_l2=(
                "relative_delta_l2",
                "mean",
            ),

            std_relative_delta_l2=(
                "relative_delta_l2",
                population_std,
            ),

            mean_delta_l2=(
                "delta_l2",
                "mean",
            ),

            std_delta_l2=(
                "delta_l2",
                population_std,
            ),

            mean_changed_parameter_fraction=(
                "changed_parameter_fraction",
                "mean",
            )
            if "changed_parameter_fraction"
            in audit.columns
            else (
                "relative_delta_l2",
                lambda values: float("nan"),
            ),
        )
    )

    layer_summary.to_csv(
        tables_directory
        / "F_parameter_change_summary.csv",
        index=False,
    )

    group_summary = (
        audit
        .groupby(
            [
                "method",
                "parameter_group",
            ],
            as_index=False,
        )
        .agg(
            mean_relative_delta_l2=(
                "relative_delta_l2",
                "mean",
            ),

            maximum_relative_delta_l2=(
                "relative_delta_l2",
                "max",
            ),

            mean_delta_l2=(
                "delta_l2",
                "mean",
            ),

            maximum_delta_l2=(
                "delta_l2",
                "max",
            ),
        )
    )

    group_summary.to_csv(
        tables_directory
        / "F_parameter_group_summary.csv",
        index=False,
    )

    methods = sorted(
        layer_summary["method"]
        .dropna()
        .astype(str)
        .unique()
    )

    for method in methods:
        method_rows = (
            layer_summary[
                layer_summary["method"]
                == method
            ]
            .sort_values(
                "mean_relative_delta_l2",
                ascending=False,
            )
        )

        figure, axis = plt.subplots(
            figsize=(12, 6)
        )

        axis.bar(
            method_rows["layer_name"],
            method_rows[
                "mean_relative_delta_l2"
            ],
        )

        axis.set_xlabel(
            "Layer"
        )

        axis.set_ylabel(
            "Mean relative L2 parameter change"
        )

        axis.set_title(
            "Layer-wise parameter change — "
            f"{method}"
        )

        axis.tick_params(
            axis="x",
            rotation=75,
        )

        axis.grid(
            True,
            axis="y",
            alpha=0.3,
        )

        save_figure(
            figure,
            plots_directory
            / (
                "F_parameter_change_by_layer"
                f"__{method}.png"
            ),
        )

    # Save a compact method/group mask figure.
    pivot = group_summary.pivot(
        index="method",
        columns="parameter_group",
        values="mean_relative_delta_l2",
    ).fillna(0.0)

    figure, axis = plt.subplots(
        figsize=(8.5, 5.5)
    )

    pivot.plot(
        kind="bar",
        ax=axis,
    )

    axis.set_xlabel(
        "Adaptation method"
    )

    axis.set_ylabel(
        "Mean relative L2 parameter change"
    )

    axis.set_title(
        "Shared versus particular parameter changes"
    )

    axis.tick_params(
        axis="x",
        rotation=20,
    )

    axis.grid(
        True,
        axis="y",
        alpha=0.3,
    )

    axis.legend(
        title="Parameter group"
    )

    save_figure(
        figure,
        plots_directory
        / "F_parameter_change_by_method_and_group.png",
    )


# ============================================================
# G. Support-size saturation analysis
# ============================================================

def task_g_saturation_analysis(
    summary: pd.DataFrame,
    tables_directory: Path,
    plots_directory: Path,
    reports_directory: Path,
) -> pd.DataFrame:
    """
    Measure the marginal BER reduction obtained when increasing
    the target support set.

    no_adaptation is excluded because it does not use target
    support data and therefore has zero marginal gain by
    definition.
    """
    adapted_summary = summary[
        summary["method"]
        != "no_adaptation"
    ].copy()

    rows: list[dict[str, object]] = []

    for (
        target_pdp,
        method,
    ), group in adapted_summary.groupby(
        [
            "target_pdp",
            "method",
        ]
    ):
        ordered = group.sort_values(
            "adaptation_blocks"
        ).reset_index(
            drop=True
        )

        for index in range(
            len(ordered)
        ):
            current = ordered.iloc[
                index
            ]

            if index == 0:
                previous_blocks = np.nan
                support_increment = np.nan
                marginal_ber_gain = np.nan
                marginal_gain_per_1000 = np.nan

            else:
                previous = ordered.iloc[
                    index - 1
                ]

                previous_blocks = int(
                    previous[
                        "adaptation_blocks"
                    ]
                )

                support_increment = float(
                    current[
                        "adaptation_blocks"
                    ]
                    - previous[
                        "adaptation_blocks"
                    ]
                )

                marginal_ber_gain = float(
                    previous[
                        "mean_adapted_ber"
                    ]
                    - current[
                        "mean_adapted_ber"
                    ]
                )

                marginal_gain_per_1000 = (
                    marginal_ber_gain
                    / support_increment
                    * 1000.0
                    if support_increment > 0
                    else np.nan
                )

            rows.append({
                "target_pdp":
                    target_pdp,

                "method":
                    method,

                "adaptation_blocks":
                    int(
                        current[
                            "adaptation_blocks"
                        ]
                    ),

                "previous_blocks":
                    previous_blocks,

                "support_increment":
                    support_increment,

                "mean_adapted_ber":
                    float(
                        current[
                            "mean_adapted_ber"
                        ]
                    ),

                "marginal_ber_gain":
                    marginal_ber_gain,

                "marginal_gain_per_1000_blocks":
                    marginal_gain_per_1000,
            })

    saturation = pd.DataFrame(
        rows
    )

    saturation.to_csv(
        tables_directory
        / "G_support_saturation_summary.csv",
        index=False,
    )

    figure, axis = plt.subplots(
        figsize=(9.5, 5.8)
    )

    valid = saturation.dropna(
        subset=[
            "marginal_gain_per_1000_blocks"
        ]
    )

    for (
        target_pdp,
        method,
    ), group in valid.groupby(
        [
            "target_pdp",
            "method",
        ]
    ):
        ordered = group.sort_values(
            "adaptation_blocks"
        )

        axis.plot(
            ordered[
                "adaptation_blocks"
            ],
            ordered[
                "marginal_gain_per_1000_blocks"
            ],
            marker="o",
            label=(
                f"PDP{target_pdp} — "
                f"{method}"
            ),
        )

    axis.set_xlabel(
        "Upper support size of each increment"
    )

    axis.set_ylabel(
        "BER reduction per 1,000 additional blocks"
    )

    axis.set_title(
        "Marginal BER gain from additional target support data"
    )

    axis.grid(
        True,
        alpha=0.3,
    )

    if not valid.empty:
        axis.legend()

    save_figure(
        figure,
        plots_directory
        / "G_support_size_saturation.png",
    )

    report_lines = [
        "Task G — Support-size saturation analysis",
        "",
        (
            "The no-adaptation baseline is excluded because "
            "it does not use target support data."
        ),
        "",
    ]

    for (
        target_pdp,
        method,
    ), group in saturation.groupby(
        [
            "target_pdp",
            "method",
        ]
    ):
        ordered = group.sort_values(
            "adaptation_blocks"
        )

        valid_group = ordered.dropna(
            subset=[
                "marginal_gain_per_1000_blocks"
            ]
        )

        report_lines.append(
            f"PDP{target_pdp}, method={method}"
        )

        if valid_group.empty:
            report_lines.append(
                "  Insufficient support-size points."
            )
            continue

        for _, row in valid_group.iterrows():
            report_lines.append(
                "  "
                f"{int(row['previous_blocks'])} -> "
                f"{int(row['adaptation_blocks'])} blocks: "
                f"{row['marginal_gain_per_1000_blocks']:.6f} "
                "BER reduction per 1,000 additional blocks."
            )

        first_efficiency = float(
            valid_group.iloc[0][
                "marginal_gain_per_1000_blocks"
            ]
        )

        final_efficiency = float(
            valid_group.iloc[-1][
                "marginal_gain_per_1000_blocks"
            ]
        )

        if final_efficiency < first_efficiency:
            report_lines.append(
                "  Interpretation: marginal efficiency "
                "decreases at larger support sizes, "
                "indicating increasing saturation."
            )
        else:
            report_lines.append(
                "  Interpretation: marginal efficiency does "
                "not show a simple decreasing pattern; the "
                "method has not clearly saturated over the "
                "tested range."
            )

        report_lines.append("")

    write_text(
        reports_directory
        / "G_support_saturation_report.txt",
        "\n".join(
            report_lines
        ),
    )

    return saturation


# ============================================================
# Combined report
# ============================================================

def build_final_report(
    raw_results_path: Path,
    dataframe: pd.DataFrame,
    summary: pd.DataFrame,
    task_a_result: dict[str, object],
    history_summary: pd.DataFrame,
    output_path: Path,
) -> None:
    lines = [
        "Task 6 Final Output Summary",
        "=" * 80,
        "",
        f"Raw results: {raw_results_path}",
        f"Number of raw rows: {len(dataframe)}",
        (
            "Seeds: "
            + ", ".join(
                str(value)
                for value in sorted(
                    dataframe[
                        "seed"
                    ].unique()
                )
            )
        ),
        (
            "Target PDPs: "
            + ", ".join(
                str(value)
                for value in sorted(
                    dataframe[
                        "target_pdp"
                    ].unique()
                )
            )
        ),
        (
            "Support sizes: "
            + ", ".join(
                str(value)
                for value in sorted(
                    dataframe[
                        "adaptation_blocks"
                    ].unique()
                )
            )
        ),
        (
            "Methods: "
            + ", ".join(
                task_a_result[
                    "available_methods"
                ]
            )
        ),
        "",
        "A. Strategy comparison",
        "-" * 80,
    ]

    if task_a_result[
        "comparison_available"
    ]:
        lines.append(
            "Multiple adaptation methods were available and "
            "were compared."
        )
    else:
        lines.append(
            "Only one adaptation method was available. "
            "A full fine-tuning comparison still requires "
            "matching full-finetune experiment rows."
        )

    lines.extend([
        "",
        "B. Support size versus BER",
        "-" * 80,
    ])

    for _, row in summary.iterrows():
        lines.append(
            f"PDP{int(row['target_pdp'])}, "
            f"{int(row['adaptation_blocks'])} blocks, "
            f"{row['method']}: "
            f"BER={row['mean_adapted_ber']:.6f} "
            f"± {row['std_adapted_ber']:.6f}; "
            f"relative improvement="
            f"{100.0 * row['mean_relative_improvement']:.2f}%."
        )

    lines.extend([
        "",
        "C. Learning curves",
        "-" * 80,
    ])

    if history_summary.empty:
        lines.append(
            "No training-history files were available."
        )
    else:
        lines.append(
            f"Loaded {len(history_summary)} grouped "
            "learning-curve records."
        )

    lines.extend([
        "",
        "D. Relative improvement",
        "-" * 80,
        (
            "Relative improvement plots and CSV tables were "
            "generated from the zero-shot and adapted BER."
        ),
        "",
        "E. Initialisation analysis",
        "-" * 80,
    ])

    if (
        "particular_initialisation"
        in dataframe.columns
    ):
        selection_counts = (
            dataframe[
                "particular_initialisation"
            ]
            .value_counts()
        )

        for name, count in (
            selection_counts.items()
        ):
            lines.append(
                f"{name}: selected {count} times."
            )
    else:
        lines.append(
            "No particular-initialisation column was found."
        )

    lines.extend([
        "",
        "F. Parameter-change audit",
        "-" * 80,
        (
            "Parameter-change analysis is generated only when "
            "a parameter_change_audit.csv file is available. "
            "The current BER/training-history files alone "
            "cannot prove that shared tensors remained exactly "
            "unchanged."
        ),
        "",
        "G. Support-size saturation",
        "-" * 80,
        (
            "Marginal BER gain per 1,000 additional support "
            "blocks was calculated. Lower marginal gain at "
            "larger support sizes indicates increasing "
            "saturation."
        ),
    ])

    write_text(
        output_path,
        "\n".join(
            lines
        ),
    )


# ============================================================
# Main
# ============================================================

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate Task 6 A-G summary tables, figures "
            "and reports from existing output files."
        )
    )

    parser.add_argument(
        "--unseen-root",
        type=Path,
        default=DEFAULT_UNSEEN_ROOT,
    )

    parser.add_argument(
        "--iadmm-root",
        type=Path,
        default=DEFAULT_IADMM_ROOT,
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
    )

    return parser.parse_args()


def main() -> int:
    args = parse_arguments()

    tables_directory = ensure_directory(
        args.output_root
        / "tables"
    )

    plots_directory = ensure_directory(
        args.output_root
        / "plots"
    )

    reports_directory = ensure_directory(
        args.output_root
        / "reports"
    )

    dataframe, raw_results_path = (
        load_unseen_results(
            args.unseen_root
        )
    )

    summary = build_unseen_summary(
        dataframe
    )

    summary.to_csv(
        tables_directory
        / "task6_master_summary.csv",
        index=False,
    )

    # A
    task_a_result = (
        task_a_strategy_comparison(
            dataframe=dataframe,
            tables_directory=(
                tables_directory
            ),
            plots_directory=(
                plots_directory
            ),
            reports_directory=(
                reports_directory
            ),
        )
    )

    # B
    task_b_support_size_ber(
        summary=summary,
        tables_directory=(
            tables_directory
        ),
        plots_directory=(
            plots_directory
        ),
    )

    # C
    history_summary = (
        task_c_learning_curves(
            unseen_root=(
                args.unseen_root
            ),
            tables_directory=(
                tables_directory
            ),
            plots_directory=(
                plots_directory
            ),
            reports_directory=(
                reports_directory
            ),
        )
    )

    # D
    task_d_relative_improvement(
        summary=summary,
        tables_directory=(
            tables_directory
        ),
        plots_directory=(
            plots_directory
        ),
    )

    # E
    task_e_initialisation_analysis(
        dataframe=dataframe,
        tables_directory=(
            tables_directory
        ),
        plots_directory=(
            plots_directory
        ),
        reports_directory=(
            reports_directory
        ),
    )

    # F
    task_f_parameter_change_audit(
        unseen_root=(
            args.unseen_root
        ),
        tables_directory=(
            tables_directory
        ),
        plots_directory=(
            plots_directory
        ),
        reports_directory=(
            reports_directory
        ),
    )

    # G
    task_g_saturation_analysis(
        summary=summary,
        tables_directory=(
            tables_directory
        ),
        plots_directory=(
            plots_directory
        ),
        reports_directory=(
            reports_directory
        ),
    )

    build_final_report(
        raw_results_path=(
            raw_results_path
        ),
        dataframe=dataframe,
        summary=summary,
        task_a_result=(
            task_a_result
        ),
        history_summary=(
            history_summary
        ),
        output_path=(
            reports_directory
            / "task6_final_report.txt"
        ),
    )

    print("=" * 80)
    print("Task 6 A-G output summary completed")
    print("=" * 80)
    print(
        f"Raw input:\n{raw_results_path}"
    )
    print(
        f"\nOutput directory:\n"
        f"{args.output_root}"
    )
    print("\nGenerated sections:")
    print("  A. Strategy comparison")
    print("  B. Support size versus BER")
    print("  C. Learning curves")
    print("  D. Relative improvement")
    print("  E. Initialisation analysis")
    print("  F. Parameter-change audit")
    print("  G. Support-size saturation")
    print(
        "\nMain report:\n"
        f"{reports_directory / 'task6_final_report.txt'}"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())