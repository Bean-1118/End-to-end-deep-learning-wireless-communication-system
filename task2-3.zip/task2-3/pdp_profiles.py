# PDP profiles for cross-environment mismatch analysis.
# Eight fixed PDP environments.
import numpy as np

def get_known_pdps(len_h=8):
    # PDP0: monotonically early-dominant
    PDP0 = np.array([
       0, 0, 0, 0, 
        0.13,0.37,0.26,0.24,
    ], dtype=np.float32)

    # PDP1: monotonically late-dominant
    PDP1 = np.array([
        0.02, 0.04, 0.05, 0.08,
        0.11, 0.16, 0.22, 0.32,
    ], dtype=np.float32)

    # PDP2: centre-left dominant
    PDP2 = np.array([
        0.08, 0.11, 0.16, 0.22,
        0.32, 0.02, 0.04, 0.05,
    ], dtype=np.float32)

    # PDP3: centre-right / shifted cluster
    PDP3 = np.array([
        0.11, 0.08, 0.05, 0.04,
        0.02, 0.32, 0.22, 0.16,
    ], dtype=np.float32)

    # PDP4: separated early and middle dominant paths
    PDP4 = np.array([
        0.32, 0.05, 0.16, 0.02,
        0.08, 0.22, 0.04, 0.11,
    ], dtype=np.float32)

    # PDP5: alternating dominant locations
    PDP5 = np.array([
        0.16, 0.02, 0.08, 0.22,
        0.04, 0.11, 0.32, 0.05,
    ], dtype=np.float32)

    # PDP6: mixed late/early profile
    PDP6 = np.array([
        0.04, 0.16, 0.05, 0.22,
        0.02, 0.11, 0.32, 0.08,
    ], dtype=np.float32)

    # PDP7: irregular fixed permutation
    PDP7 = np.array([
        0.22, 0.08, 0.02, 0.16,
        0.05, 0.32, 0.11, 0.04,
    ], dtype=np.float32)


    PDP_list = [PDP0, PDP1, PDP2, PDP3, PDP4, PDP5, PDP6, PDP7]

    # Normalise each PDP.
    PDP_list = [pdp / np.sum(pdp) for pdp in PDP_list]

    return PDP_list
